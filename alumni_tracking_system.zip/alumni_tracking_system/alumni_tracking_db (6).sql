-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2026 at 09:54 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alumni_tracking_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `alumni`
--

CREATE TABLE `alumni` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `alumni_id` varchar(30) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `suffix` varchar(10) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `contact_number` varchar(30) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `verification_status` enum('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  `submission_status` enum('draft','submitted') NOT NULL DEFAULT 'draft',
  `civil_status_id` int(11) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `city_municipality` varchar(100) DEFAULT NULL,
  `residence_type_id` int(11) DEFAULT NULL,
  `profile_status` enum('active','inactive','archived') NOT NULL DEFAULT 'active',
  `last_profile_update` datetime DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `alumni`
--

INSERT INTO `alumni` (`id`, `user_id`, `alumni_id`, `first_name`, `middle_name`, `last_name`, `suffix`, `date_of_birth`, `gender`, `contact_number`, `email`, `address`, `verification_status`, `submission_status`, `civil_status_id`, `region_id`, `province`, `city_municipality`, `residence_type_id`, `profile_status`, `last_profile_update`, `submitted_at`, `created`, `modified`) VALUES
(7, 10, 'NEC-2026-00010', 'John Matthew', 'Tamayo', 'Ong', NULL, '2005-01-28', 'Male', '09360692262', 'jmong@gmail.com', 'Naggasican,  Santiago City, Isabela', 'verified', 'submitted', 1, 4, 'Isabela', 'Santiago', 1, 'active', '2026-10-15 14:43:45', '2026-10-15 14:43:45', '2026-10-07 01:38:36', '2026-10-15 14:58:45');

-- --------------------------------------------------------

--
-- Table structure for table `alumni_academic`
--

CREATE TABLE `alumni_academic` (
  `id` int(11) NOT NULL,
  `alumni_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `major` varchar(150) DEFAULT NULL,
  `graduation_year` smallint(6) NOT NULL,
  `batch` varchar(30) DEFAULT NULL,
  `student_id` varchar(30) DEFAULT NULL,
  `degree` varchar(150) DEFAULT NULL,
  `honors_awards` varchar(255) DEFAULT NULL,
  `academic_year` varchar(9) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `alumni_academic`
--

INSERT INTO `alumni_academic` (`id`, `alumni_id`, `program_id`, `major`, `graduation_year`, `batch`, `student_id`, `degree`, `honors_awards`, `academic_year`, `created`, `modified`) VALUES
(7, 7, 4, 'Science', 2021, NULL, NULL, 'Bachelor of Secondary Education major in Science', 'Summa Cum Laude', '2020-2021', '2026-10-07 01:38:36', '2026-10-15 14:29:36');

-- --------------------------------------------------------

--
-- Table structure for table `alumni_correction_requests`
--

CREATE TABLE `alumni_correction_requests` (
  `id` int(11) NOT NULL,
  `alumni_id` int(11) NOT NULL,
  `source` enum('alumni','admin') NOT NULL DEFAULT 'alumni',
  `changes` text NOT NULL,
  `reason` varchar(500) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `review_note` varchar(500) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `alumni_correction_requests`
--

INSERT INTO `alumni_correction_requests` (`id`, `alumni_id`, `source`, `changes`, `reason`, `status`, `reviewed_by`, `reviewed_at`, `review_note`, `created`, `modified`) VALUES
(1, 7, 'alumni', '{\"date_of_birth\":{\"old\":\"2005-01-28\",\"new\":\"2005-02-28\"}}', 'my dob is feb', 'rejected', 1, '2026-10-15 15:30:07', 'kalalaking tao di alam bday, BADING!!', '2026-10-15 14:45:03', '2026-10-15 15:30:07');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `status` enum('draft','published') NOT NULL DEFAULT 'draft',
  `published_at` datetime DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `content`, `created_by`, `status`, `published_at`, `created`, `modified`) VALUES
(1, 'Welcome to the Alumni Tracking Portal', 'We are pleased to launch the Northeastern College Alumni Tracking System for the College of Education. Please keep your profile updated.', 1, 'published', '2026-10-07 01:30:40', '2026-10-07 01:30:40', '2026-10-07 01:30:40'),
(2, '2026 Homecoming Announcement', 'Save the date for the annual College of Education Alumni Homecoming this December.', 1, 'published', '2026-10-07 01:30:40', '2026-10-07 01:30:40', '2026-10-07 01:30:40');

-- --------------------------------------------------------

--
-- Table structure for table `api_login_attempts`
--

CREATE TABLE `api_login_attempts` (
  `id` int(11) NOT NULL,
  `identifier` varchar(150) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `attempted_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `api_tokens`
--

CREATE TABLE `api_tokens` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `device_name` varchar(100) DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `module` varchar(50) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `description`, `module`, `record_id`, `ip_address`, `created`) VALUES
(1, 1, 'LOGIN', 'Administrator logged in.', NULL, NULL, '127.0.0.1', '2026-10-07 01:30:40'),
(2, 1, 'CREATE_ANNOUNCEMENT', 'Created announcement: Welcome to the Alumni Tracking Portal', NULL, NULL, '127.0.0.1', '2026-10-07 01:30:40'),
(3, 1, 'CREATE_EVENT', 'Created event: College of Education Alumni Homecoming 2026', NULL, NULL, '127.0.0.1', '2026-10-07 01:30:40'),
(5, 1, 'LOGIN', 'Administrator logged in.', NULL, NULL, '::1', '2026-10-07 01:32:29'),
(6, 1, 'DELETE_USER', 'Deleted user msantos', NULL, NULL, '::1', '2026-10-07 01:34:59'),
(7, 1, 'DELETE_USER', 'Deleted user proyal', NULL, NULL, '::1', '2026-10-07 01:35:02'),
(8, 1, 'DELETE_USER', 'Deleted user rvillanueva', NULL, NULL, '::1', '2026-10-07 01:35:05'),
(9, 1, 'DELETE_USER', 'Deleted user alumni', NULL, NULL, '::1', '2026-10-07 01:35:09'),
(10, 1, 'DELETE_USER', 'Deleted user jdelacruz', NULL, NULL, '::1', '2026-10-07 01:35:15'),
(11, 1, 'EXPORT_REPORT', 'Exported GTS report dataset: summary', 'reports', NULL, '::1', '2026-10-07 01:35:44'),
(12, 1, 'LOGOUT', 'Administrator logged out.', NULL, NULL, '::1', '2026-10-07 01:38:22'),
(13, 1, 'LOGIN', 'Administrator logged in.', NULL, NULL, '::1', '2026-10-07 01:38:39'),
(14, 1, 'UPDATE_PROFILE_PICTURE', 'User changed own profile picture.', NULL, NULL, '::1', '2026-10-07 01:42:06'),
(15, 1, 'LOGOUT', 'Administrator logged out.', NULL, NULL, '::1', '2026-10-07 01:42:11'),
(16, 10, 'LOGIN', 'Alumni logged in.', NULL, NULL, '::1', '2026-10-07 01:42:14'),
(17, 10, 'UPDATE_PROFILE_PICTURE', 'User changed own profile picture.', NULL, NULL, '::1', '2026-10-07 01:42:27'),
(18, 10, 'SAVE_TRACER_SECTION', 'Saved GTS survey section 1.', 'tracer_surveys', 6, '::1', '2026-10-07 01:51:04'),
(19, 10, 'LOGOUT', 'Alumni logged out.', NULL, NULL, '::1', '2026-10-07 01:51:12'),
(20, 1, 'LOGIN', 'Administrator logged in.', NULL, NULL, '::1', '2026-10-07 01:51:14'),
(21, 1, 'LOGOUT', 'Administrator logged out.', NULL, NULL, '::1', '2026-10-07 01:51:39'),
(22, 10, 'LOGIN', 'Alumni logged in.', NULL, NULL, '::1', '2026-10-07 01:51:42'),
(23, 10, 'LOGOUT', 'Alumni logged out.', NULL, NULL, '::1', '2026-10-15 14:22:57'),
(24, 1, 'LOGIN', 'Administrator logged in.', NULL, NULL, '::1', '2026-10-15 14:22:59'),
(25, 1, 'LOGOUT', 'Administrator logged out.', NULL, NULL, '::1', '2026-10-15 14:28:40'),
(26, 10, 'LOGIN', 'Alumni logged in.', NULL, NULL, '::1', '2026-10-15 14:28:42'),
(27, 10, 'SAVE_TRACER_SECTION', 'Saved GTS survey section 2.', 'tracer_surveys', 6, '::1', '2026-10-15 14:29:36'),
(28, 10, 'SAVE_TRACER_SECTION', 'Saved GTS survey section 3.', 'tracer_surveys', 6, '::1', '2026-10-15 14:30:17'),
(29, 10, 'SAVE_TRACER_SECTION', 'Saved GTS survey section 4.', 'tracer_surveys', 6, '::1', '2026-10-15 14:30:33'),
(30, 10, 'SAVE_TRACER_SECTION', 'Saved GTS survey section 5.', 'tracer_surveys', 6, '::1', '2026-10-15 14:30:40'),
(31, 10, 'SAVE_TRACER_SECTION', 'Saved GTS survey section 6.', 'tracer_surveys', 6, '::1', '2026-10-15 14:30:56'),
(32, 10, 'SAVE_TRACER_SECTION', 'Saved GTS survey section 13.', 'tracer_surveys', 6, '::1', '2026-10-15 14:30:58'),
(33, 10, 'SUBMIT_TRACER', 'Alumni submitted the graduate tracer survey #2.', 'tracer_surveys', 6, '::1', '2026-10-15 14:31:03'),
(34, 10, 'SAVE_PROFILE_DRAFT', 'Alumni saved own profile (not yet submitted).', 'alumni', 7, '::1', '2026-10-15 14:39:06'),
(35, 10, 'LOGOUT', 'Alumni logged out.', NULL, NULL, '::1', '2026-10-15 14:39:25'),
(36, 1, 'LOGIN', 'Administrator logged in.', NULL, NULL, '::1', '2026-10-15 14:39:27'),
(37, 1, 'LOGIN', 'Administrator logged in.', NULL, NULL, '::1', '2026-10-15 14:39:27'),
(38, 1, 'ALLOW_TRACER_RESUBMISSION', 'Allowed resubmission of survey response #6', 'tracer_surveys', 6, '::1', '2026-10-15 14:39:44'),
(39, 1, 'LOGOUT', 'Administrator logged out.', NULL, NULL, '::1', '2026-10-15 14:39:48'),
(40, 10, 'LOGIN', 'Alumni logged in.', NULL, NULL, '::1', '2026-10-15 14:39:50'),
(41, 10, 'SAVE_TRACER_SECTION', 'Saved GTS survey section 6.', 'tracer_surveys', 6, '::1', '2026-10-15 14:40:02'),
(42, 10, 'SAVE_TRACER_SECTION', 'Saved GTS survey section 7.', 'tracer_surveys', 6, '::1', '2026-10-15 14:41:13'),
(43, 10, 'SAVE_TRACER_SECTION', 'Saved GTS survey section 8.', 'tracer_surveys', 6, '::1', '2026-10-15 14:41:44'),
(44, 10, 'SAVE_TRACER_SECTION', 'Saved GTS survey section 9.', 'tracer_surveys', 6, '::1', '2026-10-15 14:42:01'),
(45, 10, 'SAVE_TRACER_SECTION', 'Saved GTS survey section 10.', 'tracer_surveys', 6, '::1', '2026-10-15 14:42:13'),
(46, 10, 'SAVE_TRACER_SECTION', 'Saved GTS survey section 11.', 'tracer_surveys', 6, '::1', '2026-10-15 14:42:18'),
(47, 10, 'SAVE_TRACER_SECTION', 'Saved GTS survey section 12.', 'tracer_surveys', 6, '::1', '2026-10-15 14:42:46'),
(48, 10, 'SAVE_TRACER_SECTION', 'Saved GTS survey section 13.', 'tracer_surveys', 6, '::1', '2026-10-15 14:42:49'),
(49, 10, 'SUBMIT_TRACER', 'Alumni submitted the graduate tracer survey #2.', 'tracer_surveys', 6, '::1', '2026-10-15 14:43:00'),
(50, 10, 'SUBMIT_PROFILE', 'Alumni submitted personal information (profile locked).', 'alumni', 7, '::1', '2026-10-15 14:43:45'),
(51, 10, 'REQUEST_CORRECTION', 'Alumni requested correction of: date_of_birth', 'alumni', 7, '::1', '2026-10-15 14:45:03'),
(52, 10, 'LOGOUT', 'Alumni logged out.', NULL, NULL, '::1', '2026-10-15 14:45:05'),
(53, 1, 'LOGIN', 'Administrator logged in.', NULL, NULL, '::1', '2026-10-15 14:45:07'),
(54, 1, 'VERIFY_ALUMNI', 'Set alumni #7 verification status to verified', NULL, NULL, '::1', '2026-10-15 14:58:45'),
(55, 1, 'LOGOUT', 'Administrator logged out.', NULL, NULL, '::1', '2026-10-15 15:07:45'),
(56, 10, 'LOGIN', 'Alumni logged in.', NULL, NULL, '::1', '2026-10-15 15:07:47'),
(57, 10, 'EVENT_REGISTER', 'Alumni registered for event #2', NULL, NULL, '::1', '2026-10-15 15:07:50'),
(58, 10, 'EVENT_CANCEL', 'Alumni cancelled registration for event #2', NULL, NULL, '::1', '2026-10-15 15:07:54'),
(59, 10, 'EVENT_REGISTER', 'Alumni registered for event #1', NULL, NULL, '::1', '2026-10-15 15:07:55'),
(60, 10, 'LOGOUT', 'Alumni logged out.', NULL, NULL, '::1', '2026-10-15 15:07:57'),
(61, 1, 'LOGIN', 'Administrator logged in.', NULL, NULL, '::1', '2026-10-15 15:07:59'),
(62, 10, 'LOGIN', 'Alumni logged in from the mobile app.', 'Auth', NULL, '127.0.0.1', '2026-10-15 15:27:01'),
(63, 1, 'REJECT_CORRECTION', 'Rejected correction request #1', 'alumni', NULL, '::1', '2026-10-15 15:30:07'),
(64, 1, 'ALLOW_TRACER_RESUBMISSION', 'Allowed resubmission of survey response #6', 'tracer_surveys', 6, '::1', '2026-10-15 15:30:37'),
(65, 1, 'LOGOUT', 'Administrator logged out.', NULL, NULL, '::1', '2026-10-15 15:31:47'),
(66, 10, 'LOGIN', 'Alumni logged in.', NULL, NULL, '::1', '2026-10-15 15:31:49'),
(67, 10, 'SUBMIT_TRACER', 'Alumni submitted the graduate tracer survey #2.', 'tracer_surveys', 6, '::1', '2026-10-15 15:31:58'),
(68, 10, 'LOGOUT', 'Alumni logged out.', NULL, NULL, '::1', '2026-10-15 15:31:59'),
(69, 1, 'LOGIN', 'Administrator logged in.', NULL, NULL, '::1', '2026-10-15 15:32:01'),
(70, 1, 'LOGOUT', 'Administrator logged out.', NULL, NULL, '::1', '2026-10-15 15:33:05'),
(71, 10, 'LOGIN', 'Alumni logged in.', NULL, NULL, '::1', '2026-10-15 15:33:08'),
(72, 10, 'LOGOUT', 'Alumni logged out.', NULL, NULL, '::1', '2026-10-15 15:33:28'),
(73, 10, 'LOGIN', 'Alumni logged in.', NULL, NULL, '::1', '2026-10-15 15:33:29'),
(74, 10, 'LOGOUT', 'Alumni logged out from the mobile app.', 'Auth', NULL, '127.0.0.1', '2026-10-15 15:35:16');

-- --------------------------------------------------------

--
-- Table structure for table `civil_statuses`
--

CREATE TABLE `civil_statuses` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_other` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `civil_statuses`
--

INSERT INTO `civil_statuses` (`id`, `name`, `sort_order`, `is_other`, `is_active`) VALUES
(1, 'Single', 1, 0, 1),
(2, 'Married', 2, 0, 1),
(3, 'Separated', 3, 0, 1),
(4, 'Widowed', 4, 0, 1),
(5, 'Other', 5, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `competencies`
--

CREATE TABLE `competencies` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_other` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `competencies`
--

INSERT INTO `competencies` (`id`, `name`, `sort_order`, `is_other`, `is_active`) VALUES
(1, 'Communication skills', 1, 0, 1),
(2, 'Human relations skills', 2, 0, 1),
(3, 'Entrepreneurial skills', 3, 0, 1),
(4, 'Information technology skills', 4, 0, 1),
(5, 'Problem-solving skills', 5, 0, 1),
(6, 'Critical thinking skills', 6, 0, 1),
(7, 'Other', 7, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `course_reasons`
--

CREATE TABLE `course_reasons` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_other` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `course_reasons`
--

INSERT INTO `course_reasons` (`id`, `name`, `sort_order`, `is_other`, `is_active`) VALUES
(1, 'High grades in the course or subject area(s) related to the course', 1, 0, 1),
(2, 'Good grades in high school', 2, 0, 1),
(3, 'Influence of parents or relatives', 3, 0, 1),
(4, 'Peer influence', 4, 0, 1),
(5, 'Inspired by a role model', 5, 0, 1),
(6, 'Strong passion for the profession', 6, 0, 1),
(7, 'Prospect for immediate employment', 7, 0, 1),
(8, 'Status or prestige of the profession', 8, 0, 1),
(9, 'Availability of course offering in chosen institution', 9, 0, 1),
(10, 'Prospect of career advancement', 10, 0, 1),
(11, 'Affordable for the family', 11, 0, 1),
(12, 'Prospect of attractive compensation', 12, 0, 1),
(13, 'Opportunity for employment abroad', 13, 0, 1),
(14, 'No particular choice or no better idea', 14, 0, 1),
(15, 'Other', 15, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `curriculum_feedback`
--

CREATE TABLE `curriculum_feedback` (
  `id` int(11) NOT NULL,
  `survey_id` int(11) NOT NULL,
  `feedback` text DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `curriculum_feedback`
--

INSERT INTO `curriculum_feedback` (`id`, `survey_id`, `feedback`, `created`, `modified`) VALUES
(4, 6, NULL, '2026-10-15 14:30:58', '2026-10-15 14:42:49');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `department_name` varchar(150) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `department_name`, `created`, `modified`) VALUES
(1, 'College of Education', '2026-10-07 01:30:40', '2026-10-07 01:30:40');

-- --------------------------------------------------------

--
-- Table structure for table `duration_ranges`
--

CREATE TABLE `duration_ranges` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_other` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `duration_ranges`
--

INSERT INTO `duration_ranges` (`id`, `name`, `sort_order`, `is_other`, `is_active`) VALUES
(1, 'Less than 1 month', 1, 0, 1),
(2, '1–6 months', 2, 0, 1),
(3, '7–11 months', 3, 0, 1),
(4, '1 year to less than 2 years', 4, 0, 1),
(5, '2 years to less than 3 years', 5, 0, 1),
(6, '3 years to less than 4 years', 6, 0, 1),
(7, 'Other', 7, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `education_levels`
--

CREATE TABLE `education_levels` (
  `id` int(11) NOT NULL,
  `level_name` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `education_levels`
--

INSERT INTO `education_levels` (`id`, `level_name`) VALUES
(1, 'Baccalaureate'),
(4, 'Certificate/Short Course'),
(3, 'Doctorate Degree'),
(2, 'Master\'s Degree');

-- --------------------------------------------------------

--
-- Table structure for table `education_records`
--

CREATE TABLE `education_records` (
  `id` int(11) NOT NULL,
  `alumni_id` int(11) NOT NULL,
  `education_level_id` int(11) NOT NULL,
  `institution` varchar(150) NOT NULL,
  `degree` varchar(150) DEFAULT NULL,
  `field_of_study` varchar(150) DEFAULT NULL,
  `start_year` smallint(6) DEFAULT NULL,
  `end_year` smallint(6) DEFAULT NULL,
  `status` enum('Ongoing','Completed','Discontinued') NOT NULL DEFAULT 'Completed',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employment_reasons`
--

CREATE TABLE `employment_reasons` (
  `id` int(11) NOT NULL,
  `reason_type` enum('accept','change') NOT NULL,
  `name` varchar(150) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_other` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employment_reasons`
--

INSERT INTO `employment_reasons` (`id`, `reason_type`, `name`, `sort_order`, `is_other`, `is_active`) VALUES
(1, 'accept', 'Salary and benefits', 1, 0, 1),
(2, 'accept', 'Career challenge', 2, 0, 1),
(3, 'accept', 'Related to special skills', 3, 0, 1),
(4, 'accept', 'Proximity to residence', 4, 0, 1),
(5, 'accept', 'Other', 5, 1, 1),
(6, 'change', 'Salary and benefits', 1, 0, 1),
(7, 'change', 'Career challenge', 2, 0, 1),
(8, 'change', 'Related to special skills', 3, 0, 1),
(9, 'change', 'Proximity to residence', 4, 0, 1),
(10, 'change', 'Other', 5, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `employment_records`
--

CREATE TABLE `employment_records` (
  `id` int(11) NOT NULL,
  `alumni_id` int(11) NOT NULL,
  `employment_status_id` int(11) NOT NULL,
  `employer` varchar(150) DEFAULT NULL,
  `job_position` varchar(150) DEFAULT NULL,
  `industry` varchar(150) DEFAULT NULL,
  `employment_location` varchar(150) DEFAULT NULL,
  `employment_type` enum('Full-time','Part-time','Contractual','Self-employed','N/A') NOT NULL DEFAULT 'N/A',
  `date_hired` date DEFAULT NULL,
  `date_ended` date DEFAULT NULL,
  `is_current` tinyint(1) NOT NULL DEFAULT 1,
  `survey_id` int(11) DEFAULT NULL,
  `is_first_job` tinyint(1) NOT NULL DEFAULT 0,
  `employment_type_id` int(11) DEFAULT NULL,
  `industry_id` int(11) DEFAULT NULL,
  `place_of_work` enum('Local','Abroad') DEFAULT NULL,
  `job_level_id` int(11) DEFAULT NULL,
  `salary_range_id` int(11) DEFAULT NULL,
  `related_to_degree` tinyint(1) DEFAULT NULL,
  `search_method_id` int(11) DEFAULT NULL,
  `time_to_job_id` int(11) DEFAULT NULL,
  `duration_id` int(11) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employment_records`
--

INSERT INTO `employment_records` (`id`, `alumni_id`, `employment_status_id`, `employer`, `job_position`, `industry`, `employment_location`, `employment_type`, `date_hired`, `date_ended`, `is_current`, `survey_id`, `is_first_job`, `employment_type_id`, `industry_id`, `place_of_work`, `job_level_id`, `salary_range_id`, `related_to_degree`, `search_method_id`, `time_to_job_id`, `duration_id`, `created`, `modified`) VALUES
(8, 7, 4, 'MSB', 'Video Editor', 'Other Community, Social and Personal Services', 'phillipines', 'Self-employed', '2025-01-28', NULL, 1, 6, 1, 5, 15, 'Local', 4, 5, 1, 1, 2, 4, '2026-10-15 14:41:13', '2026-10-15 14:42:13');

-- --------------------------------------------------------

--
-- Table structure for table `employment_record_reasons`
--

CREATE TABLE `employment_record_reasons` (
  `id` int(11) NOT NULL,
  `employment_record_id` int(11) NOT NULL,
  `employment_reason_id` int(11) NOT NULL,
  `other_text` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employment_record_reasons`
--

INSERT INTO `employment_record_reasons` (`id`, `employment_record_id`, `employment_reason_id`, `other_text`) VALUES
(10, 8, 1, NULL),
(11, 8, 2, NULL),
(12, 8, 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employment_statuses`
--

CREATE TABLE `employment_statuses` (
  `id` int(11) NOT NULL,
  `status_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employment_statuses`
--

INSERT INTO `employment_statuses` (`id`, `status_name`) VALUES
(2, 'Employed - Not Related to Course'),
(1, 'Employed - Related to Course'),
(5, 'Further Studies'),
(4, 'Self-Employed'),
(3, 'Unemployed');

-- --------------------------------------------------------

--
-- Table structure for table `employment_types`
--

CREATE TABLE `employment_types` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_other` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employment_types`
--

INSERT INTO `employment_types` (`id`, `name`, `sort_order`, `is_other`, `is_active`) VALUES
(1, 'Regular / Permanent', 1, 0, 1),
(2, 'Temporary', 2, 0, 1),
(3, 'Contractual', 3, 0, 1),
(4, 'Casual', 4, 0, 1),
(5, 'Self-employed', 5, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `event_date` date NOT NULL,
  `event_time` time DEFAULT NULL,
  `location` varchar(200) DEFAULT NULL,
  `registration_deadline` date DEFAULT NULL,
  `status` enum('upcoming','ongoing','completed','cancelled') NOT NULL DEFAULT 'upcoming',
  `created_by` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `description`, `event_date`, `event_time`, `location`, `registration_deadline`, `status`, `created_by`, `created`, `modified`) VALUES
(1, 'College of Education Alumni Homecoming 2026', 'A gathering of BEEd and BSEd graduates across all batches.', '2026-12-05', '14:00:00', 'Northeastern College Gymnasium', '2026-11-28', 'upcoming', 1, '2026-10-07 01:30:40', '2026-10-07 01:30:40'),
(2, 'Career and Job Fair 2026', 'On-campus job fair for graduating students and alumni.', '2026-10-20', '08:00:00', 'Northeastern College Covered Court', '2026-10-15', 'upcoming', 1, '2026-10-07 01:30:40', '2026-10-07 01:30:40'),
(3, 'Alumni Homecoming 2025', 'Annual gathering of College of Education alumni.', '2025-12-06', '14:00:00', 'Northeastern College Gymnasium', '2025-11-28', 'completed', 1, '2026-10-07 01:30:40', '2026-10-07 01:30:40'),
(4, 'Teachers Congress 2026', 'Professional development congress for education alumni.', '2026-03-14', '08:00:00', 'Northeastern College Auditorium', '2026-03-07', 'completed', 1, '2026-10-07 01:30:40', '2026-10-07 01:30:40'),
(5, 'Alumni Outreach Day 2026', 'Community outreach activity organised with the alumni association.', '2026-08-22', '07:30:00', 'Santiago City', '2026-08-15', 'completed', 1, '2026-10-07 01:30:40', '2026-10-07 01:30:40');

-- --------------------------------------------------------

--
-- Table structure for table `event_registrations`
--

CREATE TABLE `event_registrations` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `alumni_id` int(11) NOT NULL,
  `registration_status` enum('registered','cancelled','attended') NOT NULL DEFAULT 'registered',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `event_registrations`
--

INSERT INTO `event_registrations` (`id`, `event_id`, `alumni_id`, `registration_status`, `created`, `modified`) VALUES
(15, 2, 7, 'cancelled', '2026-10-15 15:07:50', '2026-10-15 15:07:54'),
(16, 1, 7, 'registered', '2026-10-15 15:07:55', '2026-10-15 15:07:55');

-- --------------------------------------------------------

--
-- Table structure for table `industries`
--

CREATE TABLE `industries` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_other` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `industries`
--

INSERT INTO `industries` (`id`, `name`, `sort_order`, `is_other`, `is_active`) VALUES
(1, 'Agriculture, Hunting and Forestry', 1, 0, 1),
(2, 'Fishing', 2, 0, 1),
(3, 'Mining and Quarrying', 3, 0, 1),
(4, 'Manufacturing', 4, 0, 1),
(5, 'Electricity, Gas and Water Supply', 5, 0, 1),
(6, 'Construction', 6, 0, 1),
(7, 'Wholesale and Retail Trade', 7, 0, 1),
(8, 'Hotels and Restaurants', 8, 0, 1),
(9, 'Transport, Storage and Communication', 9, 0, 1),
(10, 'Financial Intermediation', 10, 0, 1),
(11, 'Real Estate, Renting and Business Activities', 11, 0, 1),
(12, 'Public Administration and Defense', 12, 0, 1),
(13, 'Education', 13, 0, 1),
(14, 'Health and Social Work', 14, 0, 1),
(15, 'Other Community, Social and Personal Services', 15, 0, 1),
(16, 'Private Households with Employed Persons', 16, 0, 1),
(17, 'Extra-territorial Organizations and Bodies', 17, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `job_levels`
--

CREATE TABLE `job_levels` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_other` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_levels`
--

INSERT INTO `job_levels` (`id`, `name`, `sort_order`, `is_other`, `is_active`) VALUES
(1, 'Rank or Clerical', 1, 0, 1),
(2, 'Professional, Technical or Supervisory', 2, 0, 1),
(3, 'Managerial or Executive', 3, 0, 1),
(4, 'Self-employed', 4, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `job_postings`
--

CREATE TABLE `job_postings` (
  `id` int(11) NOT NULL,
  `job_title` varchar(200) NOT NULL,
  `company` varchar(150) NOT NULL,
  `location` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `qualifications` text DEFAULT NULL,
  `application_instructions` text DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `status` enum('open','closed') NOT NULL DEFAULT 'open',
  `created_by` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_postings`
--

INSERT INTO `job_postings` (`id`, `job_title`, `company`, `location`, `description`, `qualifications`, `application_instructions`, `deadline`, `status`, `created_by`, `created`, `modified`) VALUES
(1, 'Elementary Teacher', 'Santiago City West Central School', 'Santiago City, Isabela', 'Full-time elementary teaching position for SY 2026-2027.', 'LET Passer, BEEd graduate', 'Send resume to hr@example-school.edu.ph', '2026-11-30', 'open', 1, '2026-10-07 01:30:40', '2026-10-07 01:30:40'),
(2, 'High School Math Teacher', 'Isabela National School', 'Ilagan City, Isabela', 'Teach Mathematics to junior and senior high school students.', 'LET Passer, BSEd Math graduate preferred', 'Apply in person at the school registrar office.', '2026-11-15', 'open', 1, '2026-10-07 01:30:40', '2026-10-07 01:30:40');

-- --------------------------------------------------------

--
-- Table structure for table `job_search_methods`
--

CREATE TABLE `job_search_methods` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_other` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_search_methods`
--

INSERT INTO `job_search_methods` (`id`, `name`, `sort_order`, `is_other`, `is_active`) VALUES
(1, 'Response to advertisement', 1, 0, 1),
(2, 'Walk-in applicant', 2, 0, 1),
(3, 'Recommended by someone', 3, 0, 1),
(4, 'Information from friends', 4, 0, 1),
(5, 'Arranged by school\'s job placement officer', 5, 0, 1),
(6, 'Family business', 6, 0, 1),
(7, 'Job Fair or Public Employment Service Office', 7, 0, 1),
(8, 'Other', 8, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `license_types`
--

CREATE TABLE `license_types` (
  `id` int(11) NOT NULL,
  `license_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `license_types`
--

INSERT INTO `license_types` (`id`, `license_name`) VALUES
(1, 'Licensure Examination for Teachers (LET) - Elementary'),
(2, 'Licensure Examination for Teachers (LET) - Secondary');

-- --------------------------------------------------------

--
-- Table structure for table `licensure_records`
--

CREATE TABLE `licensure_records` (
  `id` int(11) NOT NULL,
  `alumni_id` int(11) NOT NULL,
  `license_type_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `examination_year` smallint(6) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `licensure_statuses`
--

CREATE TABLE `licensure_statuses` (
  `id` int(11) NOT NULL,
  `status_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `licensure_statuses`
--

INSERT INTO `licensure_statuses` (`id`, `status_name`) VALUES
(3, 'Failed'),
(4, 'For Retake'),
(1, 'Not Taken'),
(2, 'Passed');

-- --------------------------------------------------------

--
-- Table structure for table `professional_examinations`
--

CREATE TABLE `professional_examinations` (
  `id` int(11) NOT NULL,
  `alumni_id` int(11) NOT NULL,
  `exam_name` varchar(200) NOT NULL,
  `date_taken` date DEFAULT NULL,
  `rating` varchar(20) DEFAULT NULL,
  `result` enum('Passed','Failed','Pending') NOT NULL DEFAULT 'Passed',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `programs`
--

CREATE TABLE `programs` (
  `id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `program_code` varchar(20) NOT NULL,
  `program_name` varchar(150) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `programs`
--

INSERT INTO `programs` (`id`, `department_id`, `program_code`, `program_name`, `created`, `modified`) VALUES
(1, 1, 'BEEd', 'Bachelor of Elementary Education', '2026-10-07 01:30:40', '2026-10-07 01:30:40'),
(2, 1, 'BSEd-Eng', 'Bachelor of Secondary Education major in English', '2026-10-07 01:30:40', '2026-10-07 01:30:40'),
(3, 1, 'BSEd-Math', 'Bachelor of Secondary Education major in Mathematics', '2026-10-07 01:30:40', '2026-10-07 01:30:40'),
(4, 1, 'BSEd-Sci', 'Bachelor of Secondary Education major in Science', '2026-10-07 01:30:40', '2026-10-07 01:30:40');

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

CREATE TABLE `regions` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_other` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`id`, `name`, `sort_order`, `is_other`, `is_active`) VALUES
(1, 'National Capital Region (NCR)', 1, 0, 1),
(2, 'Cordillera Administrative Region (CAR)', 2, 0, 1),
(3, 'Region I - Ilocos Region', 3, 0, 1),
(4, 'Region II - Cagayan Valley', 4, 0, 1),
(5, 'Region III - Central Luzon', 5, 0, 1),
(6, 'Region IV-A - CALABARZON', 6, 0, 1),
(7, 'MIMAROPA Region', 7, 0, 1),
(8, 'Region V - Bicol Region', 8, 0, 1),
(9, 'Region VI - Western Visayas', 9, 0, 1),
(10, 'Region VII - Central Visayas', 10, 0, 1),
(11, 'Region VIII - Eastern Visayas', 11, 0, 1),
(12, 'Region IX - Zamboanga Peninsula', 12, 0, 1),
(13, 'Region X - Northern Mindanao', 13, 0, 1),
(14, 'Region XI - Davao Region', 14, 0, 1),
(15, 'Region XII - SOCCSKSARGEN', 15, 0, 1),
(16, 'Region XIII - Caraga', 16, 0, 1),
(17, 'Bangsamoro Autonomous Region in Muslim Mindanao (BARMM)', 17, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `residence_types`
--

CREATE TABLE `residence_types` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_other` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `residence_types`
--

INSERT INTO `residence_types` (`id`, `name`, `sort_order`, `is_other`, `is_active`) VALUES
(1, 'City', 1, 0, 1),
(2, 'Municipality', 2, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `salary_ranges`
--

CREATE TABLE `salary_ranges` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_other` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `salary_ranges`
--

INSERT INTO `salary_ranges` (`id`, `name`, `sort_order`, `is_other`, `is_active`) VALUES
(1, 'Below ₱5,000', 1, 0, 1),
(2, '₱5,000 to less than ₱10,000', 2, 0, 1),
(3, '₱10,000 to less than ₱15,000', 3, 0, 1),
(4, '₱15,000 to less than ₱20,000', 4, 0, 1),
(5, '₱20,000 to less than ₱25,000', 5, 0, 1),
(6, '₱25,000 and above', 6, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `survey_competencies`
--

CREATE TABLE `survey_competencies` (
  `id` int(11) NOT NULL,
  `survey_id` int(11) NOT NULL,
  `competency_id` int(11) NOT NULL,
  `other_text` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `survey_competencies`
--

INSERT INTO `survey_competencies` (`id`, `survey_id`, `competency_id`, `other_text`) VALUES
(7, 6, 1, NULL),
(8, 6, 2, NULL),
(9, 6, 3, NULL),
(10, 6, 5, NULL),
(11, 6, 6, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `survey_course_reasons`
--

CREATE TABLE `survey_course_reasons` (
  `id` int(11) NOT NULL,
  `survey_id` int(11) NOT NULL,
  `course_reason_id` int(11) NOT NULL,
  `other_text` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `survey_course_reasons`
--

INSERT INTO `survey_course_reasons` (`id`, `survey_id`, `course_reason_id`, `other_text`) VALUES
(11, 6, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `survey_unemployment_reasons`
--

CREATE TABLE `survey_unemployment_reasons` (
  `id` int(11) NOT NULL,
  `survey_id` int(11) NOT NULL,
  `unemployment_reason_id` int(11) NOT NULL,
  `other_text` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tracer_questions`
--

CREATE TABLE `tracer_questions` (
  `id` int(11) NOT NULL,
  `tracer_study_id` int(11) NOT NULL,
  `question` text NOT NULL,
  `question_type` enum('text','yes_no','multiple_choice','select') NOT NULL DEFAULT 'text',
  `options` text DEFAULT NULL COMMENT 'Pipe-separated options for multiple_choice/select',
  `is_required` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tracer_questions`
--

INSERT INTO `tracer_questions` (`id`, `tracer_study_id`, `question`, `question_type`, `options`, `is_required`, `sort_order`, `created`, `modified`) VALUES
(1, 1, 'Are you currently employed?', 'yes_no', NULL, 1, 1, '2026-10-07 01:30:40', '2026-10-07 01:30:40'),
(2, 1, 'What is your current employment status?', 'select', 'Employed - Related to Course|Employed - Not Related to Course|Unemployed|Self-Employed|Further Studies', 1, 2, '2026-10-07 01:30:40', '2026-10-07 01:30:40'),
(3, 1, 'How relevant is your degree to your current job?', 'multiple_choice', 'Very Relevant|Somewhat Relevant|Not Relevant', 0, 3, '2026-10-07 01:30:40', '2026-10-07 01:30:40'),
(4, 1, 'Any comments or suggestions for the program?', 'text', NULL, 0, 4, '2026-10-07 01:30:40', '2026-10-07 01:30:40');

-- --------------------------------------------------------

--
-- Table structure for table `tracer_responses`
--

CREATE TABLE `tracer_responses` (
  `id` int(11) NOT NULL,
  `tracer_study_id` int(11) NOT NULL,
  `tracer_question_id` int(11) NOT NULL,
  `alumni_id` int(11) NOT NULL,
  `answer` text DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tracer_studies`
--

CREATE TABLE `tracer_studies` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('draft','active','closed') NOT NULL DEFAULT 'draft',
  `survey_year` smallint(6) DEFAULT NULL,
  `survey_type` enum('custom','gts') NOT NULL DEFAULT 'custom',
  `created_by` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tracer_studies`
--

INSERT INTO `tracer_studies` (`id`, `title`, `description`, `start_date`, `end_date`, `status`, `survey_year`, `survey_type`, `created_by`, `created`, `modified`) VALUES
(1, '2024 Graduate Tracer Study', 'Annual tracer study for BEEd and BSEd graduates to monitor employment and program outcomes.', '2024-01-01', '2026-12-31', 'active', 2024, 'custom', 1, '2026-10-07 01:30:40', '2026-10-07 01:30:40'),
(2, '2026 Graduate Tracer Survey (CHED GTS-aligned)', 'Annual graduate tracer survey designed from the information requirements reflected in the CHED Graduate Tracer Survey. Please answer every section that applies to you.', '2026-01-01', '2026-12-31', 'active', 2026, 'gts', 1, '2026-10-07 01:30:40', '2026-10-07 01:30:40');

-- --------------------------------------------------------

--
-- Table structure for table `tracer_surveys`
--

CREATE TABLE `tracer_surveys` (
  `id` int(11) NOT NULL,
  `tracer_study_id` int(11) NOT NULL,
  `alumni_id` int(11) NOT NULL,
  `employment_state` enum('employed','not_employed','never_employed') DEFAULT NULL,
  `current_is_first_job` tinyint(1) DEFAULT NULL,
  `curriculum_relevant` tinyint(1) DEFAULT NULL,
  `last_section` tinyint(4) NOT NULL DEFAULT 1,
  `status` enum('draft','submitted') NOT NULL DEFAULT 'draft',
  `allow_resubmission` tinyint(1) NOT NULL DEFAULT 0,
  `submitted_at` datetime DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tracer_surveys`
--

INSERT INTO `tracer_surveys` (`id`, `tracer_study_id`, `alumni_id`, `employment_state`, `current_is_first_job`, `curriculum_relevant`, `last_section`, `status`, `allow_resubmission`, `submitted_at`, `created`, `modified`) VALUES
(6, 2, 7, 'employed', 1, 1, 14, 'submitted', 0, '2026-10-15 15:31:58', '2026-10-07 01:42:37', '2026-10-15 15:31:58');

-- --------------------------------------------------------

--
-- Table structure for table `training_records`
--

CREATE TABLE `training_records` (
  `id` int(11) NOT NULL,
  `alumni_id` int(11) NOT NULL,
  `training_title` varchar(200) NOT NULL,
  `organizer` varchar(150) DEFAULT NULL,
  `date_start` date DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  `training_type` enum('Training','Advanced Study') NOT NULL DEFAULT 'Training',
  `duration` varchar(60) DEFAULT NULL,
  `credits_earned` varchar(30) DEFAULT NULL,
  `college_university` varchar(150) DEFAULT NULL,
  `training_year` smallint(6) DEFAULT NULL,
  `purpose` enum('Promotion','Professional Development','Other') DEFAULT NULL,
  `purpose_other` varchar(150) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `unemployment_reasons`
--

CREATE TABLE `unemployment_reasons` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_other` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `unemployment_reasons`
--

INSERT INTO `unemployment_reasons` (`id`, `name`, `sort_order`, `is_other`, `is_active`) VALUES
(1, 'Further study', 1, 0, 1),
(2, 'No job opportunity', 2, 0, 1),
(3, 'Family concern', 3, 0, 1),
(4, 'Did not look for a job', 4, 0, 1),
(5, 'Health-related reason', 5, 0, 1),
(6, 'Lack of work experience', 6, 0, 1),
(7, 'Other', 7, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(55) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(55) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `profile_picture` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `status`, `profile_picture`, `created`, `modified`) VALUES
(1, 'admin', 'admin@necolleges.edu.ph', '$2y$10$JW3ykrocgivX1TpeU.CwS.FUdOgfdgDA0KL6QbwPDqlNSJh8NEU.a', 'Administrator', 'active', 'u1_84ebab76a96014cc171fc787.webp', '2026-10-07 01:30:40', '2026-10-07 01:42:06'),
(3, 'faculty', 'faculty.demo@necolleges.edu.ph', '$2y$10$6wyYytyRCrlnR0fWKu3caOTBQXpTsfnb2zE9z3HY2QSGlO8o/dWSC', 'Faculty', 'active', NULL, '2026-10-07 01:30:40', '2026-10-07 01:30:40'),
(4, 'qa', 'qa.demo@necolleges.edu.ph', '$2y$10$On8HDzKm3eApP5g3iIfemuE9Al0G9dtnQyQNnyPyVErR2NE4mlqqi', 'Quality Assurance', 'active', NULL, '2026-10-07 01:30:40', '2026-10-07 01:30:40'),
(10, 'jm_ong28', 'jmong@gmail.com', '$2y$10$6YCix6ppAMvXYfJQ2EOtLePMGVCk4VXSZhHEOdWKcgSXUqOSlrae6', 'Alumni', 'active', 'u10_3cdeef31b8c342aeb5314541.jpg', '2026-10-07 01:38:36', '2026-10-07 01:42:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alumni`
--
ALTER TABLE `alumni`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `alumni_id` (`alumni_id`),
  ADD KEY `fk_alumni_civil` (`civil_status_id`),
  ADD KEY `fk_alumni_region` (`region_id`),
  ADD KEY `fk_alumni_residence` (`residence_type_id`),
  ADD KEY `idx_alumni_email` (`email`),
  ADD KEY `idx_alumni_profile_status` (`profile_status`),
  ADD KEY `idx_alumni_names` (`last_name`,`first_name`),
  ADD KEY `idx_alumni_verification` (`verification_status`),
  ADD KEY `idx_alumni_submission` (`submission_status`);

--
-- Indexes for table `alumni_academic`
--
ALTER TABLE `alumni_academic`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_academic_alumni` (`alumni_id`),
  ADD KEY `idx_academic_student` (`student_id`),
  ADD KEY `idx_academic_program` (`program_id`),
  ADD KEY `idx_academic_gradyear` (`graduation_year`);

--
-- Indexes for table `alumni_correction_requests`
--
ALTER TABLE `alumni_correction_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_corr_alumni` (`alumni_id`),
  ADD KEY `idx_corr_status` (`status`),
  ADD KEY `fk_corr_reviewer` (`reviewed_by`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_announcement_creator` (`created_by`);

--
-- Indexes for table `api_login_attempts`
--
ALTER TABLE `api_login_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lookup` (`identifier`,`ip_address`,`attempted_at`);

--
-- Indexes for table `api_tokens`
--
ALTER TABLE `api_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token_hash` (`token_hash`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_audit_user` (`user_id`),
  ADD KEY `idx_audit_module` (`module`,`record_id`),
  ADD KEY `idx_audit_created` (`created`);

--
-- Indexes for table `civil_statuses`
--
ALTER TABLE `civil_statuses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `competencies`
--
ALTER TABLE `competencies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `course_reasons`
--
ALTER TABLE `course_reasons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `curriculum_feedback`
--
ALTER TABLE `curriculum_feedback`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `survey_id` (`survey_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `department_name` (`department_name`);

--
-- Indexes for table `duration_ranges`
--
ALTER TABLE `duration_ranges`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `education_levels`
--
ALTER TABLE `education_levels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `level_name` (`level_name`);

--
-- Indexes for table `education_records`
--
ALTER TABLE `education_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_education_alumni` (`alumni_id`),
  ADD KEY `fk_education_level` (`education_level_id`);

--
-- Indexes for table `employment_reasons`
--
ALTER TABLE `employment_reasons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_reason` (`reason_type`,`name`);

--
-- Indexes for table `employment_records`
--
ALTER TABLE `employment_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_employment_alumni` (`alumni_id`),
  ADD KEY `fk_employment_status` (`employment_status_id`),
  ADD KEY `fk_employment_type` (`employment_type_id`),
  ADD KEY `fk_employment_industry` (`industry_id`),
  ADD KEY `fk_employment_level` (`job_level_id`),
  ADD KEY `fk_employment_salary` (`salary_range_id`),
  ADD KEY `fk_employment_method` (`search_method_id`),
  ADD KEY `fk_employment_timetojob` (`time_to_job_id`),
  ADD KEY `fk_employment_duration` (`duration_id`),
  ADD KEY `idx_employment_survey` (`survey_id`,`is_current`,`is_first_job`),
  ADD KEY `idx_employment_current` (`is_current`);

--
-- Indexes for table `employment_record_reasons`
--
ALTER TABLE `employment_record_reasons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_err` (`employment_record_id`,`employment_reason_id`),
  ADD KEY `fk_err_reason` (`employment_reason_id`);

--
-- Indexes for table `employment_statuses`
--
ALTER TABLE `employment_statuses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `status_name` (`status_name`);

--
-- Indexes for table `employment_types`
--
ALTER TABLE `employment_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_event_creator` (`created_by`),
  ADD KEY `idx_events_date` (`event_date`);

--
-- Indexes for table `event_registrations`
--
ALTER TABLE `event_registrations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_event_alumni` (`event_id`,`alumni_id`),
  ADD KEY `fk_registration_alumni` (`alumni_id`);

--
-- Indexes for table `industries`
--
ALTER TABLE `industries`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `job_levels`
--
ALTER TABLE `job_levels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `job_postings`
--
ALTER TABLE `job_postings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_job_creator` (`created_by`),
  ADD KEY `idx_jobs_status` (`status`);

--
-- Indexes for table `job_search_methods`
--
ALTER TABLE `job_search_methods`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `license_types`
--
ALTER TABLE `license_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `license_name` (`license_name`);

--
-- Indexes for table `licensure_records`
--
ALTER TABLE `licensure_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_licensure_alumni` (`alumni_id`),
  ADD KEY `fk_licensure_type` (`license_type_id`),
  ADD KEY `fk_licensure_status` (`status_id`);

--
-- Indexes for table `licensure_statuses`
--
ALTER TABLE `licensure_statuses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `status_name` (`status_name`);

--
-- Indexes for table `professional_examinations`
--
ALTER TABLE `professional_examinations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_exam_alumni` (`alumni_id`);

--
-- Indexes for table `programs`
--
ALTER TABLE `programs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `program_code` (`program_code`),
  ADD KEY `fk_programs_department` (`department_id`);

--
-- Indexes for table `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `residence_types`
--
ALTER TABLE `residence_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `salary_ranges`
--
ALTER TABLE `salary_ranges`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `survey_competencies`
--
ALTER TABLE `survey_competencies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_sc` (`survey_id`,`competency_id`),
  ADD KEY `fk_sc_competency` (`competency_id`);

--
-- Indexes for table `survey_course_reasons`
--
ALTER TABLE `survey_course_reasons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_scr` (`survey_id`,`course_reason_id`),
  ADD KEY `fk_scr_reason` (`course_reason_id`);

--
-- Indexes for table `survey_unemployment_reasons`
--
ALTER TABLE `survey_unemployment_reasons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_sur` (`survey_id`,`unemployment_reason_id`),
  ADD KEY `fk_sur_reason` (`unemployment_reason_id`);

--
-- Indexes for table `tracer_questions`
--
ALTER TABLE `tracer_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_question_study` (`tracer_study_id`);

--
-- Indexes for table `tracer_responses`
--
ALTER TABLE `tracer_responses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_response` (`tracer_question_id`,`alumni_id`),
  ADD KEY `fk_response_study` (`tracer_study_id`),
  ADD KEY `fk_response_alumni` (`alumni_id`);

--
-- Indexes for table `tracer_studies`
--
ALTER TABLE `tracer_studies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_tracer_creator` (`created_by`),
  ADD KEY `idx_studies_year` (`survey_year`);

--
-- Indexes for table `tracer_surveys`
--
ALTER TABLE `tracer_surveys`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_survey` (`tracer_study_id`,`alumni_id`),
  ADD KEY `fk_survey_alumni` (`alumni_id`),
  ADD KEY `idx_survey_status` (`status`,`employment_state`);

--
-- Indexes for table `training_records`
--
ALTER TABLE `training_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_training_alumni` (`alumni_id`);

--
-- Indexes for table `unemployment_reasons`
--
ALTER TABLE `unemployment_reasons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alumni`
--
ALTER TABLE `alumni`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `alumni_academic`
--
ALTER TABLE `alumni_academic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `alumni_correction_requests`
--
ALTER TABLE `alumni_correction_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `api_login_attempts`
--
ALTER TABLE `api_login_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `api_tokens`
--
ALTER TABLE `api_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `civil_statuses`
--
ALTER TABLE `civil_statuses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `competencies`
--
ALTER TABLE `competencies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `course_reasons`
--
ALTER TABLE `course_reasons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `curriculum_feedback`
--
ALTER TABLE `curriculum_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `duration_ranges`
--
ALTER TABLE `duration_ranges`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `education_levels`
--
ALTER TABLE `education_levels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `education_records`
--
ALTER TABLE `education_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employment_reasons`
--
ALTER TABLE `employment_reasons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `employment_records`
--
ALTER TABLE `employment_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `employment_record_reasons`
--
ALTER TABLE `employment_record_reasons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `employment_statuses`
--
ALTER TABLE `employment_statuses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `employment_types`
--
ALTER TABLE `employment_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `event_registrations`
--
ALTER TABLE `event_registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `industries`
--
ALTER TABLE `industries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `job_levels`
--
ALTER TABLE `job_levels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `job_postings`
--
ALTER TABLE `job_postings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `job_search_methods`
--
ALTER TABLE `job_search_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `license_types`
--
ALTER TABLE `license_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `licensure_records`
--
ALTER TABLE `licensure_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `licensure_statuses`
--
ALTER TABLE `licensure_statuses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `professional_examinations`
--
ALTER TABLE `professional_examinations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `programs`
--
ALTER TABLE `programs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `regions`
--
ALTER TABLE `regions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `residence_types`
--
ALTER TABLE `residence_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `salary_ranges`
--
ALTER TABLE `salary_ranges`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `survey_competencies`
--
ALTER TABLE `survey_competencies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `survey_course_reasons`
--
ALTER TABLE `survey_course_reasons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `survey_unemployment_reasons`
--
ALTER TABLE `survey_unemployment_reasons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tracer_questions`
--
ALTER TABLE `tracer_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tracer_responses`
--
ALTER TABLE `tracer_responses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tracer_studies`
--
ALTER TABLE `tracer_studies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tracer_surveys`
--
ALTER TABLE `tracer_surveys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `training_records`
--
ALTER TABLE `training_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `unemployment_reasons`
--
ALTER TABLE `unemployment_reasons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `alumni`
--
ALTER TABLE `alumni`
  ADD CONSTRAINT `fk_alumni_civil` FOREIGN KEY (`civil_status_id`) REFERENCES `civil_statuses` (`id`),
  ADD CONSTRAINT `fk_alumni_region` FOREIGN KEY (`region_id`) REFERENCES `regions` (`id`),
  ADD CONSTRAINT `fk_alumni_residence` FOREIGN KEY (`residence_type_id`) REFERENCES `residence_types` (`id`),
  ADD CONSTRAINT `fk_alumni_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `alumni_academic`
--
ALTER TABLE `alumni_academic`
  ADD CONSTRAINT `fk_academic_alumni` FOREIGN KEY (`alumni_id`) REFERENCES `alumni` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_academic_program` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`);

--
-- Constraints for table `alumni_correction_requests`
--
ALTER TABLE `alumni_correction_requests`
  ADD CONSTRAINT `fk_corr_alumni` FOREIGN KEY (`alumni_id`) REFERENCES `alumni` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_corr_reviewer` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `announcements`
--
ALTER TABLE `announcements`
  ADD CONSTRAINT `fk_announcement_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `api_tokens`
--
ALTER TABLE `api_tokens`
  ADD CONSTRAINT `api_tokens_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `curriculum_feedback`
--
ALTER TABLE `curriculum_feedback`
  ADD CONSTRAINT `fk_cf_survey` FOREIGN KEY (`survey_id`) REFERENCES `tracer_surveys` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `education_records`
--
ALTER TABLE `education_records`
  ADD CONSTRAINT `fk_education_alumni` FOREIGN KEY (`alumni_id`) REFERENCES `alumni` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_education_level` FOREIGN KEY (`education_level_id`) REFERENCES `education_levels` (`id`);

--
-- Constraints for table `employment_records`
--
ALTER TABLE `employment_records`
  ADD CONSTRAINT `fk_employment_alumni` FOREIGN KEY (`alumni_id`) REFERENCES `alumni` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_employment_duration` FOREIGN KEY (`duration_id`) REFERENCES `duration_ranges` (`id`),
  ADD CONSTRAINT `fk_employment_industry` FOREIGN KEY (`industry_id`) REFERENCES `industries` (`id`),
  ADD CONSTRAINT `fk_employment_level` FOREIGN KEY (`job_level_id`) REFERENCES `job_levels` (`id`),
  ADD CONSTRAINT `fk_employment_method` FOREIGN KEY (`search_method_id`) REFERENCES `job_search_methods` (`id`),
  ADD CONSTRAINT `fk_employment_salary` FOREIGN KEY (`salary_range_id`) REFERENCES `salary_ranges` (`id`),
  ADD CONSTRAINT `fk_employment_status` FOREIGN KEY (`employment_status_id`) REFERENCES `employment_statuses` (`id`),
  ADD CONSTRAINT `fk_employment_survey` FOREIGN KEY (`survey_id`) REFERENCES `tracer_surveys` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_employment_timetojob` FOREIGN KEY (`time_to_job_id`) REFERENCES `duration_ranges` (`id`),
  ADD CONSTRAINT `fk_employment_type` FOREIGN KEY (`employment_type_id`) REFERENCES `employment_types` (`id`);

--
-- Constraints for table `employment_record_reasons`
--
ALTER TABLE `employment_record_reasons`
  ADD CONSTRAINT `fk_err_reason` FOREIGN KEY (`employment_reason_id`) REFERENCES `employment_reasons` (`id`),
  ADD CONSTRAINT `fk_err_record` FOREIGN KEY (`employment_record_id`) REFERENCES `employment_records` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `fk_event_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `event_registrations`
--
ALTER TABLE `event_registrations`
  ADD CONSTRAINT `fk_registration_alumni` FOREIGN KEY (`alumni_id`) REFERENCES `alumni` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_registration_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `job_postings`
--
ALTER TABLE `job_postings`
  ADD CONSTRAINT `fk_job_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `licensure_records`
--
ALTER TABLE `licensure_records`
  ADD CONSTRAINT `fk_licensure_alumni` FOREIGN KEY (`alumni_id`) REFERENCES `alumni` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_licensure_status` FOREIGN KEY (`status_id`) REFERENCES `licensure_statuses` (`id`),
  ADD CONSTRAINT `fk_licensure_type` FOREIGN KEY (`license_type_id`) REFERENCES `license_types` (`id`);

--
-- Constraints for table `professional_examinations`
--
ALTER TABLE `professional_examinations`
  ADD CONSTRAINT `fk_exam_alumni` FOREIGN KEY (`alumni_id`) REFERENCES `alumni` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `programs`
--
ALTER TABLE `programs`
  ADD CONSTRAINT `fk_programs_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`);

--
-- Constraints for table `survey_competencies`
--
ALTER TABLE `survey_competencies`
  ADD CONSTRAINT `fk_sc_competency` FOREIGN KEY (`competency_id`) REFERENCES `competencies` (`id`),
  ADD CONSTRAINT `fk_sc_survey` FOREIGN KEY (`survey_id`) REFERENCES `tracer_surveys` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `survey_course_reasons`
--
ALTER TABLE `survey_course_reasons`
  ADD CONSTRAINT `fk_scr_reason` FOREIGN KEY (`course_reason_id`) REFERENCES `course_reasons` (`id`),
  ADD CONSTRAINT `fk_scr_survey` FOREIGN KEY (`survey_id`) REFERENCES `tracer_surveys` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `survey_unemployment_reasons`
--
ALTER TABLE `survey_unemployment_reasons`
  ADD CONSTRAINT `fk_sur_reason` FOREIGN KEY (`unemployment_reason_id`) REFERENCES `unemployment_reasons` (`id`),
  ADD CONSTRAINT `fk_sur_survey` FOREIGN KEY (`survey_id`) REFERENCES `tracer_surveys` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tracer_questions`
--
ALTER TABLE `tracer_questions`
  ADD CONSTRAINT `fk_question_study` FOREIGN KEY (`tracer_study_id`) REFERENCES `tracer_studies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tracer_responses`
--
ALTER TABLE `tracer_responses`
  ADD CONSTRAINT `fk_response_alumni` FOREIGN KEY (`alumni_id`) REFERENCES `alumni` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_response_question` FOREIGN KEY (`tracer_question_id`) REFERENCES `tracer_questions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_response_study` FOREIGN KEY (`tracer_study_id`) REFERENCES `tracer_studies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tracer_studies`
--
ALTER TABLE `tracer_studies`
  ADD CONSTRAINT `fk_tracer_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `tracer_surveys`
--
ALTER TABLE `tracer_surveys`
  ADD CONSTRAINT `fk_survey_alumni` FOREIGN KEY (`alumni_id`) REFERENCES `alumni` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_survey_study` FOREIGN KEY (`tracer_study_id`) REFERENCES `tracer_studies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `training_records`
--
ALTER TABLE `training_records`
  ADD CONSTRAINT `fk_training_alumni` FOREIGN KEY (`alumni_id`) REFERENCES `alumni` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
