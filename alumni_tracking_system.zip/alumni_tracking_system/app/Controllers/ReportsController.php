<?php

namespace Controllers;

use Models\Lookups;
use Models\Reports;
use Models\Users;
use Core\BaseController;

class ReportsController extends BaseController
{
    public function __construct()
    {
        require_role(Users::ADMIN, Users::FACULTY, Users::QA);
    }

    public function index()
    {
        foreach (Reports::pageTypes() as $key => $config) {
            if (has_role(...$config['roles'])) {
                $this->redirect(BASE_URL . '/Reports/' . $key);
            }
        }
        $this->redirect(BASE_URL . '/Dashboard');
    }

    public function alumni()     { $this->show('alumni'); }
    public function tracer()     { $this->show('tracer'); }
    public function program()    { $this->show('program'); }
    public function engagement() { $this->engagementPage(); }

    private function show(string $type): void
    {
        $config = Reports::configFor($type, user_role());
        require_role(...$config['roles']);

        $Lookups = new Lookups();
        $lookups = [];

        if (in_array('program_id', $config['filters'], true)) {
            $lookups['programs'] = $Lookups->programs();
        }
        if (in_array('graduation_year', $config['filters'], true)) {
            $lookups['graduationYears'] = $Lookups->graduationYears();
        }
        if (in_array('employment_status_id', $config['filters'], true)) {
            $lookups['employmentStatuses'] = $Lookups->employmentStatuses();
        }
        if (in_array('licensure_status_id', $config['filters'], true)) {
            $lookups['licensureStatuses'] = $Lookups->licensureStatuses();
        }
        if (in_array('province', $config['filters'], true)) {
            $lookups['provinces'] = $Lookups->provinces();
        }

        $columns = [];
        foreach ($config['columns'] as $field => $label) {
            $columns[] = [
                'data'    => $field,
                'title'   => $label,
                'visible' => !in_array($field, $config['hidden'] ?? [], true),
            ];
        }

        $this->view('Reports/index', [
            'title'    => $config['title'],
            'script'   => 'Reports',
            'type'     => $type,
            'config'   => $config,
            'lookups'  => $lookups,
            'pageData' => ['type' => $type, 'title' => $config['title'], 'columns' => $columns],
        ]);
    }

    private function engagementPage(): void
    {
        $config = Reports::TYPES['engagement'];
        require_role(...$config['roles']);

        $Lookups = new Lookups();
        $columns = [];
        foreach ($config['columns'] as $field => $label) {
            $columns[] = ['data' => $field, 'title' => $label];
        }

        $Reports = new Reports();

        $this->view('Reports/engagement', [
            'title'    => $config['title'],
            'script'   => 'ReportsEngagement',
            'summary'  => $Reports->attendanceSummary(),
            'programs' => $Lookups->programs(),
            'years'    => $Lookups->graduationYears(),
            'events'   => $Lookups->events(),
            'levels'   => Reports::ENGAGEMENT_LEVELS,
            'pageData' => ['title' => $config['title'], 'overviewColumns' => $columns],
        ]);
    }
}
