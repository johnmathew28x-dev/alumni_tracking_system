<?php

namespace Controllers;

use Models\Announcements;
use Models\Users;
use Core\BaseController;

class AnnouncementsController extends BaseController
{
    public function __construct()
    {
        require_role(Users::ADMIN, Users::ALUMNI);
    }

    public function index()
    {
        if (has_role(Users::ADMIN)) {
            $this->view('Announcements/index', [
                'title'  => 'Announcements',
                'script' => 'Announcements',
            ]);
            return;
        }

        $this->view('Announcements/browse', [
            'title'         => 'Announcements',
            'announcements' => (new Announcements())->published(),
        ]);
    }
}
