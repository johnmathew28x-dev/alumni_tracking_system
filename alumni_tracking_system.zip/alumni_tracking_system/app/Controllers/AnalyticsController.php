<?php

namespace Controllers;

use Models\AiAnalytics;
use Models\Lookups;
use Models\Users;
use Core\BaseController;

class AnalyticsController extends BaseController
{
    public function __construct()
    {
        require_role(Users::ADMIN, Users::FACULTY, Users::QA);
    }

    public function index()
    {
        $L = new Lookups();

        $this->view('Analytics/index', [
            'title'    => 'Graduate Tracer Analytics',
            'script'   => ['Analytics', 'AnalyticsAi'],
            'charts'   => true,
            'L'        => $L,
            'pageData' => [
                'canExport' => has_role(Users::ADMIN, Users::QA),
                'ai'        => AiAnalytics::status() + ['isAdmin' => has_role(Users::ADMIN)],
            ],
        ]);
    }
}
