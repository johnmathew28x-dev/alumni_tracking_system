<?php

namespace Controllers;

use Models\Academics;
use Models\Alumni;
use Models\Educations;
use Models\Employments;
use Models\Licensures;
use Models\Trainings;
use Models\Lookups;
use Models\Users;
use Core\BaseController;

class AlumniController extends BaseController
{
    public function __construct()
    {
        require_role(Users::ADMIN, Users::FACULTY);
    }

    public function index()
    {
        $this->renderList('All Alumni', '');
    }

    public function pending()
    {
        $this->renderList('Pending Verification', 'pending');
    }

    private function renderList(string $title, string $status): void
    {
        $this->view('Alumni/index', [
            'title'    => $title,
            'script'   => has_role(Users::ADMIN) && $status === 'pending' ? ['Alumni', 'Corrections'] : 'Alumni',
            'programs' => (new Lookups())->programs(),
            'years'    => (new Lookups())->graduationYears(),
            'employmentStatuses' => (new Lookups())->employmentStatuses(),
            'licensureStatuses'  => has_role(Users::ADMIN) ? (new Lookups())->licensureStatuses() : [],
            'provinces' => (new Lookups())->provinces(),
            'status'   => $status,
            'canEdit'  => has_role(Users::ADMIN),
            'pageData' => ['status' => $status, 'canEdit' => has_role(Users::ADMIN)],
        ]);
    }

    public function details($id = null)
    {
        $Alumni = new Alumni();
        $alumni = $id ? $Alumni->details($id) : null;

        if (!$alumni) {
            http_response_code(404);
            exit('Alumni record not found.');
        }

        $this->view('Alumni/details', [
            'title'       => 'Alumni Profile',
            'script'      => 'AlumniDetails',
            'alumni'      => $alumni,
            'pictureUrl'  => avatar_url($alumni->profile_picture),
            'academics'   => (new Academics())->forAlumni($alumni->id),
            'educations'  => (new Educations())->forAlumni($alumni->id),
            'employments' => (new Employments())->forAlumni($alumni->id),
            'licensures'  => (new Licensures())->forAlumni($alumni->id),
            'trainings'   => (new Trainings())->forAlumni($alumni->id),
            'canVerify'   => has_role(Users::ADMIN),
            'pageData'    => ['alumniId' => (int) $alumni->id],
        ]);
    }
}
