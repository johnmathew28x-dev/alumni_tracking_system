<?php

namespace Controllers;

use Core\Auth;
use Models\Alumni;
use Models\Lookups;
use Models\Users;
use Core\BaseController;

class AuthController extends BaseController
{
    private const MAX_ATTEMPTS = 5;
    private const LOCK_SECONDS = 60;

    private $Users;

    public function __construct()
    {
        $this->Users = new Users();
    }

    public function index()
    {
        if (Auth::check()) {
            $this->redirect(BASE_URL . '/Dashboard');
        }

        if ($this->Users->count() === 0) {
            $this->redirect(BASE_URL . '/Users/register');
        }

        $this->view('Auth/login', ['title' => 'Login'], 'auth');
    }

    public function login()
    {
        if (!is_post()) {
            $this->redirect(BASE_URL . '/Auth');
        }

        verify_csrf();

        if (($_SESSION['login_locked_until'] ?? 0) > time()) {
            $_SESSION['error'] = 'Too many failed attempts. Please wait a minute and try again.';
            $this->redirect(BASE_URL . '/Auth');
        }

        $identifier = trim($_POST['username'] ?? '');
        $password   = $_POST['password'] ?? '';

        $user = $identifier !== '' ? $this->Users->findByLogin($identifier) : null;

        if (!$user || !password_verify($password, $user->password)) {
            $_SESSION['login_attempts'] = ($_SESSION['login_attempts'] ?? 0) + 1;

            if ($_SESSION['login_attempts'] >= self::MAX_ATTEMPTS) {
                $_SESSION['login_locked_until'] = time() + self::LOCK_SECONDS;
                $_SESSION['login_attempts'] = 0;
            }

            $_SESSION['error'] = 'Invalid username or password.';
            $this->redirect(BASE_URL . '/Auth');
        }

        if ($user->status !== 'active') {
            $_SESSION['error'] = 'Your account is inactive. Please contact the administrator.';
            $this->redirect(BASE_URL . '/Auth');
        }

        unset($_SESSION['login_attempts'], $_SESSION['login_locked_until']);

        login_user([
            'id'       => $user->id,
            'username' => $user->username,
            'role'     => $user->role,
        ]);

        audit('LOGIN', $user->role . ' logged in.');
        $this->redirect(BASE_URL . '/Dashboard');
    }

    public function register()
    {
        if (Auth::check()) {
            $this->redirect(BASE_URL . '/Dashboard');
        }

        $Lookups = new Lookups();
        $old = [];
        $error = null;

        if (is_post()) {
            verify_csrf();
            $d = array_map(fn($v) => is_string($v) ? trim($v) : $v, $_POST);
            $old = $d;
            $g = fn($k) => $d[$k] ?? '';

            if ($g('first_name') === '' || $g('last_name') === '' || $g('username') === '') {
                $error = 'First name, last name and username are required.';
            } elseif (!filter_var($g('email'), FILTER_VALIDATE_EMAIL)) {
                $error = 'Please enter a valid email address.';
            } elseif (strlen($g('password')) < 8) {
                $error = 'Password must be at least 8 characters.';
            } elseif ($g('password') !== $g('confirm_password')) {
                $error = 'Passwords do not match.';
            } elseif ($g('program_id') === '' || $g('graduation_year') === '') {
                $error = 'Please select your program and graduation year.';
            } elseif ((int) $g('graduation_year') < 1950 || (int) $g('graduation_year') > (int) date('Y') + 6) {
                $error = 'Please enter a valid graduation year.';
            } elseif ($this->Users->usernameExists($g('username'))) {
                $error = 'Username is already taken.';
            } elseif ($this->Users->emailExists($g('email'))) {
                $error = 'Email is already registered.';
            }

            if (!$error) {
                $saved = $this->Users->createUser(
                    [
                        'username' => $g('username'),
                        'email'    => $g('email'),
                        'password' => $g('password'),
                        'role'     => Users::ALUMNI,
                        'status'   => 'active',
                    ],
                    [
                        'first_name'          => $g('first_name'),
                        'last_name'           => $g('last_name'),
                        'email'               => $g('email'),
                        'verification_status' => 'pending',
                    ],
                    [
                        'program_id'      => $g('program_id'),
                        'graduation_year' => $g('graduation_year'),
                    ]
                );

                if ($saved) {
                    $_SESSION['success'] = 'Registration successful! You can now log in. An administrator will verify your alumni record.';
                    $this->redirect(BASE_URL . '/Auth');
                }

                $error = 'Registration failed. Please try again.';
            }
        }

        $this->view('Auth/register', [
            'title'    => 'Alumni Registration',
            'programs' => $Lookups->programs(),
            'old'      => $old,
            'error'    => $error,
        ], 'auth');
    }

    public function logout()
    {
        if (is_post()) {
            verify_csrf();

            if (Auth::check()) {
                audit('LOGOUT', user_role() . ' logged out.');
            }

            $_SESSION = [];
            session_destroy();
        }

        $this->redirect(BASE_URL . '/Auth');
    }
}
