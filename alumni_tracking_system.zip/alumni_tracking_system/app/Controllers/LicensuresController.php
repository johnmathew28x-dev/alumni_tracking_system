<?php

namespace Controllers;

use Models\Lookups;
use Models\Users;
use Core\BaseController;

class LicensuresController extends BaseController
{
    public function __construct()
    {
        require_role(Users::ALUMNI);
    }

    public function index()
    {
        $this->view('Licensures/index', [
            'title'   => 'Licensure Records',
            'script'  => ['Licensures', 'Exams'],
            'lookups' => new Lookups(),
        ]);
    }
}
