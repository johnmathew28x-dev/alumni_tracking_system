<?php

namespace Controllers;

use Models\Jobs;
use Models\Users;
use Core\BaseController;

class JobsController extends BaseController
{
    public function __construct()
    {
        require_role(Users::ADMIN, Users::ALUMNI);
    }

    public function index()
    {
        if (has_role(Users::ADMIN)) {
            $this->view('Jobs/index', [
                'title'  => 'Job Postings',
                'script' => 'Jobs',
            ]);
            return;
        }

        $this->view('Jobs/browse', [
            'title' => 'Job Opportunities',
            'jobs'  => (new Jobs())->open(),
        ]);
    }
}
