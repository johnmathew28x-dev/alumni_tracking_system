<?php

namespace Controllers;

use Models\Lookups;
use Models\Users;
use Core\BaseController;

class EmploymentsController extends BaseController
{
    public function __construct()
    {
        require_role(Users::ALUMNI);
    }

    public function index()
    {
        $this->view('Employments/index', [
            'title'   => 'Employment Records',
            'script'  => 'Employments',
            'lookups' => new Lookups(),
        ]);
    }
}
