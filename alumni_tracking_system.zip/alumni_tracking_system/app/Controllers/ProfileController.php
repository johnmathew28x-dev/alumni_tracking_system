<?php

namespace Controllers;

use Core\Auth;
use Models\Alumni;
use Models\CorrectionRequests;
use Models\Lookups;
use Models\Profiles;
use Models\Users;
use Core\BaseController;

class ProfileController extends BaseController
{
    public function __construct()
    {
        Auth::requireLogin();
    }

    public function index()
    {
        $isAlumni = has_role(Users::ALUMNI);
        $alumni = null;

        if ($isAlumni) {
            $alumni = (new Alumni())->findByUserID(user_id());

            if (!$alumni) {
                $_SESSION['error'] = 'Your alumni profile could not be found. Please contact the administrator.';
                $this->redirect(BASE_URL . '/Dashboard');
            }
        }

        $locked      = $alumni ? Alumni::isLocked($alumni) : false;
        $corrections = $alumni ? (new CorrectionRequests())->forAlumni((int) $alumni->id) : [];

        $this->view('Profile/index', [
            'title'    => 'My Profile',
            'locked'      => $locked,
            'corrections' => $corrections,
            'script'   => 'Profile',
            'profile'  => (new Profiles())->forUser((int) user_id()),
            'alumni'   => $alumni,
            'account'  => (new Users())->findByID(user_id()),
            'lookups'  => new Lookups(),
            'pageData' => ['isAlumni' => $isAlumni, 'locked' => $locked, 'maxBytes' => PROFILE_UPLOAD_MAX_BYTES],
        ]);
    }

    public function settings()
    {
        $this->view('Profile/settings', [
            'title'   => 'Account Settings',
            'script'  => 'Settings',
            'profile' => (new Profiles())->forUser((int) user_id()),
        ]);
    }
}
