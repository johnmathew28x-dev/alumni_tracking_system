<?php

namespace Controllers;

use Core\Auth;
use Models\Alumni;
use Models\Announcements;
use Models\Events;
use Models\GtsReports;
use Models\Jobs;
use Models\TracerResponses;
use Models\TracerStudies;
use Models\Users;
use Core\BaseController;

class DashboardController extends BaseController
{
    public function __construct()
    {
        Auth::requireLogin();
    }

    public function index()
    {
        $Alumni = new Alumni();

        switch (user_role()) {
            case Users::ALUMNI:
                $me = $Alumni->findByUserID(user_id());
                $Events = new Events();

                $this->view('Dashboard/alumni', [
                    'title'         => 'Dashboard',
                    'me'            => $me,
                    'attendance'    => $Events->attendanceFor($me->id ?? 0),
                    'attended'      => array_slice($Events->attendedBy($me->id ?? 0), 0, 5),
                    'announcements' => array_slice((new Announcements())->published(), 0, 3),
                    'events'        => array_slice((new Events())->upcoming($me->id ?? 0), 0, 3),
                    'studies'       => (new TracerStudies())->active($me->id ?? 0),
                ]);
                return;

            case Users::ADMIN:
                $pending = $Alumni->find(['verification_status' => 'pending']);

                $this->view('Dashboard/admin', [
                    'title' => 'Dashboard',
                    'stats' => [
                        'total'      => $Alumni->countTotal(),
                        'pending'    => $Alumni->countByVerification('pending'),
                        'employed'   => $Alumni->countEmployed(),
                        'unemployed' => $Alumni->countUnemployed(),
                        'let'        => $Alumni->countLetPassers(),
                        'events'     => (new Events())->upcomingCount(),
                        'jobs'       => (new Jobs())->openCount(),
                        'responses'  => (new TracerResponses())->countActiveRespondents(),
                    ],
                    'gts'           => (new GtsReports())->summary([]),
                    'pending'       => array_slice($pending, 0, 5),
                    'announcements' => array_slice((new Announcements())->published(), 0, 3),
                ]);
                return;

            default:
                $this->view('Dashboard/staff', [
                    'title' => 'Dashboard',
                    'gts'   => (new GtsReports())->summary([]),
                    'stats' => [
                        'total'      => $Alumni->countTotal(),
                        'verified'   => $Alumni->countByVerification('verified'),
                        'employed'   => $Alumni->countEmployed(),
                        'let'        => $Alumni->countLetPassers(),
                    ],
                ]);
        }
    }
}
