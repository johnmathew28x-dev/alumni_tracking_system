<?php

namespace Controllers;

use Models\Lookups;
use Models\Users;
use Core\BaseController;

class AcademicsController extends BaseController
{
    public function __construct()
    {
        require_role(Users::ALUMNI);
    }

    public function index()
    {
        $this->view('Academics/index', [
            'title'   => 'My Academic Information',
            'script'  => 'Academics',
            'lookups' => new Lookups(),
        ]);
    }
}
