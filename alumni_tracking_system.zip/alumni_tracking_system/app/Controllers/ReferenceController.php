<?php

namespace Controllers;

use Models\Lookups;
use Models\Reference;
use Models\Users;
use Core\BaseController;

class ReferenceController extends BaseController
{
    public function __construct()
    {
        require_role(Users::ADMIN);
    }

    public function index()
    {
        $this->view('Reference/index', [
            'title'       => 'Reference Data',
            'script'      => 'Reference',
            'tables'      => Reference::TABLES,
            'departments' => (new Lookups())->departments(),
            'pageData'    => ['tables' => Reference::TABLES, 'current' => $_GET['t'] ?? 'programs'],
        ]);
    }
}
