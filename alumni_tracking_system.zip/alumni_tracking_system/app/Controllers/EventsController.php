<?php

namespace Controllers;

use Models\Alumni;
use Models\Events;
use Models\Users;
use Core\BaseController;

class EventsController extends BaseController
{
    public function __construct()
    {
        require_role(Users::ADMIN, Users::ALUMNI);
    }

    public function index()
    {
        if (has_role(Users::ADMIN)) {
            $this->view('Events/index', [
                'title'  => 'Events',
                'script' => 'Events',
            ]);
            return;
        }

        $me = (new Alumni())->findByUserID(user_id());

        $this->view('Events/browse', [
            'title'  => 'Events',
            'script' => 'EventsBrowse',
            'events' => (new Events())->upcoming($me->id ?? 0),
        ]);
    }
}
