<?php

namespace Controllers;

use Core\BaseController;
use Models\Lookups;
use Models\Users;

class TrainingsController extends BaseController
{
    public function __construct()
    {
        require_role(Users::ALUMNI);
    }

    public function index()
    {
        $this->view('Trainings/index', [
            'title'   => 'Trainings / Advanced Studies',
            'script'  => 'Trainings',
            'lookups' => new Lookups(),
        ]);
    }
}
