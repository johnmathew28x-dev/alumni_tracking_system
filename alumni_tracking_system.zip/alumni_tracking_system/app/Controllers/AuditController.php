<?php

namespace Controllers;

use Models\Users;
use Core\BaseController;


class AuditController extends BaseController
{
    public function index()
    {
        require_role(Users::ADMIN);

        $this->view('Audit/index', [
            'title'  => 'Audit Logs',
            'script' => 'Audit',
        ]);
    }
}
