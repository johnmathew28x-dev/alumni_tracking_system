<?php

namespace Controllers;

use Models\Users;
use Core\BaseController;

class UsersController extends BaseController
{
    public function index()
    {
        require_role(Users::ADMIN);

        $this->view('Users/index', [
            'title'  => 'Users',
            'script' => 'Users',
            'roles'  => Users::ROLES,
        ]);
    }

    public function register()
    {
        $Users = new Users();

        if ($Users->count() > 0) {
            $this->redirect(BASE_URL . '/Auth');
        }

        $error = null;
        $old = [];

        if (is_post()) {
            verify_csrf();
            $username = trim($_POST['username'] ?? '');
            $email    = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $old = ['username' => $username, 'email' => $email];

            if ($username === '') {
                $error = 'Username is required.';
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = 'Please enter a valid email address.';
            } elseif (strlen($password) < 8) {
                $error = 'Password must be at least 8 characters.';
            } elseif ($password !== ($_POST['confirm_password'] ?? '')) {
                $error = 'Passwords do not match.';
            } else {
                $Users->save([
                    'username' => $username,
                    'email'    => $email,
                    'password' => $password,
                    'role'     => Users::ADMIN,
                    'status'   => 'active',
                ]);

                $_SESSION['success'] = 'Administrator account created. You can now log in.';
                $this->redirect(BASE_URL . '/Auth');
            }
        }

        $this->view('Users/register', [
            'title' => 'Create Administrator',
            'error' => $error,
            'old'   => $old,
        ], 'auth');
    }
}
