<?php

namespace Controllers;

use Models\Alumni;
use Models\Gts;
use Models\Lookups;
use Models\TracerQuestions;
use Models\TracerResponses;
use Models\TracerStudies;
use Models\Users;
use Core\BaseController;

class TracerController extends BaseController
{
    public function __construct()
    {
        require_role(Users::ADMIN, Users::ALUMNI);
    }

    public function index()
    {
        if (has_role(Users::ADMIN)) {
            $this->view('Tracer/index', [
                'title'  => 'Tracer Studies',
                'script' => 'Tracer',
            ]);
            return;
        }

        $me = (new Alumni())->findByUserID(user_id());

        $this->view('Tracer/browse', [
            'title'   => 'Tracer Study',
            'studies' => (new TracerStudies())->active($me->id ?? 0),
        ]);
    }

    public function questions($id = null)
    {
        require_role(Users::ADMIN);
        $study = $id ? (new TracerStudies())->findByID($id) : null;

        if (!$study) {
            http_response_code(404);
            exit('Tracer study not found.');
        }

        $this->view('Tracer/questions', [
            'title'    => 'Study Questions',
            'script'   => 'TracerQuestions',
            'study'    => $study,
            'pageData' => ['studyId' => (int) $study->id],
        ]);
    }

    public function responses()
    {
        require_role(Users::ADMIN);

        $this->view('Tracer/responses', [
            'title'   => 'Tracer Study Responses',
            'studies' => (new TracerStudies())->find(),
        ]);
    }

    public function stats($id = null)
    {
        require_role(Users::ADMIN);
        $Studies = new TracerStudies();
        $study = $id ? $Studies->findByID($id) : null;

        if (!$study) {
            http_response_code(404);
            exit('Tracer study not found.');
        }

        $Responses = new TracerResponses();
        $questions = (new TracerQuestions())->forStudy($study->id);

        foreach ($questions as $q) {
            $q->breakdown = $Responses->breakdown($q->id);
            $q->total     = array_sum(array_map(fn($b) => (int) $b->total, $q->breakdown));
        }

        $this->view('Tracer/stats', [
            'title'       => 'Study Statistics',
            'study'       => $study,
            'questions'   => $questions,
            'respondents' => $Responses->countRespondents($study->id),
        ]);
    }

    public function answer($id = null)
    {
        require_role(Users::ALUMNI);

        $me = (new Alumni())->findByUserID(user_id());
        $study = $id ? (new TracerStudies())->findByID($id) : null;

        if (!$me || !$study || $study->status !== 'active') {
            $_SESSION['error'] = 'That tracer study is not available.';
            $this->redirect(BASE_URL . '/Tracer');
        }

        if ($study->survey_type === 'gts') {
            $this->redirect(BASE_URL . '/Tracer/gts/' . (int) $study->id);
        }

        $this->view('Tracer/answer', [
            'title'     => 'Tracer Study',
            'script'    => 'TracerAnswer',
            'study'     => $study,
            'questions' => (new TracerQuestions())->forStudy($study->id),
            'existing'  => (new TracerResponses())->forStudyAndAlumni($study->id, $me->id),
        ]);
    }

    public function gts($id = null)
    {
        require_role(Users::ALUMNI);

        $me    = (new Alumni())->findByUserID(user_id());
        $study = $id ? (new TracerStudies())->findByID((int) $id) : null;

        if (!$me || !$study || $study->survey_type !== 'gts') {
            $_SESSION['error'] = 'That survey is not available.';
            $this->redirect(BASE_URL . '/Tracer');
        }

        $Gts    = new Gts();
        $survey = $study->status === 'active'
            ? $Gts->ensureSurvey((int) $study->id, (int) $me->id)
            : $Gts->findSurvey((int) $study->id, (int) $me->id);

        if (!$survey) {
            $_SESSION['error'] = 'That survey is closed and you have no saved response.';
            $this->redirect(BASE_URL . '/Tracer');
        }

        $L = new Lookups();

        $this->view('Tracer/gts', [
            'title'    => 'Graduate Tracer Survey',
            'script'   => 'Gts',
            'study'    => $study,
            'L'        => $L,
            'pageData' => [
                'studyId'  => (int) $study->id,
                'editable' => $Gts->isEditable($survey, $study),
                'sections' => Gts::SECTIONS,
                'data'     => $Gts->load($survey),
            ],
        ]);
    }

    public function gtsResponses()
    {
        require_role(Users::ADMIN);
        $L = new Lookups();

        $this->view('Tracer/gtsResponses', [
            'title'    => 'Graduate Tracer Survey Responses',
            'script'   => 'GtsResponses',
            'programs' => $L->programs(),
            'studies'  => $L->gtsStudies(),
            'years'    => $L->graduationYears(),
            'pageData' => ['studyId' => (int) ($_GET['study_id'] ?? 0)],
        ]);
    }
}
