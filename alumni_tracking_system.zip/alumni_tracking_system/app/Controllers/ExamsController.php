<?php

namespace Controllers;

use Models\Users;
use Core\BaseController;


class ExamsController extends BaseController
{
    public function __construct()
    {
        require_role(Users::ALUMNI);
    }

    public function index()
    {
        $this->redirect(BASE_URL . '/Licensures');
    }
}
