<?php

namespace Api\Events;

use Core\BaseController;
use Models\Events;
use Models\Users;

class EventsController extends BaseController
{
    private $Events;

    public function __construct()
    {
        api_guard();
        $this->Events = new Events();
    }

    public function all()
    {
        api_allow(Users::ADMIN);

        $this->json([
            'data' => $this->Events->find()
        ]);
    }

    public function add()
    {
        api_allow(Users::ADMIN);
        $this->persist(null);
    }

    public function edit($id = null)
    {
        api_allow(Users::ADMIN);
        $event = $this->Events->findByID($id);

        if (!$event) {
            api_deny(404, 'Event not found.');
        }

        if (is_post()) {
            $this->persist($event->id);
        }

        $this->json($event);
    }

    public function delete($id = null)
    {
        api_allow(Users::ADMIN);

        if (empty($id)) {
            $this->json(api_error('Event ID is required.'));
        }

        if ($this->Events->delete($id)) {
            audit('DELETE_EVENT', "Deleted event #{$id}");
            $this->json(api_success('Event deleted successfully.'));
        }

        $this->json(api_error('Unable to delete event.'));
    }

    public function participants($id = null)
    {
        api_allow(Users::ADMIN);

        $this->json([
            'data' => $this->Events->participants($id)
        ]);
    }

    public function attendance($registrationId = null)
    {
        api_allow(Users::ADMIN);

        $status = $_POST['status'] ?? '';
        if (!in_array($status, ['attended', 'registered'], true)) {
            $this->json(api_error('Invalid attendance status.'));
        }

        $registration = $registrationId ? $this->Events->findRegistrationByID($registrationId) : null;
        if (!$registration) {
            api_deny(404, 'Registration not found.');
        }

        if ($registration->registration_status === 'cancelled') {
            $this->json(api_error('This registration was cancelled, so attendance cannot be recorded.'));
        }

        if (!in_array($registration->event_status, ['ongoing', 'completed'], true)) {
            $this->json(api_error('Attendance can only be recorded once the event is ongoing or completed.'));
        }

        $this->Events->setAttendance($registration->id, $status);
        audit('EVENT_ATTENDANCE', "Set registration #{$registration->id} (event #{$registration->event_id}) to {$status}", 'events', (int) $registration->event_id);
        $this->json(api_success($status === 'attended' ? 'Marked as attended.' : 'Attendance removed.'));
    }

    public function register($id = null)
    {
        api_allow(Users::ALUMNI);
        $alumniId = require_alumni_id();

        $event = $id ? $this->Events->findByID($id) : null;
        if (!$event) {
            api_deny(404, 'Event not found.');
        }

        if (!in_array($event->status, ['upcoming', 'ongoing'], true)) {
            $this->json(api_error('Registration is closed for this event.'));
        }

        if ($event->registration_deadline && strtotime($event->registration_deadline) < strtotime('today')) {
            $this->json(api_error('The registration deadline for this event has passed.'));
        }

        $existing = $this->Events->findRegistration($event->id, $alumniId);
        if ($existing && in_array($existing->registration_status, ['registered', 'attended'], true)) {
            $this->json(api_error('You are already registered for this event.'));
        }

        $this->Events->register($event->id, $alumniId);

        audit('EVENT_REGISTER', "Alumni registered for event #{$event->id}");
        $this->json(api_success('You are now registered for this event.'));
    }

    public function cancel($id = null)
    {
        api_allow(Users::ALUMNI);
        $alumniId = require_alumni_id();

        $existing = $id ? $this->Events->findRegistration($id, $alumniId) : null;
        if (!$existing || $existing->registration_status !== 'registered') {
            api_deny(404, 'You are not registered for this event.');
        }

        $this->Events->cancelRegistration($id, $alumniId);

        audit('EVENT_CANCEL', "Alumni cancelled registration for event #{$id}");
        $this->json(api_success('Your registration has been cancelled.'));
    }

    private function persist($id): void
    {
        $d = input();

        if (empty($d['title']) || empty($d['event_date'])) {
            $this->json(api_error('Title and event date are required.'));
        }

        $status = in_array($d['status'] ?? '', ['upcoming', 'ongoing', 'completed', 'cancelled'], true)
            ? $d['status'] : 'upcoming';

        $row = [
            'title'                 => $d['title'],
            'description'           => $d['description'] ?: null,
            'event_date'            => $d['event_date'],
            'event_time'            => $d['event_time'] ?: null,
            'location'              => $d['location'] ?: null,
            'registration_deadline' => $d['registration_deadline'] ?: null,
            'status'                => $status,
        ];

        if ($id) {
            $row['id'] = $id;
        } else {
            $row['created_by'] = user_id();
        }

        if ($this->Events->save($row)) {
            audit($id ? 'UPDATE_EVENT' : 'CREATE_EVENT', ($id ? 'Updated' : 'Created') . ' event: ' . $d['title']);
            $this->json(api_success($id ? 'Event updated successfully.' : 'Event added successfully.'));
        }

        $this->json(api_error('Unable to save event.'));
    }
}