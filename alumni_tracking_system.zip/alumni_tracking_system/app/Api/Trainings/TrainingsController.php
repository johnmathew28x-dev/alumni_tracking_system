<?php

namespace Api\Trainings;

use Core\BaseController;
use Models\Trainings;
use Models\Users;

class TrainingsController extends BaseController
{
    private $Trainings;

    public function __construct()
    {
        api_guard([Users::ALUMNI]);
        $this->Trainings = new Trainings();
    }

    public function all()
    {
        $this->json(['data' => $this->Trainings->forAlumni(require_alumni_id())]);
    }

    public function add()
    {
        $this->save(null);
    }

    public function edit(?int $id = null)
    {
        $record = $this->ownRecord($id);

        if (is_post()) {
            $this->save((int) $record->id);
        }

        $this->json($record);
    }

    public function delete(?int $id = null)
    {
        $record = $this->ownRecord($id);

        if ($this->Trainings->delete($record->id)) {
            audit('DELETE_TRAINING', 'Alumni deleted a training record.');
            $this->json(api_success('Training record deleted successfully.'));
        }

        $this->json(api_error('Unable to delete training record.'));
    }

    private function ownRecord(?int $id)
    {
        $record = $id ? $this->Trainings->findByID($id) : null;

        if (!$record || (int) $record->alumni_id !== require_alumni_id()) {
            api_deny(404, 'Training record not found.');
        }

        return $record;
    }

    private function save(?int $id): void
    {
        $d = input();

        if ($msg = $this->validate($d)) {
            $this->json(api_error($msg));
        }

        $data = $this->fields($d);
        $data['alumni_id'] = require_alumni_id();

        if ($id) {
            $data['id'] = $id;
        }

        if ($this->Trainings->save($data)) {
            audit('SAVE_TRAINING', 'Alumni saved a training record.');
            $this->json(api_success('Training record' . ($id ? ' updated' : ' added') . ' successfully.'));
        }

        $this->json(api_error('Unable to save training record.'));
    }

    private function validate($d): ?string
    {
        if (empty($d['training_title'])) {
            return 'Training title is required.';
        }

        if (!empty($d['date_start']) && !empty($d['date_end']) && $d['date_end'] < $d['date_start']) {
            return 'The end date cannot be earlier than the start date.';
        }

        if (!in_array($d['training_type'], ['Training', 'Advanced Study'], true)) {
            return 'Please choose the type (Training or Advanced Study).';
        }

        if ($d['training_year'] !== '' && (!ctype_digit($d['training_year'])
                || (int) $d['training_year'] < 1950 || (int) $d['training_year'] > (int) date('Y') + 1)) {
            return 'Year is not valid.';
        }

        if ($d['purpose'] !== '' && !in_array($d['purpose'], ['Promotion', 'Professional Development', 'Other'], true)) {
            return 'Please choose a valid purpose.';
        }

        if ($d['purpose'] === 'Other' && $d['purpose_other'] === '') {
            return 'Please specify the other purpose.';
        }

        return null;
    }

    private function fields($d): array
    {
        return [
            'training_title'     => $d['training_title'],
            'organizer'          => $d['organizer'] ?: null,
            'training_type'      => $d['training_type'],
            'duration'           => substr($d['duration'], 0, 60) ?: null,
            'credits_earned'     => substr($d['credits_earned'], 0, 30) ?: null,
            'college_university' => substr($d['college_university'], 0, 150) ?: null,
            'training_year'      => $d['training_year'] !== '' ? (int) $d['training_year'] : null,
            'purpose'            => $d['purpose'] ?: null,
            'purpose_other'      => $d['purpose'] === 'Other' ? substr($d['purpose_other'], 0, 150) : null,
            'date_start'         => $d['date_start'] ?: null,
            'date_end'           => $d['date_end'] ?: null,
        ];
    }
}
