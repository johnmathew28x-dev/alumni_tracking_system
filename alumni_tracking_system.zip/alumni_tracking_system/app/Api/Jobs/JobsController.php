<?php

namespace Api\Jobs;

use Core\BaseController;
use Models\Jobs;
use Models\Users;

class JobsController extends BaseController
{
    private $Jobs;

    public function __construct()
    {
        api_guard([Users::ADMIN]);
        $this->Jobs = new Jobs();
    }

    public function all()
    {
        $this->json([
            'data' => $this->Jobs->find()
        ]);
    }

    public function add()
    {
        $this->persist(null);
    }

    public function edit($id = null)
    {
        $job = $this->Jobs->findByID($id);

        if (!$job) {
            api_deny(404, 'Job posting not found.');
        }

        if (is_post()) {
            $this->persist($job->id);
        }

        $this->json($job);
    }

    public function toggle($id = null)
    {
        $job = $this->Jobs->findByID($id);

        if (!$job) {
            api_deny(404, 'Job posting not found.');
        }

        $status = $job->status === 'open' ? 'closed' : 'open';
        $this->Jobs->setStatus($job->id, $status);

        audit('TOGGLE_JOB', "Set job posting #{$job->id} to {$status}");
        $this->json(api_success('Job posting is now ' . $status . '.'));
    }

    public function delete($id = null)
    {
        if (empty($id)) {
            $this->json(api_error('Job ID is required.'));
        }

        if ($this->Jobs->delete($id)) {
            audit('DELETE_JOB', "Deleted job posting #{$id}");
            $this->json(api_success('Job posting deleted successfully.'));
        }

        $this->json(api_error('Unable to delete job posting.'));
    }

    private function persist($id): void
    {
        $d = input();

        if (empty($d['job_title']) || empty($d['company'])) {
            $this->json(api_error('Job title and company are required.'));
        }

        $row = [
            'job_title'                => $d['job_title'],
            'company'                  => $d['company'],
            'location'                 => $d['location'] ?: null,
            'description'              => $d['description'] ?: null,
            'qualifications'           => $d['qualifications'] ?: null,
            'application_instructions' => $d['application_instructions'] ?: null,
            'deadline'                 => $d['deadline'] ?: null,
            'status'                   => ($d['status'] ?? '') === 'closed' ? 'closed' : 'open',
        ];

        if ($id) {
            $row['id'] = $id;
        } else {
            $row['created_by'] = user_id();
        }

        if ($this->Jobs->save($row)) {
            audit($id ? 'UPDATE_JOB' : 'CREATE_JOB', ($id ? 'Updated' : 'Created') . ' job posting: ' . $d['job_title']);
            $this->json(api_success($id ? 'Job posting updated successfully.' : 'Job posting added successfully.'));
        }

        $this->json(api_error('Unable to save job posting.'));
    }
}