<?php

namespace Api\Educations;

use Core\BaseController;
use Models\Educations;
use Models\Users;

class EducationsController extends BaseController
{
    private $Educations;

    public function __construct()
    {
        api_guard([Users::ALUMNI]);
        $this->Educations = new Educations();
    }

    public function all()
    {
        $this->json(['data' => $this->Educations->forAlumni(require_alumni_id())]);
    }

    public function add()
    {
        $this->save(null);
    }

    public function edit(?int $id = null)
    {
        $record = $this->ownRecord($id);

        if (is_post()) {
            $this->save((int) $record->id);
        }

        $this->json($record);
    }

    public function delete(?int $id = null)
    {
        $record = $this->ownRecord($id);

        if ($this->Educations->delete($record->id)) {
            audit('DELETE_EDUCATION', 'Alumni deleted a education record.');
            $this->json(api_success('Education record deleted successfully.'));
        }

        $this->json(api_error('Unable to delete education record.'));
    }

    private function ownRecord(?int $id)
    {
        $record = $id ? $this->Educations->findByID($id) : null;

        if (!$record || (int) $record->alumni_id !== require_alumni_id()) {
            api_deny(404, 'Education record not found.');
        }

        return $record;
    }

    private function save(?int $id): void
    {
        $d = input();

        if ($msg = $this->validate($d)) {
            $this->json(api_error($msg));
        }

        $data = $this->fields($d);
        $data['alumni_id'] = require_alumni_id();

        if ($id) {
            $data['id'] = $id;
        }

        if ($this->Educations->save($data)) {
            audit('SAVE_EDUCATION', 'Alumni saved a education record.');
            $this->json(api_success('Education record' . ($id ? ' updated' : ' added') . ' successfully.'));
        }

        $this->json(api_error('Unable to save education record.'));
    }

    private function validate($d): ?string
    {
        if (empty($d['education_level_id']) || empty($d['institution'])) {
            return 'Education level and institution are required.';
        }

        if (!empty($d['start_year']) && !empty($d['end_year']) && (int) $d['end_year'] < (int) $d['start_year']) {
            return 'The end year cannot be earlier than the start year.';
        }

        return null;
    }

    private function fields($d): array
    {
        return [
            'education_level_id' => (int) $d['education_level_id'],
            'institution'        => $d['institution'],
            'degree'             => $d['degree'] ?: null,
            'field_of_study'     => $d['field_of_study'] ?: null,
            'start_year'         => $d['start_year'] ?: null,
            'end_year'           => $d['end_year'] ?: null,
            'status'             => in_array($d['status'] ?? '', ['Ongoing', 'Completed', 'Discontinued'], true)
                                    ? $d['status']
                                    : 'Completed',
        ];
    }
}
