<?php

namespace Api\Exams;

use Core\BaseController;
use Models\Exams;
use Models\Users;

class ExamsController extends BaseController
{
    private $Exams;

    public function __construct()
    {
        api_guard([Users::ALUMNI]);
        $this->Exams = new Exams();
    }

    public function all()
    {
        $this->json(['data' => $this->Exams->forAlumni(require_alumni_id())]);
    }

    public function add()
    {
        $this->save(null);
    }

    public function edit(?int $id = null)
    {
        $record = $this->ownRecord($id);

        if (is_post()) {
            $this->save((int) $record->id);
        }

        $this->json($record);
    }

    public function delete(?int $id = null)
    {
        $record = $this->ownRecord($id);

        if ($this->Exams->delete($record->id)) {
            audit('DELETE_EXAM', 'Alumni deleted a professional examination.');
            $this->json(api_success('Professional examination deleted successfully.'));
        }

        $this->json(api_error('Unable to delete professional examination.'));
    }

    private function ownRecord(?int $id)
    {
        $record = $id ? $this->Exams->findByID($id) : null;

        if (!$record || (int) $record->alumni_id !== require_alumni_id()) {
            api_deny(404, 'Professional examination not found.');
        }

        return $record;
    }

    private function save(?int $id): void
    {
        $d = input();

        if ($msg = $this->validate($d)) {
            $this->json(api_error($msg));
        }

        $data = $this->fields($d);
        $data['alumni_id'] = require_alumni_id();

        if ($id) {
            $data['id'] = $id;
        }

        if ($this->Exams->save($data)) {
            audit('SAVE_EXAM', 'Alumni saved a professional examination.');
            $this->json(api_success('Professional examination' . ($id ? ' updated' : ' added') . ' successfully.'));
        }

        $this->json(api_error('Unable to save professional examination.'));
    }

    private function validate($d): ?string
    {
        if ($d['exam_name'] === '') {
            return 'Name of examination is required.';
        }

        if (strlen($d['exam_name']) > 200) {
            return 'Name of examination is too long.';
        }

        if ($d['date_taken'] !== '') {
            $dt = \DateTime::createFromFormat('Y-m-d', $d['date_taken']);
            if (!$dt || $dt->format('Y-m-d') !== $d['date_taken']) {
                return 'Date taken is not a valid date.';
            }

            if ($d['date_taken'] > date('Y-m-d')) {
                return 'Date taken cannot be in the future.';
            }
        }

        if ($d['rating'] !== '' && (!is_numeric($d['rating']) || $d['rating'] < 0 || $d['rating'] > 100)) {
            return 'Rating must be a number from 0 to 100.';
        }

        if (!in_array($d['result'], ['Passed', 'Failed', 'Pending'], true)) {
            return 'Please choose a result.';
        }

        return null;
    }

    private function fields($d): array
    {
        return [
            'exam_name'  => $d['exam_name'],
            'date_taken' => $d['date_taken'] ?: null,
            'rating'     => $d['rating'] !== '' ? $d['rating'] : null,
            'result'     => $d['result'],
        ];
    }
}
