<?php

namespace Api\Alumni;

use Core\BaseController;
use Models\Alumni;
use Models\CorrectionRequests;
use Models\Users;

class AlumniController extends BaseController
{
    private $Alumni;

    public function __construct()
    {
        api_guard([Users::ADMIN, Users::FACULTY]);
        $this->Alumni = new Alumni();
    }

    public function all()
    {
        $rows = $this->Alumni->find([
            'keyword'              => $_GET['keyword'] ?? '',
            'program_id'           => $_GET['program_id'] ?? '',
            'graduation_year'      => $_GET['graduation_year'] ?? '',
            'verification_status'  => $_GET['verification_status'] ?? '',
            'profile_status'       => $_GET['profile_status'] ?? '',
            'gender'               => $_GET['gender'] ?? '',
            'province'             => $_GET['province'] ?? '',
            'employment_status_id' => $_GET['employment_status_id'] ?? '',
            'licensure_status_id'  => has_role(Users::ADMIN) ? ($_GET['licensure_status_id'] ?? '') : '',
        ]);

        foreach ($rows as $row) {
            $row->picture_url = avatar_url($row->profile_picture);
            $row->has_picture = !empty($row->profile_picture) && is_file(PROFILE_UPLOAD_DIR . '/' . $row->profile_picture);
            unset($row->profile_picture);
        }

        $this->json(['data' => $rows]);
    }

    private function hasPhotoUpload(): bool
    {
        return isset($_FILES['profile_picture'])
            && is_array($_FILES['profile_picture'])
            && ($_FILES['profile_picture']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
    }

    public function add()
    {
        api_allow(Users::ADMIN);
        $d = input();

        if ($d['first_name'] === '' || $d['last_name'] === '') {
            $this->json(api_error('First and last name are required.'));
        }
        if (($d['username'] ?? '') === '') {
            $this->json(api_error('Username is required.'));
        }
        if (!filter_var($d['email'] ?? '', FILTER_VALIDATE_EMAIL)) {
            $this->json(api_error('A valid email address is required.'));
        }
        if (strlen($d['password'] ?? '') < 8) {
            $this->json(api_error('Password must be at least 8 characters.'));
        }

        $Users = new Users();
        if ($Users->usernameExists($d['username'])) {
            $this->json(api_error('Username is already taken.'));
        }
        if ($Users->emailExists($d['email'])) {
            $this->json(api_error('Email is already registered.'));
        }

        $photo = null;

        if ($this->hasPhotoUpload()) {
            $stored = profile_image_store($_FILES['profile_picture'], 'new');

            if ($stored['error'] !== null) {
                $this->json(api_error($stored['error']));
            }

            $photo = $stored['file'];
        }

        $academic = null;

        if (!empty($d['program_id']) && !empty($d['graduation_year'])) {
            $academic = [
                'program_id'      => $d['program_id'],
                'major'           => $d['major'] ?: null,
                'graduation_year' => $d['graduation_year'],
                'batch'           => $d['batch'] ?: null,
                'student_id'      => $d['student_id'] ?: null,
            ];
        }

        $saved = $Users->createUser(
            [
                'username' => $d['username'],
                'email'    => $d['email'],
                'password' => $d['password'],
                'role'     => Users::ALUMNI,
                'status'   => 'active',
            ],
            [
                'first_name'          => $d['first_name'],
                'middle_name'         => $d['middle_name'] ?: null,
                'last_name'           => $d['last_name'],
                'suffix'              => $d['suffix'] ?: null,
                'date_of_birth'       => $d['date_of_birth'] ?: null,
                'gender'              => $d['gender'] ?: null,
                'contact_number'      => $d['contact_number'] ?: null,
                'email'               => $d['email'],
                'address'             => $d['address'] ?: null,
                'verification_status' => 'verified',
            ],
            $academic
        );

        if (!$saved) {
            profile_image_delete($photo);
            $this->json(api_error('Unable to save alumni.'));
        }

        audit('CREATE_ALUMNI', "Admin created alumni record: {$d['username']}");

        if ($photo !== null) {
            $created = $Users->findByUsername($d['username']);

            if (!$created || !$Users->setProfilePicture((int) $created->id, $photo)) {
                profile_image_delete($photo);
                $this->json(api_success('Alumni added, but the profile picture could not be saved. You can add it by editing the record.'));
            }
        }

        $this->json(api_success('Alumni added successfully.'));
    }

    public function edit($id = null)
    {
        $alumni = $id ? $this->Alumni->details($id) : null;

        if (!$alumni) {
            api_deny(404, 'Alumni record not found.');
        }

        if (is_post()) {
            api_allow(Users::ADMIN);
            $d = input();

            if ($d['first_name'] === '' || $d['last_name'] === '') {
                $this->json(api_error('First and last name are required.'));
            }
            if ($d['email'] !== '' && !filter_var($d['email'], FILTER_VALIDATE_EMAIL)) {
                $this->json(api_error('Please enter a valid email address.'));
            }

            if ($d['gender'] !== '' && !in_array($d['gender'], ['Male', 'Female', 'Other'], true)) {
                $this->json(api_error('Please choose a valid sex.'));
            }
            if ($d['date_of_birth'] !== '') {
                $dt = \DateTime::createFromFormat('Y-m-d', $d['date_of_birth']);

                if (!$dt || $dt->format('Y-m-d') !== $d['date_of_birth'] || $d['date_of_birth'] > date('Y-m-d')) {
                    $this->json(api_error('Please enter a valid birthday.'));
                }
            }
            if ($d['contact_number'] !== '' && !preg_match('/^[0-9+\-\s()]{7,20}$/', $d['contact_number'])) {
                $this->json(api_error('Mobile number may only contain digits, spaces, + - ( ) (7-20 characters).'));
            }

            $changes = Alumni::diff(Alumni::snapshot($alumni), [
                'first_name'     => $d['first_name'],
                'middle_name'    => $d['middle_name'],
                'last_name'      => $d['last_name'],
                'suffix'         => $d['suffix'],
                'date_of_birth'  => $d['date_of_birth'],
                'gender'         => $d['gender'],
                'contact_number' => $d['contact_number'],
                'address'        => $d['address'],
            ]);

            $photo = null;

            if ($this->hasPhotoUpload()) {
                $stored = profile_image_store($_FILES['profile_picture'], 'u' . (int) $alumni->user_id);

                if ($stored['error'] !== null) {
                    $this->json(api_error($stored['error']));
                }

                $photo = $stored['file'];
            }

            if ($this->Alumni->save([
                'id'             => $alumni->id,
                'first_name'     => $d['first_name'],
                'middle_name'    => $d['middle_name'] ?: null,
                'last_name'      => $d['last_name'],
                'suffix'         => $d['suffix'] ?: null,
                'date_of_birth'  => $d['date_of_birth'] ?: null,
                'gender'         => $d['gender'] ?: null,
                'contact_number' => $d['contact_number'] ?: null,
                'email'          => $d['email'] ?: null,
                'address'        => $d['address'] ?: null,
            ])) {
                if ($photo !== null) {
                    $Users = new Users();
                    $old   = $Users->pictureFor((int) $alumni->user_id);

                    if (!$Users->setProfilePicture((int) $alumni->user_id, $photo)) {
                        profile_image_delete($photo);
                        $this->json(api_error('The details were saved, but the new profile picture could not be saved.'));
                    }

                    profile_image_delete($old, $photo);
                    audit('UPDATE_PROFILE_PICTURE', "Admin changed profile picture of alumni #{$alumni->id}");
                }

                if ($changes && Alumni::isLocked($alumni)) {
                    (new CorrectionRequests())->logAdminEdit((int) $alumni->id, (int) user_id(), $changes);
                }

                audit('UPDATE_ALUMNI', "Updated alumni #{$alumni->id} ({$d['first_name']} {$d['last_name']})" . ($changes ? ' fields: ' . implode(', ', array_keys($changes)) : ''));
                $this->json(api_success('Alumni updated successfully.'));
            }

            profile_image_delete($photo);
            $this->json(api_error('Unable to save alumni.'));
        }

        $alumni->picture_url = avatar_url($alumni->profile_picture);
        $alumni->has_picture = !empty($alumni->profile_picture) && is_file(PROFILE_UPLOAD_DIR . '/' . $alumni->profile_picture);
        unset($alumni->profile_picture);

        $this->json($alumni);
    }

    public function verify($id = null)
    {
        api_allow(Users::ADMIN);
        $status = $_POST['status'] ?? '';

        if (!in_array($status, ['verified', 'rejected', 'pending'], true)) {
            $this->json(api_error('Invalid status.'));
        }
        if (!$id || !$this->Alumni->details($id)) {
            api_deny(404, 'Alumni record not found.');
        }

        $this->Alumni->setVerification($id, $status);
        audit('VERIFY_ALUMNI', "Set alumni #{$id} verification status to {$status}");
        $this->json(api_success('Verification status updated to ' . $status . '.'));
    }

    public function corrections()
    {
        api_allow(Users::ADMIN);

        $this->json(['data' => (new CorrectionRequests())->all((string) ($_GET['status'] ?? ''))]);
    }

    public function approveCorrection($id = null)
    {
        api_allow(Users::ADMIN);

        if (!is_post() || !$id || !ctype_digit((string) $id)) {
            $this->json(api_error('Invalid request.'));
        }

        $note = mb_substr(trim((string) ($_POST['review_note'] ?? '')), 0, 500);

        [$ok, $message] = (new CorrectionRequests())->approve((int) $id, (int) user_id(), $note);

        if ($ok) {
            audit('APPROVE_CORRECTION', "Approved correction request #{$id}", 'alumni', null);
        }

        $this->json($ok ? api_success($message) : api_error($message));
    }

    public function rejectCorrection($id = null)
    {
        api_allow(Users::ADMIN);

        if (!is_post() || !$id || !ctype_digit((string) $id)) {
            $this->json(api_error('Invalid request.'));
        }

        $note = mb_substr(trim((string) ($_POST['review_note'] ?? '')), 0, 500);

        if (mb_strlen($note) < 3) {
            $this->json(api_error('Please enter the reason for rejecting this request.'));
        }

        if ((new CorrectionRequests())->reject((int) $id, (int) user_id(), $note)) {
            audit('REJECT_CORRECTION', "Rejected correction request #{$id}", 'alumni', null);
            $this->json(api_success('Correction request rejected. The submitted information was not changed.'));
        }

        $this->json(api_error('This request is no longer pending.'));
    }
}
