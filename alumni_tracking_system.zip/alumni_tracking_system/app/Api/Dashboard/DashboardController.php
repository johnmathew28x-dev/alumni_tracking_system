<?php

namespace Api\Dashboard;

use Core\BaseController;
use Models\Alumni;
use Models\Announcements;
use Models\Events;
use Models\GtsReports;
use Models\Jobs;
use Models\TracerResponses;
use Models\TracerStudies;
use Models\Users;

class DashboardController extends BaseController
{
    public function __construct()
    {
        api_guard();
    }

    public function summary()
    {
        api_allow(Users::ALUMNI);

        $me = (new Alumni())->findByUserID(user_id());

        if (!$me) {
            $this->json(api_error('Your alumni profile could not be found. Please contact the administrator.'));
        }

        $Events = new Events();

        $this->json(api_success('OK', ['data' => [
            'alumni' => [
                'first_name'          => $me->first_name,
                'alumni_number'       => $me->alumni_id,
                'verification_status' => $me->verification_status,
            ],
            'attendance'    => $Events->attendanceFor($me->id),
            'announcements' => array_slice((new Announcements())->published(), 0, 3),
            'events'        => array_slice($Events->upcoming($me->id), 0, 3),
            'studies'       => (new TracerStudies())->active((int) $me->id),
        ]]));
    }

    /**
     * Administrator dashboard. Same figures and model calls as the web page
     * (Controllers\DashboardController, Users::ADMIN branch), as JSON.
     */
    public function admin()
    {
        api_allow(Users::ADMIN);

        $Alumni  = new Alumni();
        $pending = array_slice($Alumni->find(['verification_status' => 'pending']), 0, 5);
        attach_avatar($pending);

        $this->json(api_success('OK', ['data' => [
            'stats' => [
                'total'      => $Alumni->countTotal(),
                'pending'    => $Alumni->countByVerification('pending'),
                'employed'   => $Alumni->countEmployed(),
                'unemployed' => $Alumni->countUnemployed(),
                'let'        => $Alumni->countLetPassers(),
                'events'     => (new Events())->upcomingCount(),
                'jobs'       => (new Jobs())->openCount(),
                'responses'  => (new TracerResponses())->countActiveRespondents(),
            ],
            'gts'           => $this->gtsSummary(),
            'pending'       => $pending,
            'announcements' => array_slice((new Announcements())->published(), 0, 3),
        ]]));
    }

    /**
     * Faculty / Quality Assurance dashboard (web 'staff' view): read-only totals.
     */
    public function staff()
    {
        api_allow(Users::FACULTY, Users::QA);

        $Alumni = new Alumni();

        $this->json(api_success('OK', ['data' => [
            'stats' => [
                'total'    => $Alumni->countTotal(),
                'verified' => $Alumni->countByVerification('verified'),
                'employed' => $Alumni->countEmployed(),
                'let'      => $Alumni->countLetPassers(),
            ],
            'gts' => $this->gtsSummary(),
        ]]));
    }

    /** Only the headline GTS figures the dashboards show (not the full report payload). */
    private function gtsSummary(): array
    {
        $gts = (new GtsReports())->summary([]);

        return [
            'kpis'          => $gts['kpis'] ?? [],
            'participation' => ['rate' => $gts['participation']['rate'] ?? null],
        ];
    }
}
