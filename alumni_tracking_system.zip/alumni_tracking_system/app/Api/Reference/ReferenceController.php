<?php

namespace Api\Reference;

use Core\BaseController;
use Models\Reference;
use Models\Users;

class ReferenceController extends BaseController
{
    private $Ref;

    public function __construct()
    {
        api_guard([Users::ADMIN]);
        $this->Ref = new Reference();
    }

    private function table($t): string
    {
        if (!$t || !$this->Ref->valid($t)) {
            api_deny(404, 'Unknown reference list.');
        }
        return $t;
    }

    public function all($table = null)
    {
        $this->json(['data' => $this->Ref->all($this->table($table))]);
    }

    public function add($table = null)
    {
        $this->save($this->table($table), null);
    }

    public function edit($table = null, $id = null)
    {
        $table = $this->table($table);
        $row = $id ? $this->Ref->find($table, (int) $id) : null;

        if (!$row) {
            api_deny(404, 'Reference choice not found.');
        }

        if (is_post()) {
            $this->save($table, (int) $id);
        }

        $this->json($row);
    }

    public function toggle($table = null, $id = null)
    {
        $table = $this->table($table);

        if (in_array($table, ['programs', 'departments'], true)) {
            $this->json(api_error('Programs and departments cannot be deactivated.'));
        }

        $row = $id ? $this->Ref->find($table, (int) $id) : null;

        if (!$row) {
            api_deny(404, 'Reference choice not found.');
        }

        $new = (int) $row->is_active === 1 ? 0 : 1;
        $this->Ref->setActive($table, (int) $id, $new);

        audit('UPDATE_REFERENCE', ($new ? 'Activated' : 'Deactivated') . " {$table} #{$id}", $table, (int) $id);
        $this->json(api_success($new ? 'Choice is active again.' : 'Choice hidden from new surveys.'));
    }

    public function delete($table = null, $id = null)
    {
        $table = $this->table($table);

        if (!in_array($table, ['programs', 'departments'], true)) {
            $this->json(api_error('Survey choices are deactivated, not deleted, so past answers stay valid.'));
        }

        if ($msg = $this->Ref->delete($table, (int) $id)) {
            $this->json(api_error($msg));
        }

        audit('DELETE_REFERENCE', "Deleted {$table} #{$id}", $table, (int) $id);
        $this->json(api_success('Deleted successfully.'));
    }

    private function save(string $table, ?int $id): void
    {
        $d = input();
        $data = [];

        if ($table === 'programs') {
            if ($d['program_code'] === '' || $d['program_name'] === '') {
                $this->json(api_error('Program code and name are required.'));
            }

            $dept = $this->Ref->find('departments', (int) $d['department_id']);

            if (!$dept) {
                $this->json(api_error('Please choose a department.'));
            }

            $data = [
                'program_code'  => substr($d['program_code'], 0, 20),
                'program_name'  => substr($d['program_name'], 0, 150),
                'department_id' => (int) $dept->id,
            ];
        } elseif ($table === 'departments') {
            if ($d['department_name'] === '') {
                $this->json(api_error('Department name is required.'));
            }

            $data = ['department_name' => substr($d['department_name'], 0, 150)];
        } else {
            if ($d['name'] === '') {
                $this->json(api_error('Name is required.'));
            }

            $data = [
                'name'       => substr($d['name'], 0, 150),
                'sort_order' => (int) $d['sort_order'],
                'is_other'   => empty($d['is_other']) ? 0 : 1,
            ];

            if ($table === 'employment_reasons') {
                if (!in_array($d['reason_type'], ['accept', 'change'], true)) {
                    $this->json(api_error('Choose whether this is a reason for accepting or changing a job.'));
                }
                $data['reason_type'] = $d['reason_type'];
            }

            if (!$id) {
                $data['is_active'] = 1;
            }
        }

        if ($this->Ref->duplicate($table, $data, (int) $id)) {
            $this->json(api_error('That value already exists in this list.'));
        }

        if ($id) {
            $data['id'] = $id;
        }

        try {
            $ok = $this->Ref->save($table, $data);
        } catch (\PDOException $e) {
            error_log($e->getMessage());
            $ok = false;
        }

        if ($ok) {
            audit($id ? 'UPDATE_REFERENCE' : 'CREATE_REFERENCE', ($id ? 'Updated ' : 'Added ') . $table, $table, $id);
            $this->json(api_success('Saved successfully.'));
        }

        $this->json(api_error('Unable to save.'));
    }
}