<?php

namespace Api\Browse;

use Core\BaseController;
use Models\Announcements;
use Models\Events;
use Models\Jobs;
use Models\Users;

class BrowseController extends BaseController
{
    public function __construct()
    {
        api_guard();
    }

    public function announcements()
    {
        api_allow(Users::ALUMNI);

        $this->json(['data' => (new Announcements())->published()]);
    }

    public function jobs()
    {
        api_allow(Users::ALUMNI);

        $this->json(['data' => (new Jobs())->open()]);
    }

    public function events()
    {
        api_allow(Users::ALUMNI);

        $alumniId = require_alumni_id();

        $this->json(['data' => (new Events())->upcoming($alumniId)]);
    }
}
