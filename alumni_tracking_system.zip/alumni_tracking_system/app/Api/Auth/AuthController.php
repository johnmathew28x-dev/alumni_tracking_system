<?php

namespace Api\Auth;

use Core\BaseController;
use Models\Alumni;
use Models\ApiTokens;
use Models\AuditLogs;
use Models\Lookups;
use Models\Users;

class AuthController extends BaseController
{
    private const MOBILE_ROLES = Users::ALUMNI;

    private const REGISTER_MAX_ATTEMPTS   = 10;
    private const REGISTER_WINDOW_SECONDS = 3600;

    private $Users;
    private $Tokens;

    public function __construct()
    {
        $this->Users  = new Users();
        $this->Tokens = new ApiTokens();
    }

    public function login()
    {
        if (!is_post()) {
            api_deny(405, 'Invalid request.');
        }

        $identifier = trim($_POST['username'] ?? '');
        $password   = $_POST['password'] ?? '';
        $device     = trim($_POST['device_name'] ?? '') ?: 'Alumni mobile app';
        $ip         = $_SERVER['REMOTE_ADDR'] ?? '';

        if ($identifier === '' || $password === '') {
            api_deny(422, 'Username and password are required.');
        }

        if ($this->Tokens->tooManyFailures($identifier, $ip)) {
            api_deny(429, 'Too many failed attempts. Please wait a minute and try again.');
        }

        $user = $this->Users->findByLogin($identifier);

        if (!$user || !password_verify($password, $user->password)) {
            $this->Tokens->recordFailure($identifier, $ip);
            api_deny(401, 'Invalid username or password.');
        }

        if ($user->status !== 'active') {
            api_deny(403, 'Your account is inactive. Please contact the administrator.');
        }

        if ($user->role !== self::MOBILE_ROLES) {
            api_deny(403, 'Your account type cannot sign in to the mobile app.');
        }

        $this->Tokens->clearFailures($identifier, $ip);

        $token = $this->Tokens->issue((int) $user->id, $device);

        (new AuditLogs())->log((int) $user->id, 'LOGIN', $user->role . ' logged in from the mobile app.', 'Auth');

        $this->json(api_success('Logged in.', [
            'token' => $token,
            'user'  => $this->payload((int) $user->id, $user->username, $user->role),
        ]));
    }

    /**
     * Public: programs for the registration form (Lookups/all needs a login).
     * Same list the web registration page shows.
     */
    public function programs()
    {
        $rows = array_map(fn($row) => [
            'id'   => (int) $row->id,
            'name' => (string) $row->program_name,
            'code' => (string) $row->program_code,
        ], (new Lookups())->programs());

        $this->json(api_success('OK', ['data' => $rows]));
    }

    /**
     * Public alumni self-registration. Mirrors Controllers\AuthController::register:
     * the account is active immediately and the alumni record is 'pending'
     * until an administrator verifies it. Role and status are decided here,
     * never taken from the request.
     */
    public function register()
    {
        if (!is_post()) {
            api_deny(405, 'Invalid request.');
        }

        $ip = $_SERVER['REMOTE_ADDR'] ?? '';

        if ($this->Tokens->tooManyAttempts('reg:register', $ip, self::REGISTER_MAX_ATTEMPTS, self::REGISTER_WINDOW_SECONDS)) {
            api_deny(429, 'Too many registration attempts. Please try again later.');
        }

        $this->Tokens->recordFailure('reg:register', $ip);

        $d        = input();
        $password = (string) ($_POST['password'] ?? '');          // not trimmed
        $confirm  = (string) ($_POST['confirm_password'] ?? '');
        $year     = (int) $d['graduation_year'];

        $programIds = array_map(fn($p) => (int) $p->id, (new Lookups())->programs());

        if ($d['first_name'] === '' || $d['last_name'] === '' || $d['username'] === '') {
            api_deny(422, 'First name, last name and username are required.');
        }
        if (mb_strlen($d['first_name']) > 100 || mb_strlen($d['last_name']) > 100) {
            api_deny(422, 'First and last name must be 100 characters or fewer.');
        }
        if (mb_strlen($d['username']) > 55) {
            api_deny(422, 'Username must be 55 characters or fewer.');
        }
        // Login accepts "username OR email", so a username shaped like an email
        // could be confused with another person's address.
        if (str_contains($d['username'], '@')) {
            api_deny(422, 'Username cannot contain the @ symbol.');
        }
        if (!filter_var($d['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($d['email']) > 150) {
            api_deny(422, 'Please enter a valid email address.');
        }
        if (strlen($password) < 8) {
            api_deny(422, 'Password must be at least 8 characters.');
        }
        if ($password !== $confirm) {
            api_deny(422, 'Passwords do not match.');
        }
        if ($d['program_id'] === '' || $d['graduation_year'] === '') {
            api_deny(422, 'Please select your program and graduation year.');
        }
        if (!ctype_digit((string) $d['program_id']) || !in_array((int) $d['program_id'], $programIds, true)) {
            api_deny(422, 'Please select a valid program.');
        }
        if ($year < 1950 || $year > (int) date('Y') + 6) {
            api_deny(422, 'Please enter a valid graduation year.');
        }
        if ($this->Users->usernameExists($d['username'])) {
            api_deny(409, 'Username is already taken.');
        }
        if ($this->Users->emailExists($d['email'])) {
            api_deny(409, 'Email is already registered.');
        }

        $saved = $this->Users->createUser(
            [
                'username' => $d['username'],
                'email'    => $d['email'],
                'password' => $password,
                'role'     => Users::ALUMNI,
                'status'   => 'active',
            ],
            [
                'first_name'          => $d['first_name'],
                'last_name'           => $d['last_name'],
                'email'               => $d['email'],
                'verification_status' => 'pending',
            ],
            [
                'program_id'      => (int) $d['program_id'],
                'graduation_year' => $year,
            ]
        );

        if (!$saved) {
            // A concurrent request can win the UNIQUE keys between the checks above and the insert.
            if ($this->Users->usernameExists($d['username'])) {
                api_deny(409, 'Username is already taken.');
            }
            if ($this->Users->emailExists($d['email'])) {
                api_deny(409, 'Email is already registered.');
            }

            api_deny(500, 'Registration failed. Please try again.');
        }

        $created = $this->Users->findByUsername($d['username']);

        (new AuditLogs())->log($created ? (int) $created->id : null, 'REGISTER', 'Alumni registered from the mobile app.', 'Auth');

        http_response_code(201);
        $this->json(api_success('Registration successful! You can now log in. An administrator will verify your alumni record.'));
    }

    public function me()
    {
        api_guard();

        $user = auth_user();

        $this->json(api_success('OK', [
            'user' => $this->payload((int) $user['id'], $user['username'], $user['role']),
        ]));
    }

    public function logout()
    {
        api_guard();

        $tokenId = auth_token_id();

        if ($tokenId) {
            $this->Tokens->revoke($tokenId);
            audit('LOGOUT', user_role() . ' logged out from the mobile app.', 'Auth');
        }

        $this->json(api_success('Logged out.'));
    }

    private function payload(int $id, string $username, string $role): array
    {
        $alumni = (new Alumni())->findByUserID($id);
        $name   = $alumni ? trim($alumni->first_name . ' ' . $alumni->last_name) : '';

        return [
            'id'            => $id,
            'username'      => $username,
            'role'          => $role,
            'alumni_id'     => $alumni ? (int) $alumni->id : null,
            'alumni_number' => $alumni ? $alumni->alumni_id : null,
            'full_name'     => $name !== '' ? $name : $username,
            'picture_url'   => avatar_url($this->Users->pictureFor($id)),
        ];
    }
}
