<?php

namespace Api\Academics;

use Core\BaseController;
use Models\Academics;
use Models\Users;

class AcademicsController extends BaseController
{
    private $Academics;

    public function __construct()
    {
        api_guard([Users::ALUMNI]);
        $this->Academics = new Academics();
    }

    public function all()
    {
        $this->json(['data' => $this->Academics->forAlumni(require_alumni_id())]);
    }

    public function add()
    {
        $this->save(null);
    }

    public function edit(?int $id = null)
    {
        $record = $this->ownRecord($id);

        if (is_post()) {
            $this->save((int) $record->id);
        }

        $this->json($record);
    }

    public function delete(?int $id = null)
    {
        $record = $this->ownRecord($id);

        if ($this->Academics->delete($record->id)) {
            audit('DELETE_ACADEMIC', 'Alumni deleted a program record.');
            $this->json(api_success('Program record deleted successfully.'));
        }

        $this->json(api_error('Unable to delete program record.'));
    }

    private function ownRecord(?int $id)
    {
        $record = $id ? $this->Academics->findByID($id) : null;

        if (!$record || (int) $record->alumni_id !== require_alumni_id()) {
            api_deny(404, 'Program record not found.');
        }

        return $record;
    }

    private function save(?int $id): void
    {
        $d = input();

        if ($msg = $this->validate($d)) {
            $this->json(api_error($msg));
        }

        $data = $this->fields($d);
        $data['alumni_id'] = require_alumni_id();

        if ($id) {
            $data['id'] = $id;
        }

        if ($this->Academics->save($data)) {
            audit('SAVE_ACADEMIC', 'Alumni saved a program record.');
            $this->json(api_success('Program record' . ($id ? ' updated' : ' added') . ' successfully.'));
        }

        $this->json(api_error('Unable to save program record.'));
    }

    private function validate($d): ?string
    {
        if (empty($d['program_id']) || empty($d['graduation_year'])) {
            return 'Program and graduation year are required.';
        }

        $year = (int) $d['graduation_year'];
        if ($year < 1950 || $year > (int) date('Y') + 6) {
            return 'Please enter a valid graduation year.';
        }

        return null;
    }

    private function fields($d): array
    {
        return [
            'program_id'      => (int) $d['program_id'],
            'major'           => $d['major'] ?: null,
            'graduation_year' => (int) $d['graduation_year'],
            'batch'           => $d['batch'] ?: null,
            'student_id'      => $d['student_id'] ?: null,
        ];
    }
}
