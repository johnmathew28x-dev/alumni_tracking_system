<?php

namespace Api\Tracer;

use Core\BaseController;
use Models\Alumni;
use Models\TracerQuestions;
use Models\TracerResponses;
use Models\TracerStudies;
use Models\Users;

class TracerController extends BaseController
{
    private $Studies;

    public function __construct()
    {
        api_guard();
        $this->Studies = new TracerStudies();
    }

    public function all()
    {
        api_allow(Users::ADMIN);

        $this->json([
            'data' => $this->Studies->find()
        ]);
    }

    public function add()
    {
        api_allow(Users::ADMIN);
        $this->persist(null);
    }

    public function edit($id = null)
    {
        api_allow(Users::ADMIN);

        $study = $this->Studies->findByID($id);
        if (!$study) {
            api_deny(404, 'Tracer study not found.');
        }

        if (is_post()) {
            $this->persist($study->id);
        }

        $this->json($study);
    }

    public function status($id = null)
    {
        api_allow(Users::ADMIN);

        $status = $_POST['status'] ?? '';
        if (!in_array($status, ['draft', 'active', 'closed'], true)) {
            $this->json(api_error('Invalid status.'));
        }

        $study = $this->Studies->findByID($id);
        if (!$study) {
            api_deny(404, 'Tracer study not found.');
        }

        $this->Studies->setStatus($study->id, $status);
        audit('TOGGLE_TRACER_STATUS', "Set tracer study #{$study->id} to {$status}", 'tracer_studies', (int) $study->id);
        $this->json(api_success('Status updated to ' . $status . '.'));
    }

    public function delete($id = null)
    {
        api_allow(Users::ADMIN);

        if (empty($id)) {
            $this->json(api_error('Tracer study ID is required.'));
        }

        if ($this->Studies->delete($id)) {
            audit('DELETE_TRACER_STUDY', "Deleted tracer study #{$id}");
            $this->json(api_success('Tracer study deleted successfully.'));
        }

        $this->json(api_error('Unable to delete tracer study.'));
    }

    public function active()
    {
        api_allow(Users::ALUMNI);

        $alumniId = require_alumni_id();

        $this->json(['data' => $this->Studies->active($alumniId)]);
    }

    public function questions($id = null)
    {
        api_allow(Users::ALUMNI);

        $alumniId = require_alumni_id();
        $study = $id ? $this->Studies->findByID((int) $id) : null;

        if (!$study || $study->status !== 'active') {
            api_deny(404, 'That tracer study is not available.');
        }

        if ($study->survey_type === 'gts') {
            $this->json(api_error('This is a CHED GTS survey. Use the Graduate Tracer Survey form.'));
        }

        $questions = array_map(function ($q) {
            return [
                'id'            => (int) $q->id,
                'question'      => $q->question,
                'question_type' => $q->question_type,
                'options'       => $q->options ? array_values(array_filter(array_map('trim', explode('|', $q->options)), 'strlen')) : [],
                'is_required'   => (int) $q->is_required,
            ];
        }, (new TracerQuestions())->forStudy((int) $study->id));

        $this->json(api_success('OK', [
            'study'     => [
                'id'          => (int) $study->id,
                'title'       => $study->title,
                'description' => $study->description,
            ],
            'questions' => $questions,
            'answers'   => (object) (new TracerResponses())->forStudyAndAlumni((int) $study->id, $alumniId),
        ]));
    }

    public function submit()
    {
        api_allow(Users::ALUMNI);

        $alumniId = require_alumni_id();
        $study = $this->Studies->findByID((int) ($_POST['tracer_study_id'] ?? 0));

        if (!$study || $study->status !== 'active') {
            $this->json(api_error('This tracer study is not currently active.'));
        }

        $questions = (new TracerQuestions())->forStudy($study->id);
        $answers = $_POST['answers'] ?? [];
        $clean = [];

        foreach ($questions as $q) {
            $answer = $answers[$q->id] ?? '';
            $answer = is_array($answer) ? '' : trim(strip_tags($answer));

            if ($q->is_required && $answer === '') {
                $this->json(api_error('Please answer all required questions.'));
            }

            $clean[$q->id] = $answer;
        }

        $Responses = new TracerResponses();
        foreach ($clean as $questionId => $answer) {
            $Responses->saveAnswer($study->id, $questionId, $alumniId, $answer);
        }

        audit('SUBMIT_TRACER', "Alumni submitted responses for tracer study #{$study->id}");
        $this->json(api_success('Thank you! Your tracer study responses have been submitted.'));
    }

    private function persist($id): void
    {
        $d = input();

        if (empty($d['title'])) {
            $this->json(api_error('Title is required.'));
        }

        $start = $d['start_date'] ?: null;
        $end = $d['end_date'] ?: null;

        if ($start && $end && $end < $start) {
            $this->json(api_error('The end date cannot be earlier than the start date.'));
        }

        $year = $d['survey_year'];
        if ($year !== '' && (!ctype_digit($year) || (int) $year < 2000 || (int) $year > (int) date('Y') + 1)) {
            $this->json(api_error('Survey year is not valid.'));
        }

        $row = [
            'title' => $d['title'],
            'description' => $d['description'] ?: null,
            'start_date' => $start,
            'end_date' => $end,
            'survey_year' => $year !== '' ? (int) $year : null,
        ];

        if ($id) {
            $row['id'] = $id;
        } else {
            $row['survey_type'] = $d['survey_type'] === 'custom' ? 'custom' : 'gts';
            $row['status'] = 'draft';
            $row['created_by'] = user_id();
        }

        if ($this->Studies->save($row)) {
            audit(
                $id ? 'UPDATE_TRACER_STUDY' : 'CREATE_TRACER_STUDY',
                ($id ? 'Updated' : 'Created') . ' survey period: ' . $d['title'],
                'tracer_studies',
                $id ? (int) $id : null
            );

            $this->json(api_success($id
                ? 'Survey period updated successfully.'
                : 'Survey period added. Activate it so alumni can answer.'));
        }

        $this->json(api_error('Unable to save tracer study.'));
    }
}