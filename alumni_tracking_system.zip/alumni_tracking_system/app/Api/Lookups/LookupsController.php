<?php

namespace Api\Lookups;

use Core\BaseController;
use Models\Lookups;

class LookupsController extends BaseController
{
    public function __construct()
    {
        api_guard();
    }

    public function all()
    {
        $L = new Lookups();

        $this->json(api_success('OK', ['data' => [
            'programs'            => $this->items($L->programs(), 'program_name', 'program_code'),
            'employment_statuses' => $this->items($L->employmentStatuses(), 'status_name'),
            'license_types'       => $this->items($L->licenseTypes(), 'license_name'),
            'licensure_statuses'  => $this->items($L->licensureStatuses(), 'status_name'),
            'civil_statuses'      => $this->items($L->ref('civil_statuses'), 'name'),
            'regions'             => $this->items($L->ref('regions'), 'name'),
            'residence_types'     => $this->items($L->ref('residence_types'), 'name'),
            'employment_types'    => $this->items($L->ref('employment_types'), 'name'),
            'industries'          => $this->items($L->ref('industries'), 'name'),
            'job_levels'          => $this->items($L->ref('job_levels'), 'name'),
            'salary_ranges'       => $this->items($L->ref('salary_ranges'), 'name'),
        ]]));
    }

    private function items(array $rows, string $nameField, ?string $codeField = null): array
    {
        return array_map(fn($row) => [
            'id'   => (int) $row->id,
            'name' => (string) $row->$nameField,
            'code' => $codeField !== null ? (string) $row->$codeField : null,
        ], $rows);
    }
}
