<?php

namespace Api\Gts;

use Core\BaseController;
use Models\Gts;
use Models\TracerStudies;
use Models\Users;

class GtsController extends BaseController
{
    private $Gts;

    public function __construct()
    {
        api_guard([Users::ALUMNI, Users::ADMIN]);
        $this->Gts = new Gts();
    }

    public function start($studyId = null)
    {
        api_allow(Users::ALUMNI);

        $alumniId = require_alumni_id();
        $study = $studyId ? (new TracerStudies())->findByID((int) $studyId) : null;

        if (!$study || $study->survey_type !== 'gts') {
            api_deny(404, 'That survey is not available.');
        }

        $survey = $study->status === 'active'
            ? $this->Gts->ensureSurvey((int) $study->id, $alumniId)
            : $this->Gts->findSurvey((int) $study->id, $alumniId);

        if (!$survey) {
            api_deny(404, 'That survey is closed and you have no saved response.');
        }

        $this->json(api_success('OK', [
            'study_id' => (int) $study->id,
            'editable' => $this->Gts->isEditable($survey, $study),
            'sections' => Gts::SECTIONS,
            'data'     => $this->Gts->load($survey),
        ]));
    }

    public function saveSection($studyId = null)
    {
        api_allow(Users::ALUMNI);
        $this->mustBePost();

        [$study, $survey] = $this->ownSurvey($studyId);
        $this->mustBeEditable($study, $survey);

        $n = (int) ($_POST['section'] ?? 0);
        if ($n < 1 || $n > 13) {
            $this->json(api_error('Unknown survey section.'));
        }

        try {
            $this->Gts->begin();
            $errors = $this->Gts->saveSection($n, $survey, input());

            if ($errors) {
                $this->Gts->rollBack();
                $this->json(api_error(reset($errors), $errors));
            }

            $this->Gts->touch((int) $survey->id, min($n + 1, 14));
            $this->Gts->commit();
        } catch (\Throwable $e) {
            $this->Gts->rollBack();
            error_log('GTS save failed: ' . $e->getMessage());
            $this->json(api_error('Unable to save this section. Please try again.'));
        }

        audit('SAVE_TRACER_SECTION', 'Saved GTS survey section ' . $n . '.', 'tracer_surveys', (int) $survey->id);

        $fresh = $this->Gts->surveyById((int) $survey->id);
        $data  = $this->Gts->load($fresh);
        $this->json(api_success('Section ' . $n . ' saved.', ['data' => ['survey' => $data['survey']]]));
    }

    public function review($studyId = null)
    {
        api_allow(Users::ALUMNI);
        [, $survey] = $this->ownSurvey($studyId);

        $data = $this->Gts->load($survey);
        $this->json([
            'status'   => 'success',
            'success'  => true,
            'sections' => $this->Gts->review($data),
            'missing'  => $this->Gts->missing($data),
        ]);
    }

    public function submit($studyId = null)
    {
        api_allow(Users::ALUMNI);
        $this->mustBePost();

        [$study, $survey] = $this->ownSurvey($studyId);
        $this->mustBeEditable($study, $survey);

        $missing = $this->Gts->missing($this->Gts->load($survey));
        if ($missing) {
            $this->json(api_error('Please complete the following before submitting: ' . implode(' ', $missing), ['missing' => $missing]));
        }

        $this->Gts->submit((int) $survey->id);
        audit('SUBMIT_TRACER', 'Alumni submitted the graduate tracer survey #' . $study->id . '.', 'tracer_surveys', (int) $survey->id);
        $this->json(api_success('Thank you! Your Graduate Tracer Survey has been submitted.'));
    }

    public function responses()
    {
        api_allow(Users::ADMIN);

        $filters = [];
        foreach (['study_id', 'program_id', 'graduation_year', 'employment_state', 'status', 'keyword'] as $k) {
            $filters[$k] = trim($_GET[$k] ?? '');
        }
        $rows = $this->Gts->responses($filters);
        attach_avatar($rows);
        $this->json(['data' => $rows]);
    }

    public function detail($surveyId = null)
    {
        api_allow(Users::ADMIN);
        $survey = $surveyId ? $this->Gts->surveyById((int) $surveyId) : null;

        if (!$survey) {
            api_deny(404, 'Survey response not found.');
        }

        $data = $this->Gts->load($survey);
        audit('VIEW_TRACER_RESPONSE', 'Viewed survey response #' . $survey->id, 'tracer_surveys', (int) $survey->id);

        $this->json([
            'status'   => 'success',
            'success'  => true,
            'survey'   => $data['survey'],
            'sections' => $this->Gts->review($data),
            'missing'  => $this->Gts->missing($data),
        ]);
    }

    public function allowResubmission($surveyId = null)
    {
        api_allow(Users::ADMIN);
        $this->mustBePost();

        $survey = $surveyId ? $this->Gts->surveyById((int) $surveyId) : null;
        if (!$survey) {
            api_deny(404, 'Survey response not found.');
        }

        $this->Gts->allowResubmission((int) $survey->id);
        audit('ALLOW_TRACER_RESUBMISSION', 'Allowed resubmission of survey response #' . $survey->id, 'tracer_surveys', (int) $survey->id);
        $this->json(api_success('The alumnus can now edit and resubmit this survey.'));
    }

    private function mustBePost(): void
    {
        if (!is_post()) {
            $this->json(api_error('Invalid request method.'));
        }
    }

    private function ownSurvey($studyId): array
    {
        $alumniId = require_alumni_id();
        $study    = $studyId ? (new TracerStudies())->findByID((int) $studyId) : null;

        if (!$study || $study->survey_type !== 'gts') {
            api_deny(404, 'Survey not found.');
        }

        $survey = $this->Gts->findSurvey((int) $study->id, $alumniId);
        if (!$survey) {
            api_deny(404, 'You have not started this survey.');
        }

        return [$study, $survey];
    }

    private function mustBeEditable($study, $survey): void
    {
        if ($study->status !== 'active') {
            $this->json(api_error('This survey period is closed.'));
        }
        if ($survey->status === 'submitted') {
            $this->json(api_error('You have already submitted this survey. Ask the alumni office if you need to correct it.'));
        }
    }
}