<?php

namespace Api\Employments;

use Core\BaseController;
use Models\Employments;
use Models\Lookups;
use Models\Users;

class EmploymentsController extends BaseController
{
    private $Employments;

    public function __construct()
    {
        api_guard([Users::ALUMNI]);
        $this->Employments = new Employments();
    }

    public function all()
    {
        $this->json(['data' => $this->Employments->forAlumni(require_alumni_id())]);
    }

    public function add()
    {
        $this->save(null);
    }

    public function edit(?int $id = null)
    {
        $record = $this->ownRecord($id);

        if (is_post()) {
            $this->save((int) $record->id);
        }

        $this->json($record);
    }

    public function delete(?int $id = null)
    {
        $record = $this->ownRecord($id);

        if ($this->Employments->delete($record->id)) {
            audit('DELETE_EMPLOYMENT', 'Alumni deleted a employment record.');
            $this->json(api_success('Employment record deleted successfully.'));
        }

        $this->json(api_error('Unable to delete employment record.'));
    }

    private function ownRecord(?int $id)
    {
        $record = $id ? $this->Employments->findByID($id) : null;

        if (!$record || (int) $record->alumni_id !== require_alumni_id()) {
            api_deny(404, 'Employment record not found.');
        }

        return $record;
    }

    private function save(?int $id): void
    {
        $d = input();

        if ($msg = $this->validate($d)) {
            $this->json(api_error($msg));
        }

        $data = $this->fields($d);
        $data['alumni_id'] = require_alumni_id();

        if ($id) {
            $data['id'] = $id;
        }

        if ($this->Employments->save($data)) {
            audit('SAVE_EMPLOYMENT', 'Alumni saved a employment record.');
            $this->json(api_success('Employment record' . ($id ? ' updated' : ' added') . ' successfully.'));
        }

        $this->json(api_error('Unable to save employment record.'));
    }

    private function validate($d): ?string
    {
        if (empty($d['employment_status_id'])) {
            return 'Employment status is required.';
        }

        if (
            empty($d['is_current'])
            && !empty($d['date_hired'])
            && !empty($d['date_ended'])
            && $d['date_ended'] < $d['date_hired']
        ) {
            return 'The end date cannot be earlier than the date hired.';
        }

        $Lookups = new Lookups();
        $lookupFields = [
            'employment_type_id' => 'employment_types',
            'industry_id'        => 'industries',
            'job_level_id'       => 'job_levels',
            'salary_range_id'    => 'salary_ranges',
        ];

        foreach ($lookupFields as $field => $table) {
            if ($d[$field] !== '' && !in_array((int) $d[$field], $Lookups->validIds($table), true)) {
                return 'Invalid choice for ' . str_replace('_', ' ', preg_replace('/_id$/', '', $field)) . '.';
            }
        }

        if ($d['place_of_work'] !== '' && !in_array($d['place_of_work'], ['Local', 'Abroad'], true)) {
            return 'Place of work must be Local or Abroad.';
        }

        if ($d['related_to_degree'] !== '' && !in_array($d['related_to_degree'], ['0', '1'], true)) {
            return 'Please answer whether the job is related to your degree.';
        }

        return null;
    }

    private function fields($d): array
    {
        $current = empty($d['is_current']) ? 0 : 1;

        $Lookups = new Lookups();
        $tenure  = $d['employment_type_id'] !== '' ? (int) $d['employment_type_id'] : null;
        $ind     = $d['industry_id'] !== '' ? (int) $d['industry_id'] : null;

        $tenureName = '';
        foreach ($Lookups->ref('employment_types', false) as $t) {
            if ($tenure && (int) $t->id === $tenure) {
                $tenureName = $t->name;
            }
        }

        $industryName = '';
        foreach ($Lookups->ref('industries', false) as $i) {
            if ($ind && (int) $i->id === $ind) {
                $industryName = $i->name;
            }
        }

        $legacyType = match ($tenureName) {
            'Self-employed' => 'Self-employed',
            'Contractual'   => 'Contractual',
            ''              => 'N/A',
            default         => 'Full-time',
        };

        return [
            'employment_status_id' => (int) $d['employment_status_id'],
            'employer'             => $d['employer'] ?: null,
            'job_position'         => $d['job_position'] ?: null,
            'industry'             => $industryName !== '' ? $industryName : null,
            'employment_location'  => $d['employment_location'] ?: null,
            'employment_type'      => $legacyType,
            'employment_type_id'   => $tenure,
            'industry_id'          => $ind,
            'place_of_work'        => $d['place_of_work'] ?: null,
            'job_level_id'         => $d['job_level_id'] !== '' ? (int) $d['job_level_id'] : null,
            'salary_range_id'      => $d['salary_range_id'] !== '' ? (int) $d['salary_range_id'] : null,
            'related_to_degree'    => $d['related_to_degree'] !== '' ? (int) $d['related_to_degree'] : null,
            'is_first_job'         => empty($d['is_first_job']) ? 0 : 1,
            'date_hired'           => $d['date_hired'] ?: null,
            'date_ended'           => $current ? null : ($d['date_ended'] ?: null),
            'is_current'           => $current,
        ];
    }
}
