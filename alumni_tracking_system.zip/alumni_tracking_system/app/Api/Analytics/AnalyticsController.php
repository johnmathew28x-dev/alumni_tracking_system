<?php

namespace Api\Analytics;

use Core\BaseController;
use Models\AiAnalytics;
use Models\GtsReports;
use Models\Users;

class AnalyticsController extends BaseController
{
    private function filters(): array
    {
        $f = [];
        foreach (GtsReports::FILTERS as $k) {
            $v = trim((string) ($_GET[$k] ?? ''));
            $f[$k] = $v;
        }

        if ($f['employment_state'] !== '' && !in_array($f['employment_state'], ['employed', 'not_employed', 'never_employed'], true)) {
            $f['employment_state'] = '';
        }

        if ($f['place_of_work'] !== '' && !in_array($f['place_of_work'], ['Local', 'Abroad'], true)) {
            $f['place_of_work'] = '';
        }

        if ($f['academic_year'] !== '' && !preg_match('/^\d{4}-\d{4}$/', $f['academic_year'])) {
            $f['academic_year'] = '';
        }

        foreach (['department_id', 'program_id', 'graduation_year', 'study_id', 'survey_year', 'industry_id'] as $k) {
            if ($f[$k] !== '' && !ctype_digit($f[$k])) {
                $f[$k] = '';
            }
        }

        return $f;
    }

    public function __construct()
    {
        api_guard([Users::ADMIN, Users::FACULTY, Users::QA]);
    }

    public function summary()
    {
        $this->json([
            'status'  => 'success',
            'success' => true,
            'data'    => (new GtsReports())->summary($this->filters())
        ]);
    }

    public function ask()
    {
        if (!is_post()) {
            $this->json(api_error('Invalid request method.'));
        }

        $result = (new AiAnalytics())->ask(
            (string) ($_POST['question'] ?? ''),
            $this->filters(),
            has_role(Users::ADMIN)
        );

        if (!$result['ok']) {
            if (($result['http'] ?? 200) === 429) {
                api_deny(429, $result['message']);
            }

            $this->json(api_error($result['message']));
        }

        $this->json(api_success('Analysis generated.', [
            'data' => [
                'answer'       => $result['answer'],
                'scope'        => $result['scope'],
                'cached'       => !empty($result['cached']),
                'generated_at' => $result['generated_at'],
                'model'        => $result['model'],
                'usage'        => $result['usage'] ?? null,
            ],
        ]));
    }

    public function export()
    {
        api_allow(Users::ADMIN, Users::QA);
        $set = $_GET['dataset'] ?? 'summary';
        $s   = (new GtsReports())->summary($this->filters());

        $rows = [
            ['Northeastern College - Graduate Tracer Report (CHED GTS-aligned)'],
            ['Generated', date('Y-m-d H:i')],
            []
        ];

        $addDist = function (string $title, array $items) use (&$rows) {
            $rows[] = [$title];
            $rows[] = ['Category', 'Respondents'];
            foreach ($items as $i) {
                $rows[] = [$i['label'], $i['total']];
            }
            $rows[] = [];
        };

        if ($set === 'programs') {
            $rows[] = ['Program', 'Respondents', 'Employed', 'Not employed', 'Never employed', 'Employment rate %', 'Degree-related', 'Degree-related rate %', 'Local', 'Abroad'];
            foreach ($s['by_program'] as $p) {
                $rows[] = [
                    $p['code'] . ' - ' . $p['name'],
                    $p['respondents'],
                    $p['employed'],
                    $p['not_employed'],
                    $p['never_employed'],
                    $p['employment_rate'],
                    $p['related'],
                    $p['related_rate'],
                    $p['local'],
                    $p['abroad']
                ];
            }
        } elseif ($set === 'feedback') {
            $rows[] = ['Program', 'Graduation year', 'Survey year', 'Suggestion'];
            foreach ($s['feedback'] as $f) {
                $rows[] = [$f['program'], $f['year'], $f['survey_year'], $f['text']];
            }
        } else {
            $k = $s['kpis'];
            $rows[] = ['Key figures'];
            
            $kpiLabels = [
                'respondents'     => 'Respondents',
                'employed'        => 'Employed',
                'not_employed'    => 'Not currently employed',
                'never_employed'  => 'Never employed',
                'self_employed'   => 'Self-employed',
                'local'           => 'Local employment',
                'abroad'          => 'Overseas employment',
                'related'         => 'Degree-related employment',
                'not_related'     => 'Not degree-related',
                'employment_rate' => 'Employment rate %',
                'related_rate'    => 'Degree-related rate % (of employed)',
                'relevance_rate'  => 'Curriculum relevant %'
            ];

            foreach ($kpiLabels as $key => $label) {
                $rows[] = [$label, $k[$key] ?? ''];
            }

            $rows[] = ['Survey participation %', $s['participation']['rate']];
            $rows[] = [];

            $addDist('Employment status', $s['employment_state']);
            $addDist('Employment type', $s['employment_type']);
            $addDist('Industry', $s['industry']);
            $addDist('Local / abroad', $s['place_of_work']);
            $addDist('Job level (present)', $s['job_level']);
            $addDist('Salary bracket (present)', $s['salary']);
            $addDist('Time to first job', $s['time_to_first_job']);
            $addDist('Job search method', $s['search_method']);
            $addDist('Curriculum relevance', $s['curriculum_relevance']);
            $addDist('Competencies used', $s['competencies']);
            $addDist('Sex', $s['sex']);
            $addDist('Civil status', $s['civil_status']);
            $addDist('Region of origin', $s['region']);
            $addDist('Program', $s['program_distribution']);
            $addDist('Graduation year', $s['graduation_years']);
        }

        audit('EXPORT_REPORT', 'Exported GTS report dataset: ' . preg_replace('/[^a-z]/', '', $set), 'reports');

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="gts-' . preg_replace('/[^a-z]/', '', $set) . '-' . date('Ymd') . '.csv"');

        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");

        foreach ($rows as $r) {
            $r = array_map(fn($v) => is_string($v) && preg_match('/^[=+\-@]/', $v) ? "'" . $v : $v, $r);
            fputcsv($out, $r);
        }

        fclose($out);
        exit;
    }
}