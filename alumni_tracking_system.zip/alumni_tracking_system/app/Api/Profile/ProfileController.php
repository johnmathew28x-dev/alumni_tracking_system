<?php

namespace Api\Profile;

use Core\BaseController;
use Models\Alumni;
use Models\ApiTokens;
use Models\CorrectionRequests;
use Models\GtsGeneral;
use Models\Profiles;
use Models\Users;

class ProfileController extends BaseController
{
    public function __construct()
    {
        api_guard();
    }

    public function show()
    {
        $this->json($this->payload());
    }

    public function details()
    {
        api_allow(Users::ALUMNI);

        $a = (new Alumni())->findByUserID(user_id());

        if (!$a) {
            $this->json(api_error('Your alumni profile could not be found. Please contact the administrator.'));
        }

        $this->json(api_success('OK', ['data' => [
            'alumni_number'     => $a->alumni_id,
            'first_name'        => $a->first_name,
            'middle_name'       => $a->middle_name,
            'last_name'         => $a->last_name,
            'suffix'            => $a->suffix,
            'date_of_birth'     => $a->date_of_birth,
            'gender'            => $a->gender,
            'contact_number'    => $a->contact_number,
            'email'             => $a->email,
            'address'           => $a->address,
            'civil_status_id'   => $a->civil_status_id !== null ? (int) $a->civil_status_id : null,
            'region_id'         => $a->region_id !== null ? (int) $a->region_id : null,
            'province'          => $a->province,
            'city_municipality' => $a->city_municipality,
            'residence_type_id' => $a->residence_type_id !== null ? (int) $a->residence_type_id : null,
            'verification_status' => $a->verification_status,
            'submission_status'   => $a->submission_status ?? 'draft',
        ]]));
    }

    public function update()
    {
        if (!is_post()) {
            $this->json(api_error('Invalid request.'));
        }

        has_role(Users::ALUMNI) ? $this->updateAlumni() : $this->updateStaff();
    }

    private function updateAlumni(): void
    {
        $alumni = $this->ownAlumni();
        $this->denyIfLocked($alumni);

        [$errors, $row] = GtsGeneral::validate(input());

        if ($errors) {
            $this->json(api_error(reset($errors), $errors));
        }

        if ((new Alumni())->saveDraft((int) $alumni->id, $row)) {
            audit('SAVE_PROFILE_DRAFT', 'Alumni saved own profile (not yet submitted).', 'alumni', (int) $alumni->id);
            $this->json(api_success('Your information has been saved. It is not locked until you submit it.', ['profile' => $this->payload()]));
        }

        $this->json(api_error('Unable to save your profile. It may already have been submitted.'));
    }

    public function submit()
    {
        if (!is_post()) {
            $this->json(api_error('Invalid request.'));
        }

        api_allow(Users::ALUMNI);

        $alumni = $this->ownAlumni();
        $this->denyIfLocked($alumni);

        $d = input();

        if (($d['privacy_ack'] ?? '') !== '1') {
            $this->json(api_error('Please read the privacy notice and confirm before submitting.', ['privacy_ack' => 'Confirmation is required.']));
        }

        [$errors, $row] = GtsGeneral::validate($d);

        if ($errors) {
            $this->json(api_error(reset($errors), $errors));
        }

        if ((new Alumni())->submitInitial((int) $alumni->id, $row)) {
            audit('SUBMIT_PROFILE', 'Alumni submitted personal information (profile locked).', 'alumni', (int) $alumni->id);
            $this->json(api_success('Your personal information has been submitted and is now locked.', ['profile' => $this->payload()]));
        }

        $this->json(api_error('Unable to submit your profile. It may already have been submitted.'));
    }

    public function requestCorrection()
    {
        if (!is_post()) {
            $this->json(api_error('Invalid request.'));
        }

        api_allow(Users::ALUMNI);

        $alumni = $this->ownAlumni();

        if (!Alumni::isLocked($alumni)) {
            $this->json(api_error('Your profile has not been submitted yet. Please complete and submit it first.'));
        }

        $d      = input();
        $reason = (string) $d['reason'];

        if (mb_strlen($reason) < 10 || mb_strlen($reason) > 500) {
            $this->json(api_error('Please explain the reason for the correction (10-500 characters).', ['reason' => 'Reason must be 10-500 characters.']));
        }

        $Requests = new CorrectionRequests();
        [$errors, $changes] = $Requests->buildChanges($alumni, $d);

        if ($errors) {
            $this->json(api_error(reset($errors), $errors));
        }

        if (!$changes) {
            $this->json(api_error('No changes were detected. Edit at least one field to request a correction.'));
        }

        if (!$Requests->create((int) $alumni->id, $changes, $reason)) {
            $this->json(api_error('You already have a correction request awaiting review.'));
        }

        audit('REQUEST_CORRECTION', 'Alumni requested correction of: ' . implode(', ', array_keys($changes)), 'alumni', (int) $alumni->id);
        $this->json(api_success('Your correction request has been sent for administrator review.'));
    }

    /**
     * The signed-in alumnus's own correction requests (newest first), the same
     * list the web profile page shows under "My Correction Requests".
     */
    public function corrections()
    {
        api_allow(Users::ALUMNI);

        $alumni = $this->ownAlumni();

        $this->json(['data' => (new CorrectionRequests())->forAlumni((int) $alumni->id)]);
    }

    private function ownAlumni()
    {
        $alumni = (new Alumni())->findByUserID(user_id());

        if (!$alumni) {
            $this->json(api_error('Your alumni profile could not be found. Please contact the administrator.'));
        }

        return $alumni;
    }

    private function denyIfLocked($alumni): void
    {
        if (Alumni::isLocked($alumni)) {
            api_deny(403, 'Your profile has been submitted and is locked. Please file a correction request instead.');
        }
    }

    private function updateStaff(): void
    {
        $d = input();
        $Users = new Users();
        $errors = [];

        $username = (string) $d['username'];
        $email    = (string) $d['email'];

        if (!preg_match('/^[A-Za-z0-9_.-]{3,55}$/', $username)) {
            $errors['username'] = 'Username must be 3-55 characters: letters, numbers, dot, dash or underscore.';
        } elseif ($Users->usernameExists($username, user_id())) {
            $errors['username'] = 'That username is already taken.';
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) {
            $errors['email'] = 'Please enter a valid email address.';
        } elseif ($Users->emailExists($email, user_id())) {
            $errors['email'] = 'That email address is already registered.';
        }

        if ($errors) {
            $this->json(api_error(reset($errors), $errors));
        }

        $Users->updateAccount(user_id(), $username, $email);

        $_SESSION['user']['username'] = $username;

        audit('UPDATE_PROFILE', 'User updated own account details.');
        $this->json(api_success('Your profile has been updated.', ['profile' => $this->payload()]));
    }

    public function picture()
    {
        if (!is_post()) {
            $this->json(api_error('Invalid request.'));
        }

        $stored = profile_image_store($_FILES['profile_picture'] ?? null, 'u' . (int) user_id());

        if ($stored['error'] !== null) {
            $this->json(api_error($stored['error']));
        }

        $name = $stored['file'];

        $Users = new Users();
        $old = $Users->pictureFor(user_id());

        $Users->setProfilePicture(user_id(), $name);
        $this->deleteStored($old, $name);

        audit('UPDATE_PROFILE_PICTURE', 'User changed own profile picture.');
        $this->json(api_success('Your profile picture has been updated.', [
            'picture_url' => avatar_url($name),
            'has_picture' => true,
        ]));
    }

    public function removePicture()
    {
        if (!is_post()) {
            $this->json(api_error('Invalid request.'));
        }

        $Users = new Users();
        $old = $Users->pictureFor(user_id());

        $Users->setProfilePicture(user_id(), null);
        $this->deleteStored($old, null);

        audit('REMOVE_PROFILE_PICTURE', 'User removed own profile picture.');
        $this->json(api_success('Your profile picture has been removed.', [
            'picture_url' => avatar_url(null),
            'has_picture' => false,
        ]));
    }

    public function password()
    {
        $d = $_POST;
        $Users = new Users();
        $user  = $Users->findByUsername(auth_user()['username']);

        if (!$user || !password_verify($d['current_password'] ?? '', $user->password)) {
            $this->json(api_error('Current password is incorrect.'));
        }

        if (strlen($d['new_password'] ?? '') < 8) {
            $this->json(api_error('New password must be at least 8 characters.'));
        }

        if (($d['new_password'] ?? '') !== ($d['confirm_password'] ?? '')) {
            $this->json(api_error('New password confirmation does not match.'));
        }

        $Users->setPassword($user->id, $d['new_password']);

        audit('CHANGE_PASSWORD', 'User changed their own password.');

        try {
            (new ApiTokens())->revokeAllForUser((int) $user->id, auth_token_id());
        } catch (\Throwable $e) {
            error_log('token revoke failed: ' . $e->getMessage());
        }

        $this->json(api_success('Password updated successfully.'));
    }

    private function payload(): array
    {
        $Profiles = new Profiles();
        $profile = $Profiles->forUser((int) user_id());

        return [
            'full_name'   => $profile['full_name'],
            'picture_url' => $profile['picture_url'],
            'values'      => $Profiles->flatten($profile),
        ];
    }

    private function deleteStored(?string $file, ?string $keep): void
    {
        profile_image_delete($file, $keep);
    }
}
