<?php

namespace Api\Audit;

use Core\BaseController;
use Models\AuditLogs;
use Models\Users;

class AuditController extends BaseController
{
    public function __construct()
    {
        api_guard([Users::ADMIN]);
    }

    public function all()
    {
        $rows = (new AuditLogs())->find(1000);
        attach_avatar($rows);

        $this->json([
            'data' => $rows
        ]);
    }
}
