<?php

namespace Api\Licensures;

use Core\BaseController;
use Models\Licensures;
use Models\Users;

class LicensuresController extends BaseController
{
    private $Licensures;

    public function __construct()
    {
        api_guard([Users::ALUMNI]);
        $this->Licensures = new Licensures();
    }

    public function all()
    {
        $this->json(['data' => $this->Licensures->forAlumni(require_alumni_id())]);
    }

    public function add()
    {
        $this->save(null);
    }

    public function edit(?int $id = null)
    {
        $record = $this->ownRecord($id);

        if (is_post()) {
            $this->save((int) $record->id);
        }

        $this->json($record);
    }

    public function delete(?int $id = null)
    {
        $record = $this->ownRecord($id);

        if ($this->Licensures->delete($record->id)) {
            audit('DELETE_LICENSURE', 'Alumni deleted a licensure record.');
            $this->json(api_success('Licensure record deleted successfully.'));
        }

        $this->json(api_error('Unable to delete licensure record.'));
    }

    private function ownRecord(?int $id)
    {
        $record = $id ? $this->Licensures->findByID($id) : null;

        if (!$record || (int) $record->alumni_id !== require_alumni_id()) {
            api_deny(404, 'Licensure record not found.');
        }

        return $record;
    }

    private function save(?int $id): void
    {
        $d = input();

        if ($msg = $this->validate($d)) {
            $this->json(api_error($msg));
        }

        $data = $this->fields($d);
        $data['alumni_id'] = require_alumni_id();

        if ($id) {
            $data['id'] = $id;
        }

        if ($this->Licensures->save($data)) {
            audit('SAVE_LICENSURE', 'Alumni saved a licensure record.');
            $this->json(api_success('Licensure record' . ($id ? ' updated' : ' added') . ' successfully.'));
        }

        $this->json(api_error('Unable to save licensure record.'));
    }

    private function validate($d): ?string
    {
        if (empty($d['license_type_id']) || empty($d['status_id'])) {
            return 'License type and status are required.';
        }
        return null;
    }

    private function fields($d): array
    {
        return [
            'license_type_id'  => (int) $d['license_type_id'],
            'status_id'        => (int) $d['status_id'],
            'examination_year' => $d['examination_year'] ?: null,
        ];
    }
}
