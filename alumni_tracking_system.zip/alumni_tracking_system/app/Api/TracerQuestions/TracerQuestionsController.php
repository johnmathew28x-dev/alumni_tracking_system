<?php

namespace Api\TracerQuestions;

use Core\BaseController;
use Models\TracerQuestions;
use Models\TracerStudies;
use Models\Users;

class TracerQuestionsController extends BaseController
{
    private $Questions;

    public function __construct()
    {
        api_guard([Users::ADMIN]);
        $this->Questions = new TracerQuestions();
    }

    public function all($studyId = null)
    {
        $this->json([
            'data' => $this->Questions->forStudy((int) $studyId)
        ]);
    }

    public function add()
    {
        $this->persist(null);
    }

    public function edit($id = null)
    {
        $question = $this->Questions->findByID($id);
        if (!$question) {
            api_deny(404, 'Question not found.');
        }

        if (is_post()) {
            $this->persist($question->id, $question->tracer_study_id);
        }

        $question->options = str_replace('|', "\n", (string) $question->options);
        $this->json($question);
    }

    public function delete($id = null)
    {
        if (empty($id)) {
            $this->json(api_error('Question ID is required.'));
        }

        if ($this->Questions->delete($id)) {
            audit('DELETE_TRACER_QUESTION', "Deleted tracer question #{$id}");
            $this->json(api_success('Question deleted successfully.'));
        }

        $this->json(api_error('Unable to delete question.'));
    }

    private function persist($id, $studyId = null): void
    {
        $d = input();
        $studyId = $studyId ?: (int) ($d['tracer_study_id'] ?? 0);

        if (!$studyId || !(new TracerStudies())->findByID($studyId)) {
            $this->json(api_error('Tracer study not found.'));
        }

        if (empty($d['question'])) {
            $this->json(api_error('Question text is required.'));
        }

        $type = in_array($d['question_type'] ?? '', ['text', 'yes_no', 'multiple_choice', 'select'], true)
            ? $d['question_type']
            : 'text';

        $options = null;
        if (in_array($type, ['multiple_choice', 'select'], true)) {
            $lines = array_filter(array_map('trim', explode("\n", (string) ($d['options'] ?? ''))));
            if (count($lines) < 2) {
                $this->json(api_error('Please provide at least two options (one per line).'));
            }
            $options = implode('|', $lines);
        }

        $row = [
            'tracer_study_id' => $studyId,
            'question'        => $d['question'],
            'question_type'   => $type,
            'options'         => $options,
            'is_required'     => empty($d['is_required']) ? 0 : 1,
            'sort_order'      => (int) ($d['sort_order'] ?? 0),
        ];

        if ($id) {
            $row['id'] = $id;
        }

        if ($this->Questions->save($row)) {
            audit('SAVE_TRACER_QUESTION', "Saved question for study #{$studyId}");
            $this->json(api_success($id ? 'Question updated successfully.' : 'Question added successfully.'));
        }

        $this->json(api_error('Unable to save question.'));
    }
}