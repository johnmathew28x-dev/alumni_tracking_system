<?php

namespace Api\Reports;

use Core\BaseController;
use Models\Reports;
use Models\Users;

class ReportsController extends BaseController
{
    public function __construct()
    {
        api_guard([Users::ADMIN, Users::FACULTY, Users::QA]);
    }

    public function data($type = null)
    {
        $config = Reports::configFor((string) $type, user_role());

        if (!$config) {
            api_deny(404, 'Report not found.');
        }

        api_allow(...$config['roles']);

        $filters = [];
        foreach ($config['filters'] as $name) {
            $value = $_GET[$name] ?? '';
            $filters[$name] = is_string($value) ? trim($value) : '';
        }

        $method = $config['method'];
        $Reports = new Reports();

        $rows = $config['filters'] ? $Reports->$method($filters) : $Reports->$method();

        if (!empty($config['licensure_columns']) && !array_key_exists($config['licensure_columns'][0], $config['columns'])) {
            foreach ($rows as $row) {
                foreach ($config['licensure_columns'] as $c) {
                    unset($row->$c);
                }
            }
        }

        if ($rows && property_exists($rows[0], 'profile_picture')) {
            attach_avatar($rows);
        }

        $this->json(['data' => $rows]);
    }
}
