<?php

namespace Api\Users;

use Core\BaseController;
use Models\Users;

class UsersController extends BaseController
{
    private $Users;

    public function __construct()
    {
        api_guard([Users::ADMIN]);
        $this->Users = new Users();
    }

    public function all()
    {
        $rows = $this->Users->find();
        attach_avatar($rows);

        $this->json([
            'data' => $rows
        ]);
    }

    public function add()
    {
        $data = input();

        if ($msg = $this->validate($data, null)) {
            $this->json(api_error($msg));
        }

        if (strlen($data['password'] ?? '') < 8) {
            $this->json(api_error('Password must be at least 8 characters.'));
        }

        $isAlumni = $data['role'] === Users::ALUMNI;

        $saved = $this->Users->createUser(
            [
                'username' => $data['username'],
                'email'    => $data['email'],
                'password' => $data['password'],
                'role'     => $data['role'],
                'status'   => 'active',
            ],
            $isAlumni ? [
                'first_name'          => $data['first_name'] ?: 'New',
                'last_name'           => $data['last_name'] ?: 'Alumni',
                'email'               => $data['email'],
                'verification_status' => 'verified',
            ] : null
        );

        if (!$saved) {
            $this->json(api_error('Unable to save user.'));
        }

        audit('CREATE_USER', "Created system user: {$data['username']}");
        $this->json(api_success('User added successfully.'));
    }

    public function edit($id = null)
    {
        $user = $this->Users->findByID($id);
        if (!$user) {
            api_deny(404, 'User not found.');
        }

        if (is_post()) {
            $data = input();
            $data['username'] = $user->username;

            if ($msg = $this->validate($data, $user->id)) {
                $this->json(api_error($msg));
            }

            if (!empty($data['password']) && strlen($data['password']) < 8) {
                $this->json(api_error('Password must be at least 8 characters.'));
            }

            if ((int) $user->id === (int) user_id() && $data['role'] !== Users::ADMIN) {
                $this->json(api_error('You cannot remove your own administrator role.'));
            }

            if ($this->Users->save([
                'id'       => $user->id,
                'username' => $user->username,
                'email'    => $data['email'],
                'role'     => $data['role'],
                'password' => $data['password'] ?? '',
            ])) {
                audit('UPDATE_USER', "Updated user #{$user->id} ({$user->username})");
                $this->json(api_success('User updated successfully.'));
            }

            $this->json(api_error('Unable to save user.'));
        }

        $this->json($user);
    }

    public function toggle($id = null)
    {
        $user = $this->Users->findByID($id);
        if (!$user) {
            api_deny(404, 'User not found.');
        }

        if ((int) $user->id === (int) user_id()) {
            $this->json(api_error('You cannot deactivate your own account.'));
        }

        $status = $user->status === 'active' ? 'inactive' : 'active';
        $this->Users->setStatus($user->id, $status);

        audit('TOGGLE_USER_STATUS', "Set user #{$user->id} status to {$status}");
        $this->json(api_success('User is now ' . $status . '.'));
    }

    public function delete($id = null)
    {
        $user = $this->Users->findByID($id);
        if (!$user) {
            api_deny(404, 'User not found.');
        }

        if ((int) $user->id === (int) user_id()) {
            $this->json(api_error('You cannot delete your own account.'));
        }

        try {
            if ($this->Users->delete($user->id)) {
                audit('DELETE_USER', "Deleted user {$user->username}");
                $this->json(api_success('User deleted successfully.'));
            }
        } catch (\PDOException $e) {
            $this->json(api_error('This user has linked records and cannot be deleted. Deactivate the account instead.'));
        }

        $this->json(api_error('Unable to delete user.'));
    }

    private function validate($d, $exceptId): ?string
    {
        if (empty($d['username'])) {
            return 'Username is required.';
        }

        if (!filter_var($d['email'] ?? '', FILTER_VALIDATE_EMAIL)) {
            return 'A valid email address is required.';
        }

        if (!in_array($d['role'] ?? '', Users::ROLES, true)) {
            return 'Role is required.';
        }

        if ($this->Users->usernameExists($d['username'], $exceptId)) {
            return 'Username is already taken.';
        }

        if ($this->Users->emailExists($d['email'], $exceptId)) {
            return 'Email is already registered.';
        }

        return null;
    }
}