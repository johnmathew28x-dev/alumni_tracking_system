<?php

namespace Api\Announcements;

use Core\BaseController;
use Models\Announcements;
use Models\Users;

class AnnouncementsController extends BaseController
{
    private $Announcements;

    public function __construct()
    {
        api_guard([Users::ADMIN]);
        $this->Announcements = new Announcements();
    }

    public function all()
    {
        $this->json([
            'data' => $this->Announcements->find()
        ]);
    }

    public function add()
    {
        $data = input();

        if (empty($data['title']) || empty($data['content'])) {
            $this->json(api_error('Title and content are required.'));
        }

        if ($this->Announcements->save([
            'title'      => $data['title'],
            'content'    => $data['content'],
            'created_by' => user_id(),
            'status'     => 'draft',
        ])) {
            audit('CREATE_ANNOUNCEMENT', 'Created announcement: ' . $data['title']);
            $this->json(api_success('Announcement added as a draft. Publish it to make it visible to alumni.'));
        }

        $this->json(api_error('Unable to save announcement.'));
    }

    public function edit($id = null)
    {
        $announcement = $this->Announcements->findByID($id);

        if (!$announcement) {
            api_deny(404, 'Announcement not found.');
        }

        if (is_post()) {
            $data = input();

            if (empty($data['title']) || empty($data['content'])) {
                $this->json(api_error('Title and content are required.'));
            }

            if ($this->Announcements->save([
                'id'      => $announcement->id,
                'title'   => $data['title'],
                'content' => $data['content'],
            ])) {
                audit('UPDATE_ANNOUNCEMENT', "Updated announcement #{$announcement->id}");
                $this->json(api_success('Announcement updated successfully.'));
            }

            $this->json(api_error('Unable to save announcement.'));
        }

        $this->json($announcement);
    }

    public function toggle($id = null)
    {
        $announcement = $this->Announcements->findByID($id);

        if (!$announcement) {
            api_deny(404, 'Announcement not found.');
        }

        $publish = $announcement->status !== 'published';
        $this->Announcements->setPublished($announcement->id, $publish);

        audit('TOGGLE_ANNOUNCEMENT', "Toggled publish state for announcement #{$announcement->id}");
        $this->json(api_success($publish ? 'Announcement published.' : 'Announcement unpublished.'));
    }

    public function delete($id = null)
    {
        if (empty($id)) {
            $this->json(api_error('Announcement ID is required.'));
        }

        if ($this->Announcements->delete($id)) {
            audit('DELETE_ANNOUNCEMENT', "Deleted announcement #{$id}");
            $this->json(api_success('Announcement deleted successfully.'));
        }

        $this->json(api_error('Unable to delete announcement.'));
    }
}