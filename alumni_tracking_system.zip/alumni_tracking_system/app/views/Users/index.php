<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title">System Users</h3>
        <div class="card-tools">
            <button type="button" class="btn btn-primary btn-sm" data-crud-add>
                <i class="fas fa-plus"></i> Add User
            </button>
        </div>
    </div>
    <div class="card-body">
        <table id="users-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>

<div class="modal fade" id="users-modal" tabindex="-1">
    <div class="modal-dialog">
        <form id="users-form" class="modal-content" autocomplete="off">
            <div class="modal-header">
                <h5 class="modal-title">Add User</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" class="form-control" required>
                    <small class="text-muted edit-only d-none">Usernames cannot be changed.</small>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Role</label>
                    <select name="role" id="user-role" class="form-control" required>
                        <option value="">Select role</option>
                        <?php foreach ($roles as $r): ?>
                            <option value="<?= e($r) ?>"><?= e($r) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-row alumni-only d-none">
                    <div class="form-group col-6">
                        <label>First Name</label>
                        <input type="text" name="first_name" class="form-control">
                    </div>
                    <div class="form-group col-6">
                        <label>Last Name</label>
                        <input type="text" name="last_name" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" minlength="8" autocomplete="new-password">
                    <small class="text-muted edit-only d-none">Leave blank to keep the current password.</small>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>
