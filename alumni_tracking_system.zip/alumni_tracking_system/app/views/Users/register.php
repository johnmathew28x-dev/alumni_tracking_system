<div class="card">
    <div class="card-body" style="background: transparent;">
        <p class="login-box-msg">First-time setup: create the administrator account</p>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
        <?php endif; ?>

        <form action="<?= BASE_URL ?>/Users/register" method="POST">
            <input type="hidden" name="_csrfToken" value="<?= e(csrf_token()) ?>">

            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" value="<?= e($old['username'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" value="<?= e($old['email'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" minlength="8" required>
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control" minlength="8" required>
            </div>

            <button type="submit" class="btn btn-primary btn-block">Create Administrator</button>
        </form>
    </div>
</div>
