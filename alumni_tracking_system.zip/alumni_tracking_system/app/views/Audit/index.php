<div class="card card-primary card-outline">
    <div class="card-header"><h3 class="card-title">System Activity (latest 1,000 events)</h3></div>
    <div class="card-body">
        <table id="audit-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>
