<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title">Events</h3>
        <div class="card-tools">
            <button type="button" class="btn btn-primary btn-sm" data-crud-add>
                <i class="fas fa-plus"></i> Add Event
            </button>
        </div>
    </div>
    <div class="card-body">
        <table id="events-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>

<div class="modal fade" id="events-modal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form id="events-form" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Event</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            
            <div class="modal-body">
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" class="form-control" required>
                </div>

                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control" rows="3"></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label>Event Date</label>
                        <input type="date" name="event_date" class="form-control" required>
                    </div>
                    
                    <div class="form-group col-md-4">
                        <label>Event Time</label>
                        <input type="time" name="event_time" class="form-control">
                    </div>
                    
                    <div class="form-group col-md-4">
                        <label>Registration Deadline</label>
                        <input type="date" name="registration_deadline" class="form-control">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-8">
                        <label>Location</label>
                        <input type="text" name="location" class="form-control">
                    </div>
                    
                    <div class="form-group col-md-4">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <?php foreach (['upcoming', 'ongoing', 'completed', 'cancelled'] as $s): ?>
                                <option value="<?= $s ?>"><?= ucfirst($s) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="participants-modal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Participants</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table id="participants-table" class="table table-sm table-bordered w-100"></table>
            </div>
        </div>
    </div>
</div>