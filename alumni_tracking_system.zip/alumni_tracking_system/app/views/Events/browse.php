<?php if (empty($events)): ?>
    <div class="alert alert-info">There are no upcoming events at this time.</div>
<?php endif; ?>

<div class="row">
    <?php foreach ($events as $ev): ?>
        <div class="col-md-6 mb-4">
            <div class="card record-card h-100">
                <div class="card-body d-flex flex-column">
                    <h5 class="mb-1"><?= e($ev->title) ?></h5>
                    
                    <div class="text-muted small mb-2">
                        <div>
                            <i class="far fa-calendar"></i> 
                            <?= date('F d, Y', strtotime($ev->event_date)) ?>
                            <?php if ($ev->event_time): ?> 
                                at <?= date('g:i A', strtotime($ev->event_time)) ?>
                            <?php endif; ?>
                        </div>
                        
                        <div>
                            <i class="fas fa-map-marker-alt"></i> 
                            <?= e($ev->location ?: 'TBA') ?>
                        </div>
                        
                        <?php if ($ev->registration_deadline): ?>
                            <div>
                                <i class="far fa-clock"></i> 
                                Register by <?= date('M d, Y', strtotime($ev->registration_deadline)) ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <p class="flex-grow-1 pre-line"><?= e($ev->description) ?></p>

                    <div>
                        <?php if ($ev->is_registered): ?>
                            <span class="badge badge-success p-2 mr-2">
                                <i class="fas fa-check"></i> You are registered
                            </span>
                            <button type="button" class="btn btn-sm btn-outline-danger cancel-btn" data-id="<?= (int) $ev->id ?>">
                                Cancel Registration
                            </button>
                        <?php elseif ($ev->registration_deadline && strtotime($ev->registration_deadline) < strtotime('today')): ?>
                            <span class="badge badge-secondary p-2">Registration Closed</span>
                        <?php else: ?>
                            <button type="button" class="btn btn-sm btn-primary register-btn" data-id="<?= (int) $ev->id ?>">
                                Register
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>