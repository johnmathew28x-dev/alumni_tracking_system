<?php

use Core\Auth;
use Models\Alumni;
use Models\CorrectionRequests;
use Models\Users;

$title     = $title ?? 'Dashboard';
$user      = Auth::user();
$scripts   = (array) ($script ?? []);
$navAvatar = avatar_url((new Users())->pictureFor($user['id']));

$link  = fn(string $label, string $icon, string $url, array $options = []) =>
    ['label' => $label, 'icon' => $icon, 'url' => $url] + $options;
$group = fn(string $label, string $icon, array $children) =>
    ['label' => $label, 'icon' => $icon, 'children' => $children];

$dashboard = $link('Dashboard', 'fa-tachometer-alt', 'Dashboard');

$pendingCount = $user['role'] === Users::ADMIN
    ? (new Alumni())->countByVerification('pending') + (new CorrectionRequests())->countPending()
    : 0;

switch ($user['role']) {
        case Users::ADMIN:
            $menu = [
                $dashboard,
                $group('Alumni Management', 'fa-user-graduate', [
                    $link('All Alumni', 'fa-list', 'Alumni', ['except' => ['Alumni/pending']]),
                    $link('Pending Verification', 'fa-user-check', 'Alumni/pending', ['badge' => $pendingCount]),
                ]),
                $group('Graduate Tracer', 'fa-poll', [
                    $link('Survey Periods', 'fa-clipboard-list', 'Tracer', ['except' => ['Tracer/responses', 'Tracer/stats', 'Tracer/gtsResponses']]),
                    $link('GTS Responses', 'fa-list-alt', 'Tracer/gtsResponses'),
                    $link('Analytics', 'fa-chart-pie', 'Analytics'),
                    $link('Custom Study Results', 'fa-chart-bar', 'Tracer/responses', ['also' => ['Tracer/stats']]),
                ]),
                $group('Engagement', 'fa-comments', [
                    $link('Announcements', 'fa-bullhorn', 'Announcements'),
                    $link('Events', 'fa-calendar-alt', 'Events'),
                    $link('Jobs', 'fa-briefcase', 'Jobs'),
                ]),
                $group('Reports', 'fa-file-alt', [
                    $link('Alumni Report', 'fa-users', 'Reports/alumni'),
                    $link('Tracer Study Report', 'fa-poll', 'Reports/tracer'),
                    $link('Program Report', 'fa-book', 'Reports/program'),
                    $link('Engagement Report', 'fa-comments', 'Reports/engagement'),
                ]),
                $group('System', 'fa-cogs', [
                    $link('Reference Data', 'fa-database', 'Reference'),
                    $link('Users', 'fa-users-cog', 'Users'),
                    $link('Audit Logs', 'fa-history', 'Audit'),
                ]),
            ];
            break;

        case Users::ALUMNI:
            $menu = [
                $dashboard,
                $group('My Records', 'fa-folder-open', [
                    $link('Academic Info', 'fa-book', 'Academics'),
                    $link('Employment', 'fa-briefcase', 'Employments'),
                    $link('Licensure', 'fa-id-badge', 'Licensures'),
                    $link('Trainings / Adv Studies', 'fa-chalkboard-teacher', 'Trainings'),
                    $link('Graduate Tracer Survey', 'fa-clipboard-list', 'Tracer'),
                ]),
                $group('Community', 'fa-globe', [
                    $link('Announcements', 'fa-bullhorn', 'Announcements'),
                    $link('Events', 'fa-calendar-alt', 'Events'),
                    $link('Job Opportunities', 'fa-briefcase', 'Jobs'),
                ]),
            ];
            break;

        case Users::FACULTY:
            $menu = [
                $dashboard,
                $link('View Alumni', 'fa-user-graduate', 'Alumni'),
                $link('Tracer Analytics', 'fa-chart-pie', 'Analytics'),
                $group('Reports', 'fa-file-alt', [
                    $link('Alumni Report', 'fa-users', 'Reports/alumni'),
                    $link('Tracer Study Report', 'fa-poll', 'Reports/tracer'),
                ]),
            ];
            break;

        case Users::QA:
            $menu = [
                $dashboard,
                $group('Accreditation Reports', 'fa-award', [
                    $link('Tracer Analytics', 'fa-chart-pie', 'Analytics'),
                    $link('Alumni Report', 'fa-users', 'Reports/alumni'),
                    $link('Tracer Study Report', 'fa-poll', 'Reports/tracer'),
                    $link('Program Report', 'fa-book', 'Reports/program'),
                ]),
            ];
            break;

        default:
            $menu = [$dashboard];
    }

$menu[] = ['header' => 'Account'];
$menu[] = $link('My Profile', 'fa-id-card', 'Profile', ['except' => ['Profile/settings']]);
$menu[] = $link('Account Settings', 'fa-key', 'Profile/settings');

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$base = parse_url(BASE_URL, PHP_URL_PATH);

if ($base && str_starts_with($path, $base)) {
    $path = substr($path, strlen($base));
}

$path = '/' . strtolower(trim($path, '/'));
$path = $path === '/' ? '/dashboard' : $path;

$matches  = function (string $url) use ($path): bool {
    $url = '/' . strtolower(trim($url, '/'));
    return $path === $url || str_starts_with($path, $url . '/');
};
$isActive = function (array $item) use ($matches): bool {
    foreach ($item['except'] ?? [] as $skip) {
        if ($matches($skip)) {
            return false;
        }
    }

    foreach (array_merge([$item['url']], $item['also'] ?? []) as $url) {
        if ($matches($url)) {
            return true;
        }
    }

    return false;
};
$hasActiveChild = function (array $group) use ($isActive): bool {
    foreach ($group['children'] as $child) {
        if ($isActive($child)) {
            return true;
        }
    }

    return false;
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
  <title><?= e($title) ?> | <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <link rel="stylesheet" href="<?= BASE_URL ?>/plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button">
                    <i class="fas fa-bars"></i>
                </a>
            </li>
        </ul>

        <ul class="navbar-nav ml-auto align-items-center">
            <li class="nav-item d-none d-sm-block">
                <a class="nav-link text-muted" href="<?= BASE_URL ?>/Profile" title="My profile">
                    <img src="<?= e($navAvatar) ?>" alt="" class="nav-avatar js-avatar-nav">
                    <span class="js-username"><?= e($user['username']) ?></span>
                    <span class="badge badge-secondary ml-1"><?= e($user['role']) ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL ?>/Profile/settings" title="Account settings">
                    <i class="fas fa-key"></i>
                </a>
            </li>
            <li class="nav-item">
                <form action="<?= BASE_URL ?>/Auth/logout" method="POST" class="m-0">
                    <input type="hidden" name="_csrfToken" value="<?= e(csrf_token()) ?>">
                    <button class="btn btn-link nav-link" type="submit">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </button>
                </form>
            </li>
        </ul>
    </nav>

    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="<?= BASE_URL ?>/" class="brand-link">
            <img src="<?= BASE_URL ?>/img/logo.webp" alt="NEC Logo" class="brand-image">
            <span class="brand-text font-weight-light"><?= e(APP_NAME) ?></span>
        </a>

        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                    <?php foreach ($menu as $item): ?>
                        <?php if (isset($item['header'])): ?>
                            <li class="nav-header"><?= e(strtoupper($item['header'])) ?></li>
                        <?php elseif (isset($item['children'])): ?>
                            <?php $open = $hasActiveChild($item); ?>
                            <li class="nav-item <?= $open ? 'menu-open' : '' ?>">
                                <a href="#" class="nav-link <?= $open ? 'active' : '' ?>">
                                    <i class="nav-icon fas <?= e($item['icon']) ?>"></i>
                                    <?php $groupBadge = (int) array_sum(array_column($item['children'], 'badge')); ?>
                                    <p>
                                        <?= e($item['label']) ?>
                                        <i class="right fas fa-angle-left"></i>
                                        <?php if ($groupBadge > 0): ?>
                                            <span class="badge badge-warning right"><?= $groupBadge ?></span>
                                        <?php endif; ?>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <?php foreach ($item['children'] as $child): ?>
                                        <li class="nav-item">
                                            <a href="<?= BASE_URL ?>/<?= e($child['url']) ?>"
                                               class="nav-link <?= $isActive($child) ? 'active' : '' ?>">
                                                <i class="far fa-circle nav-icon"></i>
                                                <p>
                                                    <?= e($child['label']) ?>
                                                    <?php if (!empty($child['badge'])): ?>
                                                        <span class="badge badge-warning right"><?= (int) $child['badge'] ?></span>
                                                    <?php endif; ?>
                                                </p>
                                            </a>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a href="<?= BASE_URL ?>/<?= e($item['url']) ?>"
                                   class="nav-link <?= $isActive($item) ? 'active' : '' ?>">
                                    <i class="nav-icon fas <?= e($item['icon']) ?>"></i>
                                    <p><?= e($item['label']) ?></p>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
            </nav>
        </div>
    </aside>

    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <h1><?= e($title) ?></h1>
            </div>
        </section>

        <section class="content">
            <div class="container-fluid">
                <?php

                foreach (['success' => 'success', 'error' => 'danger', 'info' => 'info'] as $key => $class):
                    if (!empty($_SESSION[$key])):
                ?>
                    <div class="alert alert-<?= $class ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <?= e($_SESSION[$key]) ?>
                    </div>
                <?php
                        unset($_SESSION[$key]);
                    endif;
                endforeach;
                ?>
                <?= $content ?>
            </div>
        </section>
    </div>

    <footer class="main-footer text-sm">
        <strong><?= e(APP_FULL_NAME) ?></strong> &middot; College of Education
    </footer>
</div>

<script src="<?= BASE_URL ?>/plugins/jquery/jquery.min.js"></script>
<script src="<?= BASE_URL ?>/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>/plugins/sweetalert2/sweetalert2.min.js"></script>
<script src="<?= BASE_URL ?>/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?= BASE_URL ?>/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?= BASE_URL ?>/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?= BASE_URL ?>/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?= BASE_URL ?>/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?= BASE_URL ?>/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?= BASE_URL ?>/plugins/jszip/jszip.min.js"></script>
<script src="<?= BASE_URL ?>/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?= BASE_URL ?>/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?= BASE_URL ?>/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?= BASE_URL ?>/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?= BASE_URL ?>/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

<?php if (!empty($charts)): ?>
<script src="<?= BASE_URL ?>/plugins/chart.js/Chart.min.js"></script>
<?php endif; ?>

<script src="<?= BASE_URL ?>/dist/js/adminlte.min.js"></script>
<script>window.PAGE = <?= json_encode($pageData ?? new stdClass, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<script src="<?= BASE_URL ?>/js/app.js"></script>
<?php foreach ($scripts as $file): ?>
<script src="<?= BASE_URL ?>/js/<?= e($file) ?>.js"></script>
<?php endforeach; ?>
</body>
</html>
