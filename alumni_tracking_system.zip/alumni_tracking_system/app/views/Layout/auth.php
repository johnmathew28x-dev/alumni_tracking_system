<?php
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?= htmlspecialchars($title ?? 'Login') ?> | <?= APP_NAME ?></title>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <link rel="stylesheet" href="<?= BASE_URL ?>/plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/css/auth.css">
</head>

<body class="hold-transition login-page">

    <div class="auth-wrapper">
        <div class="auth-card">
            <div class="text-center mb-3 text-white">
                <img src="<?= BASE_URL ?>/img/logo.webp" alt="College of Education Logo" class="auth-logo mb-2">
                <h4 class="font-weight-bold mb-0">College of Education</h4>
                <span>Alumni Tracking System</span>
            </div>

            <?= $content ?>
        </div>
    </div>

    <script src="<?= BASE_URL ?>/plugins/jquery/jquery.min.js"></script>
    <script src="<?= BASE_URL ?>/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>