<?php use Core\Auth; ?>

<div class="row">
    <?php
    $boxes = [
        ['Total Alumni', $stats['total'], 'bg-info', 'fa-user-graduate'],
        ['Verified', $stats['verified'], 'bg-success', 'fa-user-check'],
        ['Employed', $stats['employed'], 'bg-primary', 'fa-briefcase'],
        ['LET Passers', $stats['let'], 'bg-warning', 'fa-certificate'],
    ];
    foreach ($boxes as [$label, $value, $bg, $icon]): ?>
        <div class="col-lg-3 col-6">
            <div class="small-box <?= $bg ?>">
                <div class="inner">
                    <h3><?= (int) $value ?></h3>
                    <p><?= e($label) ?></p>
                </div>
                <div class="icon">
                    <i class="fas <?= $icon ?>"></i>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="card card-outline card-primary">
    <div class="card-body">
        <p class="mb-2">
            Welcome, <strong><?= e(Auth::user()['username']) ?></strong> (<?= e(Auth::user()['role']) ?>).
        </p>
        <p class="mb-0 text-muted">
            Use the menu to open the reports available to your role. Every report can be filtered and exported to Excel, PDF or printed.
        </p>
    </div>
</div>