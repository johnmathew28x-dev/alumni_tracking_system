<?php 
$k = $gts['kpis']; 
$part = $gts['participation']; 
$pc = fn($x) => $x === null ? 'n/a' : $x . '%'; 
?>

<div class="card card-outline card-primary">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fas fa-poll mr-1"></i> Graduate Tracer Outcomes (submitted surveys)
        </h3>
        <div class="card-tools">
            <a href="<?= BASE_URL ?>/Analytics" class="btn btn-sm btn-primary">Open analytics &amp; charts</a>
        </div>
    </div>
    <div class="card-body">
        <?php if (!$k['reliable']): ?>
            <div class="alert alert-warning py-2">
                Only <?= (int) $k['respondents'] ?> submitted survey(s) so far - percentages are not yet reliable.
            </div>
        <?php endif; ?>

        <div class="row text-center">
            <?php foreach ([
                ['Surveys submitted', $k['respondents']], 
                ['Completion rate', $pc($part['rate'])], 
                ['Employment rate', $pc($k['employment_rate'])],
                ['Employed', $k['employed']], 
                ['Not currently employed', $k['not_employed']], 
                ['Never employed', $k['never_employed']],
                ['Self-employed', $k['self_employed']], 
                ['Local / Overseas', $k['local'] . ' / ' . $k['abroad']],
                ['Degree-related', $k['related'] . ' (' . $pc($k['related_rate']) . ')'], 
                ['Not degree-related', $k['not_related']],
                ['Curriculum relevant', $pc($k['relevance_rate'])],
            ] as [$label, $value]): ?>
                <div class="col-md-2 col-4 mb-3">
                    <div class="h4 mb-0"><?= e($value) ?></div>
                    <div class="small text-muted"><?= e($label) ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<div class="row">
    <?php
    $boxes = [
        ['Total Alumni', $stats['total'], 'bg-info', 'fa-user-graduate', 'Alumni'],
        ['Pending Verification', $stats['pending'], 'bg-warning', 'fa-user-clock', 'Alumni/pending'],
        ['Employed', $stats['employed'], 'bg-success', 'fa-briefcase', 'Reports/alumni'],
        ['Unemployed', $stats['unemployed'], 'bg-danger', 'fa-user-times', 'Reports/alumni'],
        ['LET Passers', $stats['let'], 'bg-primary', 'fa-certificate', 'Reports/alumni'],
        ['Upcoming Events', $stats['events'], 'bg-secondary', 'fa-calendar-alt', 'Events'],
        ['Open Job Postings', $stats['jobs'], 'bg-teal', 'fa-briefcase', 'Jobs'],
        ['Active Tracer Responses', $stats['responses'], 'bg-indigo', 'fa-poll', 'Tracer/responses'],
    ];
    foreach ($boxes as [$label, $value, $bg, $icon, $link]): ?>
        <div class="col-lg-3 col-6">
            <div class="small-box <?= $bg ?>">
                <div class="inner">
                    <h3><?= (int) $value ?></h3>
                    <p><?= e($label) ?></p>
                </div>
                <div class="icon">
                    <i class="fas <?= $icon ?>"></i>
                </div>
                <a href="<?= BASE_URL ?>/<?= $link ?>" class="small-box-footer">
                    More info <i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="row">
    <div class="col-lg-7">
        <div class="card card-outline card-warning">
            <div class="card-header">
                <h3 class="card-title">Awaiting Verification</h3>
                <div class="card-tools">
                    <a href="<?= BASE_URL ?>/Alumni/pending" class="btn btn-sm btn-outline-primary">View all</a>
                </div>
            </div>
            <div class="card-body p-0">
                <table class="table table-sm mb-0">
                    <thead>
                        <tr>
                            <th>Alumni ID</th>
                            <th>Name</th>
                            <th>Program</th>
                            <th>Year</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$pending): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted py-3">No pending alumni. All caught up!</td>
                            </tr>
                        <?php endif; ?>
                        
                        <?php foreach ($pending as $a): ?>
                            <tr>
                                <td><?= e($a->alumni_id) ?></td>
                                <td><?= e($a->last_name) ?>, <?= e($a->first_name) ?></td>
                                <td><?= e($a->program_code ?: '—') ?></td>
                                <td><?= e($a->graduation_year ?: '—') ?></td>
                                <td class="text-right">
                                    <a class="btn btn-xs btn-outline-primary" href="<?= BASE_URL ?>/Alumni/details/<?= (int) $a->id ?>">Review</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="card card-outline card-primary">
            <div class="card-header">
                <h3 class="card-title">Latest Announcements</h3>
            </div>
            <div class="card-body">
                <?php if (!$announcements): ?>
                    <p class="text-muted mb-0">No published announcements yet.</p>
                <?php endif; ?>

                <?php foreach ($announcements as $a): ?>
                    <div class="mb-3">
                        <strong><?= e($a->title) ?></strong>
                        <div class="text-muted small"><?= date('M d, Y', strtotime($a->published_at)) ?></div>
                        <div class="small pre-line"><?= e(str_limit($a->content, 140)) ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>