<?php
$badge = [
    'verified' => 'success', 
    'pending' => 'warning', 
    'rejected' => 'danger'
][$me->verification_status ?? ''] ?? 'secondary';
?>

<div class="card card-outline card-primary">
    <div class="card-body d-flex flex-wrap justify-content-between align-items-center">
        <div>
            <h4 class="mb-1">Welcome, <?= e($me->first_name ?? '') ?>!</h4>
            <div class="text-muted">Alumni ID: <?= e($me->alumni_id ?? '—') ?></div>
        </div>
        <div>
            Verification:
            <span class="badge badge-<?= $badge ?> p-2"><?= e(ucfirst($me->verification_status ?? 'unknown')) ?></span>
        </div>
    </div>
</div>

<?php if (($me->verification_status ?? '') === 'pending'): ?>
    <div class="alert alert-warning">
        Your alumni record is waiting for verification by the administrator.
    </div>
<?php endif; ?>

<?php $pendingStudies = array_filter($studies, fn($s) => !$s->answered); ?>
<?php if ($pendingStudies): ?>
    <div class="alert alert-info d-flex justify-content-between align-items-center">
        <span>
            <i class="fas fa-clipboard-list mr-1"></i> 
            You have <?= count($pendingStudies) ?> tracer stud<?= count($pendingStudies) === 1 ? 'y' : 'ies' ?> waiting for your response.
        </span>
        <a href="<?= BASE_URL ?>/Tracer" class="btn btn-sm btn-primary">Answer now</a>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-6">
        <div class="card card-outline card-primary">
            <div class="card-header">
                <h3 class="card-title">Announcements</h3>
            </div>
            <div class="card-body">
                <?php if (!$announcements): ?>
                    <p class="text-muted mb-0">No announcements yet.</p>
                <?php endif; ?>

                <?php foreach ($announcements as $a): ?>
                    <div class="mb-3">
                        <strong><?= e($a->title) ?></strong>
                        <div class="text-muted small"><?= date('M d, Y', strtotime($a->published_at)) ?></div>
                        <div class="small pre-line"><?= e(str_limit($a->content, 160)) ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card card-outline card-info">
            <div class="card-header">
                <h3 class="card-title">Upcoming Events</h3>
            </div>
            <div class="card-body">
                <?php if (!$events): ?>
                    <p class="text-muted mb-0">No upcoming events.</p>
                <?php endif; ?>

                <?php foreach ($events as $ev): ?>
                    <div class="mb-3">
                        <strong><?= e($ev->title) ?></strong>
                        <?php if ($ev->is_registered): ?>
                            <span class="badge badge-success ml-1">Registered</span>
                        <?php endif; ?>
                        <div class="text-muted small">
                            <i class="far fa-calendar"></i> <?= date('F d, Y', strtotime($ev->event_date)) ?>
                            &middot; 
                            <i class="fas fa-map-marker-alt"></i> <?= e($ev->location ?: 'TBA') ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<div class="card card-outline card-success">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fas fa-user-check mr-1"></i> My Event Attendance
        </h3>
    </div>
    <div class="card-body">
        <?php if ($attendance['total'] === 0): ?>
            <p class="text-muted mb-0">No events have been completed yet, so there is no attendance to show.</p>
        <?php else: ?>
            <p class="mb-2">
                You attended <strong><?= (int) $attendance['attended'] ?></strong> of
                <strong><?= (int) $attendance['total'] ?></strong> completed event<?= $attendance['total'] === 1 ? '' : 's' ?>
                (<strong><?= e($attendance['rate']) ?>%</strong>).
            </p>

            <?php if ($attended): ?>
                <ul class="list-unstyled small mb-0">
                    <?php foreach ($attended as $ev): ?>
                        <li>
                            <i class="fas fa-check text-success"></i> 
                            <?= e($ev->title) ?> &middot; <?= date('M d, Y', strtotime($ev->event_date)) ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>