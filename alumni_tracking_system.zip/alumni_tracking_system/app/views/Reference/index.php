<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title">Reference Data &amp; Survey Choices</h3>
        <div class="card-tools">
            <button type="button" class="btn btn-primary btn-sm" id="ref-add">
                <i class="fas fa-plus"></i> Add
            </button>
        </div>
    </div>
    <div class="card-body">
        <div class="form-group" style="max-width: 420px;">
            <label>List</label>
            <select id="ref-table" class="form-control">
                <?php foreach ($tables as $key => $label): ?>
                    <option value="<?= e($key) ?>"><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <p class="text-muted small">
            Survey choices that already have answers are <strong>hidden</strong> rather than deleted, so earlier surveys keep their meaning.
            Programs and departments can be deleted only when nothing uses them.
        </p>
        <table id="ref-grid" class="table table-bordered table-striped w-100"></table>
    </div>
</div>

<div class="modal fade" id="ref-modal" tabindex="-1">
    <div class="modal-dialog">
        <form id="ref-form" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="ref-field f-name">
                    <div class="form-group">
                        <label>Name / Label</label>
                        <input type="text" name="name" class="form-control" maxlength="150">
                    </div>
                    <div class="form-row">
                        <div class="form-group col-6">
                            <label>Sort order</label>
                            <input type="number" name="sort_order" class="form-control" value="0">
                        </div>
                        <div class="form-group col-6 d-flex align-items-end">
                            <div class="custom-control custom-checkbox mb-2">
                                <input type="checkbox" class="custom-control-input" id="ref_is_other" name="is_other" value="1">
                                <label class="custom-control-label" for="ref_is_other">"Other" (alumni type their own text)</label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="ref-field f-reason">
                    <div class="form-group">
                        <label>Reason type</label>
                        <select name="reason_type" class="form-control">
                            <option value="accept">Accepting a job</option>
                            <option value="change">Changing jobs</option>
                        </select>
                    </div>
                </div>

                <div class="ref-field f-program">
                    <div class="form-group">
                        <label>Program code</label>
                        <input type="text" name="program_code" class="form-control" maxlength="20">
                    </div>
                    <div class="form-group">
                        <label>Program name</label>
                        <input type="text" name="program_name" class="form-control" maxlength="150">
                    </div>
                    <div class="form-group">
                        <label>Department</label>
                        <select name="department_id" class="form-control">
                            <?php foreach ($departments as $d): ?>
                                <option value="<?= (int) $d->id ?>"><?= e($d->department_name) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="ref-field f-dept">
                    <div class="form-group">
                        <label>Department name</label>
                        <input type="text" name="department_name" class="form-control" maxlength="150">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>