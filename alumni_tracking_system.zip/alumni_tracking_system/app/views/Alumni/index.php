<?php if (!empty($canEdit) && $status === 'pending'): ?>
<div class="card card-outline card-warning" id="corrections-card">
    <div class="card-header">
        <h3 class="card-title">Correction Requests</h3>
        <div class="card-tools">
            <label class="sr-only" for="corr-status">Filter by status</label>
            <select id="corr-status" class="form-control form-control-sm">
                <option value="pending" selected>Pending</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
                <option value="">All</option>
            </select>
        </div>
    </div>
    <div class="card-body">
        <table id="corrections-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>

<div class="modal fade" id="correction-review-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Review Correction Request</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <div id="corr-summary" class="mb-2"></div>
                <div id="corr-changes" class="table-responsive"></div>
                <div class="mb-3"><strong>Reason given:</strong> <span id="corr-reason"></span></div>
                <div class="form-group mb-0">
                    <label for="corr-note">Review note <span class="text-muted small">(required when rejecting; shown to the alumnus)</span></label>
                    <textarea id="corr-note" class="form-control" rows="2" maxlength="500"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" id="corr-reject" class="btn btn-danger"><i class="fas fa-times"></i> Reject</button>
                <button type="button" id="corr-approve" class="btn btn-success"><i class="fas fa-check"></i> Approve &amp; Apply</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="card card-outline card-primary">
    <div class="card-body">
        <form id="filter-form" class="form-row mb-2" autocomplete="off" onsubmit="return false;">
            <div class="col-lg-3 col-md-4 mb-2">
                <label class="small text-muted mb-0" for="af-keyword">Search</label>
                <input type="search" name="keyword" id="af-keyword" class="form-control form-control-sm" placeholder="Name, alumni ID or email">
            </div>

            <div class="col-lg-3 col-md-4 mb-2">
                <label class="small text-muted mb-0" for="af-program">Course / Program</label>
                <select name="program_id" id="af-program" class="form-control form-control-sm">
                    <option value="">All</option>
                    <?php foreach ($programs as $p): ?>
                        <option value="<?= (int) $p->id ?>">
                            <?= e($p->program_code) ?> - <?= e($p->program_name) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-lg-2 col-md-4 mb-2">
                <label class="small text-muted mb-0" for="af-year">Graduation Year</label>
                <select name="graduation_year" id="af-year" class="form-control form-control-sm">
                    <option value="">All</option>
                    <?php foreach ($years as $y): ?>
                        <option value="<?= (int) $y->graduation_year ?>"><?= (int) $y->graduation_year ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-lg-2 col-md-4 mb-2">
                <label class="small text-muted mb-0" for="af-verification">Verification</label>
                <select name="verification_status" id="af-verification" class="form-control form-control-sm">
                    <option value="">All</option>
                    <?php foreach (['verified', 'pending', 'rejected'] as $s): ?>
                        <option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>>
                            <?= ucfirst($s) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-lg-2 col-md-4 mb-2">
                <label class="small text-muted mb-0" for="af-status">Alumni Status</label>
                <select name="profile_status" id="af-status" class="form-control form-control-sm">
                    <option value="">All</option>
                    <?php foreach (['active', 'inactive', 'archived'] as $s): ?>
                        <option value="<?= $s ?>"><?= ucfirst($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-lg-2 col-md-4 mb-2">
                <label class="small text-muted mb-0" for="af-gender">Gender</label>
                <select name="gender" id="af-gender" class="form-control form-control-sm">
                    <option value="">All</option>
                    <?php foreach (['Male', 'Female', 'Other'] as $g): ?>
                        <option><?= $g ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-lg-3 col-md-4 mb-2">
                <label class="small text-muted mb-0" for="af-employment">Employment Status</label>
                <select name="employment_status_id" id="af-employment" class="form-control form-control-sm">
                    <option value="">All</option>
                    <?php foreach ($employmentStatuses as $es): ?>
                        <option value="<?= (int) $es->id ?>"><?= e($es->status_name) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <?php if ($licensureStatuses): ?>
                <div class="col-lg-3 col-md-4 mb-2">
                    <label class="small text-muted mb-0" for="af-licensure">Licensure Status</label>
                    <select name="licensure_status_id" id="af-licensure" class="form-control form-control-sm">
                        <option value="">All</option>
                        <?php foreach ($licensureStatuses as $ls): ?>
                            <option value="<?= (int) $ls->id ?>"><?= e($ls->status_name) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php endif; ?>

            <div class="col-lg-3 col-md-4 mb-2">
                <label class="small text-muted mb-0" for="af-province">Location (Province)</label>
                <select name="province" id="af-province" class="form-control form-control-sm">
                    <option value="">All</option>
                    <?php foreach ($provinces as $pr): ?>
                        <option><?= e($pr->province) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-lg-2 col-md-4 mb-2 d-flex align-items-end">
                <button type="reset" id="filter-reset" class="btn btn-sm btn-outline-secondary">
                    <i class="fas fa-undo"></i> Reset filters
                </button>
            </div>
        </form>

        <?php if ($canEdit): ?>
            <div class="mb-3">
                <button type="button" class="btn btn-primary btn-sm" data-crud-add>
                    <i class="fas fa-plus"></i> Add Alumni
                </button>
            </div>
        <?php endif; ?>

        <table id="alumni-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>

<?php if ($canEdit): ?>
<div class="modal fade" id="alumni-modal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form id="alumni-form" class="modal-content" autocomplete="off">
            <div class="modal-header">
                <h5 class="modal-title">Add Alumni</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <div class="form-group d-flex align-items-center">
                    <img id="alumni-photo-preview" src="<?= BASE_URL ?>/img/default-avatar.svg" alt="Profile photo preview"
                         class="alumni-photo alumni-photo-lg mr-3">
                    <div>
                        <label for="alumni-photo-input" class="mb-1">Profile Photo <span class="text-muted small">(optional)</span></label>
                        <input type="file" id="alumni-photo-input" name="profile_picture" class="form-control-file"
                               accept="image/jpeg,image/png,image/webp">
                        <small class="text-muted">JPG, PNG or WEBP, up to 2 MB. Leave empty to keep the current photo.</small>
                    </div>
                </div>

                <h6 class="text-primary">Personal Information</h6>
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label>First Name</label>
                        <input type="text" name="first_name" class="form-control" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label>Middle Name</label>
                        <input type="text" name="middle_name" class="form-control">
                    </div>
                    <div class="form-group col-md-4">
                        <label>Last Name</label>
                        <input type="text" name="last_name" class="form-control" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-2">
                        <label>Suffix</label>
                        <input type="text" name="suffix" class="form-control" maxlength="10">
                    </div>
                    <div class="form-group col-md-4">
                        <label>Date of Birth</label>
                        <input type="date" name="date_of_birth" class="form-control">
                    </div>
                    <div class="form-group col-md-3">
                        <label>Gender</label>
                        <select name="gender" class="form-control">
                            <option value="">Select</option>
                            <option>Male</option>
                            <option>Female</option>
                            <option>Other</option>
                        </select>
                    </div>
                    <div class="form-group col-md-3">
                        <label>Contact No.</label>
                        <input type="text" name="contact_number" class="form-control">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-5">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control">
                    </div>
                    <div class="form-group col-md-7">
                        <label>Address</label>
                        <input type="text" name="address" class="form-control">
                    </div>
                </div>

                <div class="create-only">
                    <hr>
                    <h6 class="text-primary">Account</h6>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Username</label>
                            <input type="text" name="username" class="form-control">
                        </div>
                        <div class="form-group col-md-6">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" minlength="8" autocomplete="new-password">
                        </div>
                    </div>

                    <h6 class="text-primary">Academic Information</h6>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Program</label>
                            <select name="program_id" class="form-control">
                                <option value="">Select program</option>
                                <?php foreach ($programs as $p): ?>
                                    <option value="<?= (int) $p->id ?>">
                                        <?= e($p->program_code) ?> - <?= e($p->program_name) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Major</label>
                            <input type="text" name="major" class="form-control">
                        </div>
                        <div class="form-group col-md-3">
                            <label>Graduation Year</label>
                            <input type="number" name="graduation_year" class="form-control">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Batch</label>
                            <input type="text" name="batch" class="form-control" placeholder="e.g. Batch 2024">
                        </div>
                        <div class="form-group col-md-6">
                            <label>Student ID</label>
                            <input type="text" name="student_id" class="form-control">
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>