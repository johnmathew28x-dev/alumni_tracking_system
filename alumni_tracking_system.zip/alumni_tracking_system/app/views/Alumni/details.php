<?php
$badge = ['verified' => 'success', 'pending' => 'warning', 'rejected' => 'danger'][$alumni->verification_status] ?? 'secondary';
$name  = trim("{$alumni->first_name} {$alumni->middle_name} {$alumni->last_name} {$alumni->suffix}");
$v     = fn($x) => ($x === null || $x === '') ? '—' : e($x);
?>

<div class="mb-3">
    <a href="<?= BASE_URL ?>/Alumni" class="btn btn-sm btn-outline-secondary">
        <i class="fas fa-arrow-left"></i> Back to alumni
    </a>
</div>

<div class="card card-outline card-primary">
    <div class="card-body">
        <div class="d-flex flex-wrap justify-content-between align-items-start">
            <div class="d-flex align-items-center">
                <img src="<?= e($pictureUrl) ?>" alt="Profile photo of <?= e($name) ?>"
                     class="alumni-photo alumni-photo-lg mr-3">
                <div>
                    <h4 class="mb-1"><?= e($name) ?></h4>
                    <div class="text-muted">
                        Alumni ID: <?= e($alumni->alumni_id) ?> &middot; Username: <?= e($alumni->username) ?>
                    </div>
                    <?php if (!empty($academics)): ?>
                        <?php $latest = reset($academics); ?>
                        <div class="text-muted small">
                            <?= e($latest->program_name) ?><?= $latest->graduation_year ? ' &middot; Class of ' . e($latest->graduation_year) : '' ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="text-right">
                <span class="badge badge-<?= $badge ?> p-2 mb-2" id="verify-badge">
                    <?= e(ucfirst($alumni->verification_status)) ?>
                </span>
                <?php if ($canVerify): ?>
                    <div>
                        <?php if ($alumni->verification_status !== 'verified'): ?>
                            <button class="btn btn-sm btn-success verify-btn" data-status="verified">
                                <i class="fas fa-check"></i> Verify
                            </button>
                        <?php endif; ?>
                        <?php if ($alumni->verification_status !== 'rejected'): ?>
                            <button class="btn btn-sm btn-outline-danger verify-btn" data-status="rejected">
                                <i class="fas fa-times"></i> Reject
                            </button>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <hr>

        <div class="row small">
            <div class="col-md-3">
                <strong>Email</strong><br><?= $v($alumni->email) ?>
            </div>
            <div class="col-md-3">
                <strong>Contact</strong><br><?= $v($alumni->contact_number) ?>
            </div>
            <div class="col-md-3">
                <strong>Gender</strong><br><?= $v($alumni->gender) ?>
            </div>
            <div class="col-md-3">
                <strong>Date of Birth</strong><br><?= $alumni->date_of_birth ? date('M d, Y', strtotime($alumni->date_of_birth)) : '—' ?>
            </div>
            <div class="col-12 mt-2">
                <strong>Address</strong><br><?= $v($alumni->address) ?>
            </div>
        </div>
    </div>
</div>

<?php
function details_table(string $heading, array $headers, array $rows, callable $cells): void { ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><?= e($heading) ?></h3>
        </div>
        <div class="card-body p-0 table-responsive">
            <table class="table table-sm mb-0">
                <thead>
                    <tr>
                        <?php foreach ($headers as $h): ?>
                            <th><?= e($h) ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!$rows): ?>
                        <tr>
                            <td colspan="<?= count($headers) ?>" class="text-center text-muted py-3">No records.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($rows as $r): ?>
                            <tr>
                                <?php foreach ($cells($r) as $c): ?>
                                    <td><?= ($c === null || $c === '') ? '—' : e($c) ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php }

details_table(
    'Academic Information',
    ['Program', 'Major', 'Grad. Year', 'Batch', 'Student ID'],
    $academics,
    fn($r) => [$r->program_name, $r->major, $r->graduation_year, $r->batch, $r->student_id]
);

details_table(
    'Employment',
    ['Status', 'Employer', 'Position', 'Type', 'Hired', 'Current'],
    $employments,
    fn($r) => [$r->status_name, $r->employer, $r->job_position, $r->employment_type, $r->date_hired, $r->is_current ? 'Yes' : 'No']
);

details_table(
    'Licensure',
    ['License', 'Status', 'Exam Year'],
    $licensures,
    fn($r) => [$r->license_name, $r->status_name, $r->examination_year]
);

details_table(
    'Further Education',
    ['Level', 'Institution', 'Degree', 'Field', 'Years', 'Status'],
    $educations,
    fn($r) => [
        $r->level_name,
        $r->institution,
        $r->degree,
        $r->field_of_study,
        trim(($r->start_year ?: '') . ' – ' . ($r->end_year ?: 'present'), ' –'),
        $r->status
    ]
);

details_table(
    'Trainings / Advanced Studies',
    ['Title', 'Type', 'Organizer', 'Start', 'End'],
    $trainings,
    fn($r) => [$r->training_title, $r->training_type, $r->organizer, $r->date_start, $r->date_end]
);
?>