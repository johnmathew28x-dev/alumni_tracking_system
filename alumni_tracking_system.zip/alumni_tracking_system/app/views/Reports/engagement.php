<?php
$rate = fn($v) => $v === null ? 'n/a' : $v . '%';
$boxes = [
    ['Completed Events', $summary['completed_events'], 'bg-info', 'fa-calendar-check'],
    ['Active Alumni', $summary['active_alumni'], 'bg-primary', 'fa-user-graduate'],
    ['Active Alumni Who Attended', $summary['active_attendees'], 'bg-success', 'fa-user-check'],
    ['Average Attendance Rate', $rate($summary['average_rate']), 'bg-warning', 'fa-percentage'],
];
?>

<div class="row">
    <?php foreach ($boxes as [$label, $value, $bg, $icon]): ?>
        <div class="col-lg-3 col-6">
            <div class="small-box <?= $bg ?>" id="eng-box-<?= e(strtolower(preg_replace('/\W+/', '-', $label))) ?>">
                <div class="inner">
                    <h3><?= e($value) ?></h3>
                    <p><?= e($label) ?></p>
                </div>
                <div class="icon">
                    <i class="fas <?= $icon ?>"></i>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="card card-primary card-outline card-outline-tabs">
    <div class="card-header p-0 pt-1 border-bottom-0">
        <ul class="nav nav-tabs" id="engagement-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="pill" href="#tab-alumni" role="tab">Active Alumni Attendance</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="pill" href="#tab-events" role="tab">Events</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="pill" href="#tab-records" role="tab">Attendance Records</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="pill" href="#tab-overview" role="tab">Overview</a>
            </li>
        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content">

            <div class="tab-pane fade show active" id="tab-alumni" role="tabpanel">
                <p class="text-muted small mb-2">
                    Only alumni whose status is <strong>Active</strong> are counted. <em>Total Events</em> = completed events;
                    <em>Attendance Rate</em> = events attended &divide; total events. Attendance is marked by the administrator in
                    <a href="<?= BASE_URL ?>/Events">Events &rarr; Participants</a>.
                </p>
                <form class="form-row mb-2 eng-filter" data-table="alumni" autocomplete="off" onsubmit="return false;">
                    <div class="col-lg-4 col-md-6 mb-2">
                        <label class="small text-muted mb-0">Course / Program</label>
                        <select name="program_id" class="form-control form-control-sm">
                            <option value="">All</option>
                            <?php foreach ($programs as $p): ?>
                                <option value="<?= (int) $p->id ?>"><?= e($p->program_code) ?> - <?= e($p->program_name) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-lg-2 col-md-6 mb-2">
                        <label class="small text-muted mb-0">Graduation Year</label>
                        <select name="graduation_year" class="form-control form-control-sm">
                            <option value="">All</option>
                            <?php foreach ($years as $y): ?>
                                <option value="<?= (int) $y->graduation_year ?>"><?= (int) $y->graduation_year ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-2">
                        <label class="small text-muted mb-0">Engagement Status</label>
                        <select name="engagement_level" class="form-control form-control-sm">
                            <option value="">All</option>
                            <?php foreach ($levels as $k => $label): ?>
                                <option value="<?= e($k) ?>"><?= e($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-lg-2 col-md-6 mb-2 d-flex align-items-end">
                        <button type="reset" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-undo"></i> Reset filters
                        </button>
                    </div>
                </form>
                <table id="eng-alumni-table" class="table table-bordered table-striped w-100"></table>
            </div>

            <div class="tab-pane fade" id="tab-events" role="tabpanel">
                <form class="form-row mb-2 eng-filter" data-table="events" autocomplete="off" onsubmit="return false;">
                    <div class="col-lg-3 col-md-6 mb-2">
                        <label class="small text-muted mb-0">Event Status</label>
                        <select name="event_status" class="form-control form-control-sm">
                            <option value="">All</option>
                            <?php foreach (['upcoming', 'ongoing', 'completed', 'cancelled'] as $s): ?>
                                <option value="<?= $s ?>"><?= ucfirst($s) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-lg-2 col-md-6 mb-2 d-flex align-items-end">
                        <button type="reset" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-undo"></i> Reset filters
                        </button>
                    </div>
                </form>
                <table id="eng-events-table" class="table table-bordered table-striped w-100"></table>
            </div>

            <div class="tab-pane fade" id="tab-records" role="tabpanel">
                <form class="form-row mb-2 eng-filter" data-table="records" autocomplete="off" onsubmit="return false;">
                    <div class="col-lg-4 col-md-6 mb-2">
                        <label class="small text-muted mb-0">Event</label>
                        <select name="event_id" class="form-control form-control-sm">
                            <option value="">All</option>
                            <?php foreach ($events as $ev): ?>
                                <option value="<?= (int) $ev->id ?>"><?= e($ev->title) ?> (<?= e(date('M d, Y', strtotime($ev->event_date))) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-2">
                        <label class="small text-muted mb-0">Course / Program</label>
                        <select name="program_id" class="form-control form-control-sm">
                            <option value="">All</option>
                            <?php foreach ($programs as $p): ?>
                                <option value="<?= (int) $p->id ?>"><?= e($p->program_code) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-lg-2 col-md-6 mb-2">
                        <label class="small text-muted mb-0">Graduation Year</label>
                        <select name="graduation_year" class="form-control form-control-sm">
                            <option value="">All</option>
                            <?php foreach ($years as $y): ?>
                                <option value="<?= (int) $y->graduation_year ?>"><?= (int) $y->graduation_year ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-2">
                        <label class="small text-muted mb-0">Attendance Status</label>
                        <select name="attendance_status" class="form-control form-control-sm">
                            <option value="">All</option>
                            <option value="attended">Attended</option>
                            <option value="absent">Absent (registered, event completed)</option>
                            <option value="registered">Registered (event not yet held)</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                    <div class="col-12 mb-2">
                        <button type="reset" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-undo"></i> Reset filters
                        </button>
                    </div>
                </form>
                <table id="eng-records-table" class="table table-bordered table-striped w-100"></table>
            </div>

            <div class="tab-pane fade" id="tab-overview" role="tabpanel">
                <table id="eng-overview-table" class="table table-bordered table-striped w-100"></table>
            </div>

        </div>
    </div>
</div>