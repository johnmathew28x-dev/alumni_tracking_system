<?php
$f = $config['filters'];

$select = function (string $name, string $allLabel, array $options, string $col = 'col-lg-3 col-md-4') {
    ?>
    <div class="<?= $col ?> mb-2">
        <label class="small text-muted mb-0" for="f-<?= e($name) ?>"><?= e($allLabel) ?></label>
        <select name="<?= e($name) ?>" id="f-<?= e($name) ?>" class="form-control form-control-sm">
            <option value="">All</option>
            <?php foreach ($options as $value => $label): ?>
                <option value="<?= e($value) ?>"><?= e($label) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <?php
};
?>

<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title"><?= e($config['title']) ?></h3>
    </div>
    <div class="card-body">
        <?php if ($f): ?>
            <form id="report-filter" class="form-row mb-2" autocomplete="off" onsubmit="return false;">
                <?php if (in_array('keyword', $f, true)): ?>
                    <div class="col-lg-3 col-md-4 mb-2">
                        <label class="small text-muted mb-0" for="f-keyword">Search</label>
                        <input type="search" name="keyword" id="f-keyword" class="form-control form-control-sm" placeholder="Name, alumni ID, email or employer">
                    </div>
                <?php endif; ?>

                <?php if (in_array('program_id', $f, true)):
                    $opts = [];
                    foreach ($lookups['programs'] as $p) {
                        $opts[$p->id] = $p->program_code . ' - ' . $p->program_name;
                    }
                    $select('program_id', 'Course / Program', $opts);
                endif; ?>

                <?php if (in_array('graduation_year', $f, true)):
                    $opts = [];
                    foreach ($lookups['graduationYears'] as $y) {
                        $opts[$y->graduation_year] = $y->graduation_year;
                    }
                    $select('graduation_year', 'Graduation Year', $opts, 'col-lg-2 col-md-4');
                endif; ?>

                <?php if (in_array('employment_status_id', $f, true)):
                    $opts = [];
                    foreach ($lookups['employmentStatuses'] as $es) {
                        $opts[$es->id] = $es->status_name;
                    }
                    $select('employment_status_id', 'Employment Status', $opts);
                endif; ?>

                <?php if (in_array('licensure_status_id', $f, true)):
                    $opts = [];
                    foreach ($lookups['licensureStatuses'] as $ls) {
                        $opts[$ls->id] = $ls->status_name;
                    }
                    $select('licensure_status_id', 'Licensure Status', $opts);
                endif; ?>

                <?php if (in_array('profile_status', $f, true)):
                    $select('profile_status', 'Alumni Status', [
                        'active' => 'Active',
                        'inactive' => 'Inactive',
                        'archived' => 'Archived'
                    ], 'col-lg-2 col-md-4');
                endif; ?>

                <?php if (in_array('verification_status', $f, true)):
                    $select('verification_status', 'Verification', [
                        'verified' => 'Verified',
                        'pending' => 'Pending',
                        'rejected' => 'Rejected'
                    ], 'col-lg-2 col-md-4');
                endif; ?>

                <?php if (in_array('gender', $f, true)):
                    $select('gender', 'Gender', [
                        'Male' => 'Male',
                        'Female' => 'Female',
                        'Other' => 'Other'
                    ], 'col-lg-2 col-md-4');
                endif; ?>

                <?php if (in_array('province', $f, true)):
                    $opts = [];
                    foreach ($lookups['provinces'] as $pr) {
                        $opts[$pr->province] = $pr->province;
                    }
                    $select('province', 'Location (Province)', $opts);
                endif; ?>

                <div class="col-lg-2 col-md-4 mb-2 d-flex align-items-end">
                    <button type="reset" id="report-reset" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-undo"></i> Reset filters
                    </button>
                </div>
            </form>
        <?php endif; ?>

        <table id="report-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>