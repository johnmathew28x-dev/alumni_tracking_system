<?php if (!$studies): ?>
    <div class="alert alert-info">There are no active tracer studies at this time. Please check back later.</div>
<?php endif; ?>

<div class="row">
    <?php foreach ($studies as $s): ?>
        <div class="col-md-6">
            <div class="card record-card h-100">
                <div class="card-body d-flex flex-column">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h5 class="mb-0"><?= e($s->title) ?></h5>
                        <?php if ($s->answered): ?>
                            <span class="badge badge-success ml-2">
                                <i class="fas fa-check"></i> Responded
                            </span>
                        <?php elseif (!empty($s->in_progress)): ?>
                            <span class="badge badge-warning ml-2">In progress</span>
                        <?php endif; ?>
                    </div>
                    <p class="text-muted flex-grow-1 pre-line"><?= e($s->description) ?></p>
                    <a href="<?= BASE_URL ?>/Tracer/<?= $s->survey_type === 'gts' ? 'gts' : 'answer' ?>/<?= (int) $s->id ?>" 
                       class="btn btn-block <?= $s->answered ? 'btn-outline-primary' : 'btn-primary' ?>">
                        <i class="fas <?= $s->answered ? 'fa-edit' : 'fa-pen' ?>"></i>
                        <?= $s->answered ? 'Review My Answers' : (!empty($s->in_progress) ? 'Continue Survey' : 'Start Survey') ?>
                    </a>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>