<?php 
$opt = function ($rows, $v, $t) { 
    foreach ($rows as $r) { 
        echo '<option value="' . e($r->$v) . '">' . e($r->$t) . '</option>'; 
    } 
}; 
?>

<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title">Survey Responses</h3>
        <div class="card-tools">
            <a href="<?= BASE_URL ?>/Analytics" class="btn btn-sm btn-outline-primary">
                <i class="fas fa-chart-bar"></i> Analytics
            </a>
        </div>
    </div>
    <div class="card-body">
        <form id="resp-filter" class="form-row mb-2">
            <div class="col-md-3 mb-1">
                <input type="text" name="keyword" class="form-control form-control-sm" placeholder="Name or Alumni ID">
            </div>
            <div class="col-md-3 mb-1">
                <select name="study_id" class="form-control form-control-sm">
                    <option value="">All survey periods</option>
                    <?php $opt($studies, 'id', 'title'); ?>
                </select>
            </div>
            <div class="col-md-2 mb-1">
                <select name="program_id" class="form-control form-control-sm">
                    <option value="">All programs</option>
                    <?php $opt($programs, 'id', 'program_code'); ?>
                </select>
            </div>
            <div class="col-md-2 mb-1">
                <select name="graduation_year" class="form-control form-control-sm">
                    <option value="">All years</option>
                    <?php $opt($years, 'graduation_year', 'graduation_year'); ?>
                </select>
            </div>
            <div class="col-md-2 mb-1">
                <select name="employment_state" class="form-control form-control-sm">
                    <option value="">Any status</option>
                    <option value="employed">Employed</option>
                    <option value="not_employed">Not employed</option>
                    <option value="never_employed">Never employed</option>
                </select>
            </div>
            <div class="col-md-2 mb-1">
                <select name="status" class="form-control form-control-sm">
                    <option value="">Draft + submitted</option>
                    <option value="submitted">Submitted</option>
                    <option value="draft">In progress</option>
                </select>
            </div>
            <div class="col-md-2 mb-1">
                <button class="btn btn-primary btn-sm btn-block">Filter</button>
            </div>
        </form>
        <table id="resp-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>

<div class="modal fade" id="resp-modal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Survey Response</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body" id="resp-body"></div>
        </div>
    </div>
</div>