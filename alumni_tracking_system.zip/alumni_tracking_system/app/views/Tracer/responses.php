<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title">Responses by Study</h3>
    </div>
    <div class="card-body p-0 table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>Study</th>
                    <th>Status</th>
                    <th class="text-center">Questions</th>
                    <th class="text-center">Respondents</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$studies): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">No tracer studies yet.</td>
                    </tr>
                <?php endif; ?>

                <?php foreach ($studies as $s): ?>
                    <?php $sc = ['draft' => 'secondary', 'active' => 'success', 'closed' => 'dark'][$s->status] ?? 'secondary'; ?>
                    <tr>
                        <td><?= e($s->title) ?></td>
                        <td>
                            <span class="badge badge-<?= $sc ?>"><?= ucfirst($s->status) ?></span>
                        </td>
                        <td class="text-center"><?= (int) $s->question_count ?></td>
                        <td class="text-center"><?= (int) $s->respondents ?></td>
                        <td class="text-right">
                            <a class="btn btn-sm btn-outline-primary" href="<?= BASE_URL ?>/Tracer/stats/<?= (int) $s->id ?>">
                                <i class="fas fa-chart-bar"></i> Statistics
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>