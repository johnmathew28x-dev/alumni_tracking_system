<div class="mb-3">
    <a href="<?= BASE_URL ?>/Tracer/responses" class="btn btn-sm btn-outline-secondary">
        <i class="fas fa-arrow-left"></i> Back to responses
    </a>
</div>

<div class="card card-outline card-primary">
    <div class="card-body">
        <h5 class="mb-1"><?= e($study->title) ?></h5>
        <p class="text-muted mb-0">Total respondents: <strong><?= (int) $respondents ?></strong></p>
    </div>
</div>

<?php if (!$questions): ?>
    <div class="alert alert-info">This study has no questions yet.</div>
<?php endif; ?>

<?php foreach ($questions as $q): ?>
    <div class="card">
        <div class="card-header">
            <strong><?= e($q->question) ?></strong>
        </div>
        <div class="card-body">
            <?php if (!$q->breakdown): ?>
                <p class="text-muted small mb-0">No responses yet for this question.</p>
            <?php elseif ($q->question_type === 'text'): ?>
                <ul class="list-unstyled mb-0">
                    <?php foreach ($q->breakdown as $b): ?>
                        <li class="border-bottom py-1 pre-line"><?= e($b->answer ?: '(blank)') ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <?php foreach ($q->breakdown as $b): 
                    $pct = $q->total ? round($b->total / $q->total * 100) : 0; 
                ?>
                    <div class="mb-2">
                        <div class="d-flex justify-content-between small">
                            <span><?= e($b->answer ?: '(blank)') ?></span>
                            <span><?= (int) $b->total ?> (<?= $pct ?>%)</span>
                        </div>
                        <div class="progress progress-sm">
                            <div class="progress-bar bg-primary" style="width: <?= $pct ?>%"></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
<?php endforeach; ?>