<div class="mb-3">
    <a href="<?= BASE_URL ?>/Tracer" class="btn btn-sm btn-outline-secondary">
        <i class="fas fa-arrow-left"></i> Back
    </a>
</div>

<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title"><?= e($study->title) ?></h3>
    </div>
    <form id="tracer-answer-form">
        <input type="hidden" name="tracer_study_id" value="<?= (int) $study->id ?>">
        <div class="card-body">
            <?php if ($study->description): ?>
                <p class="text-muted pre-line"><?= e($study->description) ?></p>
                <hr>
            <?php endif; ?>

            <?php if (!$questions): ?>
                <div class="alert alert-info mb-0">This study has no questions yet.</div>
            <?php endif; ?>

            <?php foreach ($questions as $q):
                $val  = $existing[$q->id] ?? '';
                $name = 'answers[' . (int) $q->id . ']';
                $req  = $q->is_required ? 'required' : '';
                $opts = $q->options ? array_map('trim', explode('|', $q->options)) : [];
            ?>
                <div class="form-group tracer-question">
                    <label class="d-block">
                        <?= e($q->question) ?>
                        <?php if ($q->is_required): ?>
                            <span class="text-danger">*</span>
                        <?php endif; ?>
                    </label>

                    <?php if ($q->question_type === 'text'): ?>
                        <textarea name="<?= $name ?>" class="form-control" rows="3" <?= $req ?>><?= e($val) ?></textarea>

                    <?php elseif ($q->question_type === 'yes_no'): ?>
                        <?php foreach (['Yes', 'No'] as $opt): ?>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" class="custom-control-input" id="q<?= (int) $q->id ?>_<?= $opt ?>" 
                                       name="<?= $name ?>" value="<?= $opt ?>" <?= $val === $opt ? 'checked' : '' ?> <?= $req ?>>
                                <label class="custom-control-label" for="q<?= (int) $q->id ?>_<?= $opt ?>"><?= $opt ?></label>
                            </div>
                        <?php endforeach; ?>

                    <?php elseif ($q->question_type === 'multiple_choice'): ?>
                        <?php foreach ($opts as $i => $opt): ?>
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" id="q<?= (int) $q->id ?>_<?= $i ?>" 
                                       name="<?= $name ?>" value="<?= e($opt) ?>" <?= $val === $opt ? 'checked' : '' ?> <?= $req ?>>
                                <label class="custom-control-label" for="q<?= (int) $q->id ?>_<?= $i ?>"><?= e($opt) ?></label>
                            </div>
                        <?php endforeach; ?>

                    <?php elseif ($q->question_type === 'select'): ?>
                        <select name="<?= $name ?>" class="form-control" <?= $req ?>>
                            <option value="">Select an option</option>
                            <?php foreach ($opts as $opt): ?>
                                <option value="<?= e($opt) ?>" <?= $val === $opt ? 'selected' : '' ?>><?= e($opt) ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if ($questions): ?>
            <div class="card-footer">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-paper-plane"></i> Submit Responses
                </button>
            </div>
        <?php endif; ?>
    </form>
</div>