<?php
$options = function (array $rows, string $placeholder = 'Select'): void {
    echo '<option value="">' . e($placeholder) . '</option>';
    foreach ($rows as $r) {
        echo '<option value="' . (int) $r->id . '" data-name="' . e($r->name) . '">' . e($r->name) . '</option>';
    }
};

$select = function (string $name, string $label, array $rows, string $col = 'col-md-6', string $placeholder = 'Select') use ($options): void {
    echo '<div class="form-group ' . $col . '"><label>' . e($label) . '</label><select name="' . e($name) . '" class="form-control">';
    $options($rows, $placeholder);
    echo '</select></div>';
};

$text = function (string $name, string $label, string $col = 'col-md-6', string $type = 'text', string $extra = ''): void {
    echo '<div class="form-group ' . $col . '"><label>' . e($label) . '</label><input type="' . $type . '" name="' . e($name)
        . '" class="form-control" ' . $extra . '></div>';
};

$yesNo = function (string $name, string $label, string $yes = 'Yes', string $no = 'No'): void {
    echo '<div class="form-group"><label class="d-block">' . e($label) . '</label>'
        . '<div class="custom-control custom-radio custom-control-inline"><input type="radio" class="custom-control-input" id="' . $name . '_1" name="' . $name . '" value="1">'
        . '<label class="custom-control-label" for="' . $name . '_1">' . e($yes) . '</label></div>'
        . '<div class="custom-control custom-radio custom-control-inline"><input type="radio" class="custom-control-input" id="' . $name . '_0" name="' . $name . '" value="0">'
        . '<label class="custom-control-label" for="' . $name . '_0">' . e($no) . '</label></div></div>';
};

$checks = function (string $name, array $rows, string $otherField): void {
    echo '<div class="row">';
    foreach ($rows as $r) {
        echo '<div class="col-md-6"><div class="custom-control custom-checkbox mb-1">'
            . '<input type="checkbox" class="custom-control-input gts-check" id="' . $name . '_' . (int) $r->id . '" name="' . $name . '[]" value="' . (int) $r->id
            . '" data-other="' . (int) $r->is_other . '" data-other-target="' . e($otherField) . '">'
            . '<label class="custom-control-label" for="' . $name . '_' . (int) $r->id . '">' . e($r->name) . '</label></div></div>';
    }
    echo '</div><input type="text" name="' . e($otherField) . '" class="form-control mt-2 other-input" maxlength="150" placeholder="Please specify" style="display:none">';
};
?>

<div class="callout callout-info">
    <h5 class="mb-1"><?= e($study->title) ?></h5>
    <p class="mb-0 small">This survey is <strong>designed based on the information requirements reflected in the CHED Graduate Tracer Survey</strong>. Your answers are used for institutional reporting; reports show summarized statistics only. Your progress is saved every time you press <em>Save &amp; Continue</em>, so you may leave and come back.</p>
</div>

<div id="gts-lock" class="alert alert-secondary" style="display:none"></div>

<div class="card card-primary card-outline card-outline-tabs gts-tabs">
    <div class="card-header p-0 pt-1 border-bottom-0">
        <ul class="nav nav-tabs gts-tablist flex-nowrap" id="gts-steps" role="tablist" aria-label="Survey sections"></ul>
    </div>
    <div class="card-body">
        <div class="tab-content">
        <div class="gts-panel" data-section="1" role="tabpanel">
            <h5 class="section-title">1. General Information</h5>
            <form class="gts-form" id="gts-form-1" data-section="1">
                <div class="card-body">
                    <div class="form-row">
                        <?php $text('first_name', 'First Name', 'col-md-4', 'text', 'required maxlength="100"'); ?>
                        <?php $text('middle_name', 'Middle Name', 'col-md-3', 'text', 'maxlength="100"'); ?>
                        <?php $text('last_name', 'Last Name', 'col-md-4', 'text', 'required maxlength="100"'); ?>
                        <?php $text('suffix', 'Suffix', 'col-md-1', 'text', 'maxlength="10"'); ?>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label>Sex</label>
                            <select name="gender" class="form-control">
                                <option value="">Select</option>
                                <option>Male</option>
                                <option>Female</option>
                                <option>Other</option>
                            </select>
                        </div>
                        <?php $text('date_of_birth', 'Birthday', 'col-md-3', 'date'); ?>
                        <?php $select('civil_status_id', 'Civil Status', $L->ref('civil_statuses'), 'col-md-3'); ?>
                        <?php $select('region_id', 'Region of Origin', $L->ref('regions'), 'col-md-3'); ?>
                    </div>
                    <?php $text('address', 'Permanent Address', 'col-12 px-0', 'text', 'maxlength="255"'); ?>
                    <div class="form-row">
                        <?php $text('province', 'Province', 'col-md-4', 'text', 'maxlength="100"'); ?>
                        <?php $text('city_municipality', 'City / Municipality of Residence', 'col-md-4', 'text', 'maxlength="100"'); ?>
                        <?php $select('residence_type_id', 'Residence Type', $L->ref('residence_types'), 'col-md-4'); ?>
                    </div>
                    <div class="form-row">
                        <?php $text('contact_number', 'Mobile Number', 'col-md-6', 'text', 'maxlength="20"'); ?>
                        <div class="form-group col-md-6">
                            <label>Email Address</label>
                            <input type="text" id="gts-email" class="form-control" disabled>
                            <small class="text-muted">Changed by the alumni office only.</small>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <div class="gts-panel" data-section="2" role="tabpanel" style="display:none">
            <h5 class="section-title">2. Educational Background</h5>
            <form class="gts-form" id="gts-form-2" data-section="2">
                <div class="card-body">
                    <div class="alert alert-light border small mb-3">
                        <strong>College / University:</strong> Northeastern College &middot;
                        <strong>Program:</strong> <span id="edu-program"></span> &middot;
                        <strong>Year Graduated:</strong> <span id="edu-year"></span>
                        <div class="text-muted">These come from your school record. Tell the alumni office if something is wrong.</div>
                    </div>
                    <div class="form-row">
                        <?php $text('degree', 'Degree', 'col-md-6', 'text', 'required maxlength="150"'); ?>
                        <?php $text('specialization', 'Specialization', 'col-md-6', 'text', 'maxlength="150"'); ?>
                    </div>
                    <div class="form-row">
                        <?php $text('academic_year', 'Academic Year Graduated', 'col-md-4', 'text', 'maxlength="9" placeholder="2022-2023"'); ?>
                        <?php $text('honors_awards', 'Honors / Awards Received', 'col-md-8', 'text', 'maxlength="255"'); ?>
                    </div>
                </div>
            </form>
        </div>

        <div class="gts-panel" data-section="3" role="tabpanel" style="display:none">
            <h5 class="section-title">3. Professional Examinations</h5>
            <form class="gts-form" id="gts-form-3" data-section="3">
                <div class="card-body">
                    <p class="text-muted small">Name of examination, date taken and rating of every professional examination you have taken. Leave empty if none.</p>
                    <table class="table table-sm table-bordered">
                        <thead>
                            <tr>
                                <th>Examination</th>
                                <th>Date Taken</th>
                                <th>Rating</th>
                                <th>Result</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id="exam-rows">
                            <tr>
                                <td colspan="5" class="text-muted text-center">Loading&hellip;</td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="inline-add border rounded p-2 gts-edit-only" id="exam-add">
                        <div class="form-row">
                            <div class="form-group col-md-4 mb-1">
                                <input class="form-control form-control-sm" name="exam_name" placeholder="Name of examination" maxlength="200">
                            </div>
                            <div class="form-group col-md-3 mb-1">
                                <input type="date" class="form-control form-control-sm" name="date_taken" max="<?= date('Y-m-d') ?>">
                            </div>
                            <div class="form-group col-md-2 mb-1">
                                <input type="number" step="0.01" min="0" max="100" class="form-control form-control-sm" name="rating" placeholder="Rating">
                            </div>
                            <div class="form-group col-md-2 mb-1">
                                <select class="form-control form-control-sm" name="result">
                                    <option>Passed</option>
                                    <option>Failed</option>
                                    <option>Pending</option>
                                </select>
                            </div>
                            <div class="col-md-1 mb-1">
                                <button type="button" class="btn btn-sm btn-outline-primary btn-block" id="exam-add-btn">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <div class="gts-panel" data-section="4" role="tabpanel" style="display:none">
            <h5 class="section-title">4. Reasons for Taking the Course</h5>
            <form class="gts-form" id="gts-form-4" data-section="4">
                <div class="card-body">
                    <p class="text-muted small">Select all that apply.</p>
                    <?php $checks('course_reason_ids', $L->ref('course_reasons'), 'course_reason_other'); ?>
                </div>
            </form>
        </div>

        <div class="gts-panel" data-section="5" role="tabpanel" style="display:none">
            <h5 class="section-title">5. Trainings / Advanced Studies</h5>
            <form class="gts-form" id="gts-form-5" data-section="5">
                <div class="card-body">
                    <p class="text-muted small">Professional or work-related trainings and advanced studies after college. Leave empty if none.</p>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Type</th>
                                    <th>Institution</th>
                                    <th>Duration / Credits</th>
                                    <th>Year</th>
                                    <th>Purpose</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="training-rows">
                                <tr>
                                    <td colspan="7" class="text-muted text-center">Loading&hellip;</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="inline-add border rounded p-2 gts-edit-only" id="training-add">
                        <div class="form-row">
                            <div class="form-group col-md-5 mb-1">
                                <input class="form-control form-control-sm" name="training_title" placeholder="Title" maxlength="200">
                            </div>
                            <div class="form-group col-md-3 mb-1">
                                <select class="form-control form-control-sm" name="training_type">
                                    <option>Training</option>
                                    <option>Advanced Study</option>
                                </select>
                            </div>
                            <div class="form-group col-md-4 mb-1">
                                <input class="form-control form-control-sm" name="organizer" placeholder="Training institution" maxlength="150">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-3 mb-1">
                                <input class="form-control form-control-sm" name="college_university" placeholder="College / University" maxlength="150">
                            </div>
                            <div class="form-group col-md-2 mb-1">
                                <input class="form-control form-control-sm" name="duration" placeholder="Duration" maxlength="60">
                            </div>
                            <div class="form-group col-md-2 mb-1">
                                <input class="form-control form-control-sm" name="credits_earned" placeholder="Credits" maxlength="30">
                            </div>
                            <div class="form-group col-md-1 mb-1">
                                <input type="number" class="form-control form-control-sm" name="training_year" placeholder="Year" min="1950" max="<?= (int) date('Y') + 1 ?>">
                            </div>
                            <div class="form-group col-md-3 mb-1">
                                <select class="form-control form-control-sm" name="purpose">
                                    <option value="">Purpose</option>
                                    <option>Promotion</option>
                                    <option>Professional Development</option>
                                    <option>Other</option>
                                </select>
                            </div>
                            <div class="col-md-1 mb-1">
                                <button type="button" class="btn btn-sm btn-outline-primary btn-block" id="training-add-btn">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="form-row" id="training-purpose-other" style="display:none">
                            <div class="form-group col-md-6 mb-1">
                                <input class="form-control form-control-sm" name="purpose_other" placeholder="Please specify the purpose" maxlength="150">
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <div class="gts-panel" data-section="6" role="tabpanel" style="display:none">
            <h5 class="section-title">6. Employment Status</h5>
            <form class="gts-form" id="gts-form-6" data-section="6">
                <div class="card-body">
                    <label class="d-block">Are you presently employed?</label>
                    <?php foreach (['employed' => 'Yes, I am currently employed', 'not_employed' => 'No, I am not currently employed', 'never_employed' => 'I have never been employed'] as $v => $l): ?>
                        <div class="custom-control custom-radio mb-1">
                            <input type="radio" class="custom-control-input" id="state_<?= $v ?>" name="employment_state" value="<?= $v ?>">
                            <label class="custom-control-label" for="state_<?= $v ?>"><?= e($l) ?></label>
                        </div>
                    <?php endforeach; ?>
                    <div id="unemployment-wrap" class="mt-3" style="display:none">
                        <label>Reason(s) why you are not employed <small class="text-muted">(select all that apply)</small></label>
                        <?php $checks('unemployment_reason_ids', $L->ref('unemployment_reasons'), 'unemployment_reason_other'); ?>
                    </div>
                </div>
            </form>
        </div>

        <div class="gts-panel" data-section="7" role="tabpanel" style="display:none">
            <h5 class="section-title">7. Current Employment</h5>
            <form class="gts-form" id="gts-form-7" data-section="7">
                <div class="card-body">
                    <div class="form-row">
                        <?php $select('employment_type_id', 'Employment Status', $L->ref('employment_types'), 'col-md-4'); ?>
                        <?php $text('job_position', 'Present Occupation', 'col-md-4', 'text', 'maxlength="150" placeholder="e.g. Teacher, Software Developer"'); ?>
                        <div class="form-group col-md-4">
                            <label id="employer-label">Employer / Company</label>
                            <input type="text" name="employer" class="form-control" maxlength="150">
                        </div>
                    </div>
                    <div class="form-row">
                        <?php $select('industry_id', 'Major Line of Business / Industry', $L->ref('industries'), 'col-md-5'); ?>
                        <div class="form-group col-md-3">
                            <label>Place of Work</label>
                            <select name="place_of_work" class="form-control">
                                <option value="">Select</option>
                                <option>Local</option>
                                <option>Abroad</option>
                            </select>
                        </div>
                        <?php $text('employment_location', 'Work Location (city / country)', 'col-md-4', 'text', 'maxlength="150"'); ?>
                    </div>
                    <div class="form-row">
                        <div class="col-md-4"><?php $yesNo('related_to_degree', 'Is your work related to your degree?'); ?></div>
                        <div class="col-md-4"><?php $yesNo('current_is_first_job', 'Is this your first job?'); ?></div>
                        <?php $text('date_hired', 'Date Hired (optional)', 'col-md-4', 'date', 'max="' . date('Y-m-d') . '"'); ?>
                    </div>
                </div>
            </form>
        </div>

        <div class="gts-panel" data-section="8" role="tabpanel" style="display:none">
            <h5 class="section-title">8. First Job</h5>
            <form class="gts-form" id="gts-form-8" data-section="8">
                <div class="card-body">
                    <div id="first-merged-note" class="alert alert-light border small" style="display:none">Your current job is your first job, so its details were already collected in Section 7.</div>
                    <div id="first-separate">
                        <div class="form-row">
                            <?php $text('first_job_position', 'First Job Position', 'col-md-4', 'text', 'maxlength="150"'); ?>
                            <?php $text('first_employer', 'Employer / Company (optional)', 'col-md-4', 'text', 'maxlength="150"'); ?>
                            <?php $text('first_job_location', 'First Job Location', 'col-md-4', 'text', 'maxlength="150"'); ?>
                        </div>
                        <div class="form-row">
                            <?php $select('first_industry_id', 'First Job Industry', $L->ref('industries'), 'col-md-8'); ?>
                            <div class="col-md-4"><?php $yesNo('first_related_to_degree', 'Related to your degree?'); ?></div>
                        </div>
                    </div>
                    <?php $select('duration_id', 'How long did you stay in your first job?', $L->ref('duration_ranges'), 'col-md-6 px-0'); ?>
                    <label>Reason(s) for accepting your first job <small class="text-muted">(select all that apply)</small></label>
                    <?php $checks('accept_reason_ids', $L->employmentReasons('accept'), 'accept_reason_other'); ?>
                </div>
            </form>
        </div>

        <div class="gts-panel" data-section="9" role="tabpanel" style="display:none">
            <h5 class="section-title">9. Job Search</h5>
            <form class="gts-form" id="gts-form-9" data-section="9">
                <div class="card-body">
                    <div class="form-row">
                        <?php $select('search_method_id', 'How did you find your first job?', $L->ref('job_search_methods'), 'col-md-6'); ?>
                        <?php $select('time_to_job_id', 'How long did it take to land your first job?', $L->ref('duration_ranges'), 'col-md-6'); ?>
                    </div>
                    <div id="change-wrap" style="display:none">
                        <label>Reason(s) for changing jobs <small class="text-muted">(select all that apply)</small></label>
                        <?php $checks('change_reason_ids', $L->employmentReasons('change'), 'change_reason_other'); ?>
                    </div>
                </div>
            </form>
        </div>

        <div class="gts-panel" data-section="10" role="tabpanel" style="display:none">
            <h5 class="section-title">10. Job Level and Earnings</h5>
            <form class="gts-form" id="gts-form-10" data-section="10">
                <div class="card-body">
                    <h6 id="level-first-title" class="text-primary">First job</h6>
                    <div class="form-row">
                        <?php $select('first_job_level_id', 'Job Level', $L->ref('job_levels'), 'col-md-6'); ?>
                        <?php $select('first_salary_range_id', 'Initial Gross Monthly Earnings', $L->ref('salary_ranges'), 'col-md-6', 'Prefer not to say'); ?>
                    </div>
                    <div id="level-current-wrap" style="display:none">
                        <h6 class="text-primary">Present job</h6>
                        <div class="form-row">
                            <?php $select('current_job_level_id', 'Job Level', $L->ref('job_levels'), 'col-md-6'); ?>
                            <?php $select('current_salary_range_id', 'Gross Monthly Earnings', $L->ref('salary_ranges'), 'col-md-6', 'Prefer not to say'); ?>
                        </div>
                    </div>
                    <small class="text-muted">You do not have to give your exact salary - only the bracket, and you may choose "Prefer not to say".</small>
                </div>
            </form>
        </div>

        <div class="gts-panel" data-section="11" role="tabpanel" style="display:none">
            <h5 class="section-title">11. Curriculum Relevance</h5>
            <form class="gts-form" id="gts-form-11" data-section="11">
                <div class="card-body">
                    <?php $yesNo('curriculum_relevant', 'Was the curriculum you had in college relevant to your first job?'); ?>
                </div>
            </form>
        </div>

        <div class="gts-panel" data-section="12" role="tabpanel" style="display:none">
            <h5 class="section-title">12. Competencies</h5>
            <form class="gts-form" id="gts-form-12" data-section="12">
                <div class="card-body">
                    <p class="text-muted small">Which competencies learned in college were useful in your first job? Select all that apply.</p>
                    <?php $checks('competency_ids', $L->ref('competencies'), 'competency_other'); ?>
                </div>
            </form>
        </div>

        <div class="gts-panel" data-section="13" role="tabpanel" style="display:none">
            <h5 class="section-title">13. Curriculum Feedback</h5>
            <form class="gts-form" id="gts-form-13" data-section="13">
                <div class="card-body">
                    <div class="form-group">
                        <label>Suggestions to further improve the course curriculum</label>
                        <textarea name="curriculum_feedback" class="form-control" rows="5" maxlength="2000"></textarea>
                    </div>
                </div>
            </form>
        </div>

        <div class="gts-panel" data-section="14" role="tabpanel" style="display:none">
            <h5 class="section-title">14. Review and Submit</h5>
            <div class="card-body">
                <div id="review-missing" class="alert alert-warning" style="display:none"></div>
                <div id="review-body"><p class="text-muted">Loading&hellip;</p></div>
            </div>
        </div>
        </div>
    </div>
    <div class="card-footer d-flex justify-content-between align-items-center flex-wrap gts-actions">
        <button type="button" class="btn btn-outline-secondary gts-prev">
            <i class="fas fa-arrow-left"></i> Back
        </button>
        <span id="gts-dirty" class="small text-warning mx-2" style="display:none">
            <i class="fas fa-exclamation-circle"></i> Unsaved changes in this section
        </span>
        <span class="ml-auto">
            <button type="submit" class="btn btn-primary gts-edit-only" id="gts-save">
                Save &amp; Continue <i class="fas fa-arrow-right"></i>
            </button>
            <button type="button" class="btn btn-success gts-edit-only" id="gts-submit" style="display:none">
                <i class="fas fa-paper-plane"></i> Submit Survey
            </button>
            <button type="button" class="btn btn-primary gts-next gts-view-only" style="display:none">
                Next <i class="fas fa-arrow-right"></i>
            </button>
        </span>
    </div>
</div>
