<div class="mb-3">
    <a href="<?= BASE_URL ?>/Tracer" class="btn btn-sm btn-outline-secondary">
        <i class="fas fa-arrow-left"></i> Back to studies
    </a>
</div>

<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title">Questions: <?= e($study->title) ?></h3>
        <div class="card-tools">
            <button type="button" class="btn btn-primary btn-sm" data-crud-add>
                <i class="fas fa-plus"></i> Add Question
            </button>
        </div>
    </div>
    <div class="card-body">
        <table id="questions-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>

<div class="modal fade" id="questions-modal" tabindex="-1">
    <div class="modal-dialog">
        <form id="questions-form" class="modal-content">
            <input type="hidden" name="tracer_study_id" value="<?= (int) $study->id ?>">
            <div class="modal-header">
                <h5 class="modal-title">Add Question</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Question</label>
                    <textarea name="question" class="form-control" rows="2" required></textarea>
                </div>
                <div class="form-group">
                    <label>Answer Type</label>
                    <select name="question_type" id="q_type" class="form-control">
                        <option value="text">Text</option>
                        <option value="yes_no">Yes / No</option>
                        <option value="multiple_choice">Multiple Choice</option>
                        <option value="select">Select (Dropdown)</option>
                    </select>
                </div>
                <div class="form-group d-none" id="q_options_wrap">
                    <label>Options (one per line)</label>
                    <textarea name="options" class="form-control" rows="4"></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group col-6">
                        <label>Sort Order</label>
                        <input type="number" name="sort_order" class="form-control" value="0">
                    </div>
                    <div class="form-group col-6 d-flex align-items-end">
                        <div class="custom-control custom-checkbox mb-2">
                            <input type="checkbox" class="custom-control-input" id="q_required" name="is_required" value="1" checked>
                            <label class="custom-control-label" for="q_required">Required</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>