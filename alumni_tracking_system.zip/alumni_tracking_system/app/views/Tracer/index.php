<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title">Survey Periods (Graduate Tracer Surveys)</h3>
        <div class="card-tools">
            <button type="button" class="btn btn-primary btn-sm" data-crud-add>
                <i class="fas fa-plus"></i> New Survey Period
            </button>
        </div>
    </div>
    <div class="card-body">
        <table id="tracer-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>

<div class="modal fade" id="tracer-modal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form id="tracer-form" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">New Tracer Study</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" class="form-control" required>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label>Survey Year</label>
                        <input type="number" name="survey_year" class="form-control" min="2000" max="<?= (int) date('Y') + 1 ?>" value="<?= date('Y') ?>">
                    </div>
                    <div class="form-group col-md-8" id="survey-type-wrap">
                        <label>Survey Form</label>
                        <select name="survey_type" class="form-control">
                            <option value="gts">Graduate Tracer Survey (CHED GTS-aligned form)</option>
                            <option value="custom">Custom questions (write my own)</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control" rows="3"></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Start Date</label>
                        <input type="date" name="start_date" class="form-control">
                    </div>
                    <div class="form-group col-md-6">
                        <label>End Date</label>
                        <input type="date" name="end_date" class="form-control">
                    </div>
                </div>
                <small class="text-muted">Survey periods start as drafts. Activate one so alumni can answer it. Only one response per alumnus is allowed in each period unless you permit a resubmission.</small>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>