<?php
$sel = function (string $name, string $label, array $rows, string $valueField, string $textField) {
    echo '<div class="form-group col-md-3 col-6">';
    echo '<label class="small text-muted mb-0" for="af-' . e($name) . '">' . e($label) . '</label>';
    echo '<select name="' . e($name) . '" id="af-' . e($name) . '" class="form-control form-control-sm">';
    echo '<option value="">All</option>';
    foreach ($rows as $r) {
        echo '<option value="' . e($r->$valueField) . '">' . e($r->$textField) . '</option>';
    }
    echo '</select>';
    echo '</div>';
};
?>

<div class="callout callout-info py-2">
    <small>
        Statistics from submitted <strong>Graduate Tracer Surveys</strong> (designed based on the information requirements reflected in the CHED Graduate Tracer Survey).
        Only summarized figures are shown—no names, contact details, or salaries of individuals.
    </small>
</div>

<div class="card card-outline card-primary">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-filter mr-1"></i> Dashboard Filters</h3>
    </div>
    <form id="filter-form" class="card-body pb-2" autocomplete="off" onsubmit="return false;">
        <div class="form-row">
            <?php $sel('department_id', 'Department', $L->departments(), 'id', 'department_name'); ?>
            <?php $sel('program_id', 'Program', $L->programs(), 'id', 'program_name'); ?>
            <?php $sel('graduation_year', 'Graduation Year', $L->graduationYears(), 'graduation_year', 'graduation_year'); ?>
            <?php $sel('academic_year', 'Academic Year', $L->academicYears(), 'academic_year', 'academic_year'); ?>
            <?php $sel('study_id', 'Survey Period', $L->gtsStudies(), 'id', 'title'); ?>
            <?php $sel('industry_id', 'Industry', $L->ref('industries'), 'id', 'name'); ?>

            <div class="form-group col-md-3 col-6">
                <label class="small text-muted mb-0" for="af-employment_state">Employment Status</label>
                <select name="employment_state" id="af-employment_state" class="form-control form-control-sm">
                    <option value="">All</option>
                    <option value="employed">Employed</option>
                    <option value="not_employed">Not currently employed</option>
                    <option value="never_employed">Never employed</option>
                </select>
            </div>

            <div class="form-group col-md-3 col-6">
                <label class="small text-muted mb-0" for="af-place_of_work">Location</label>
                <select name="place_of_work" id="af-place_of_work" class="form-control form-control-sm">
                    <option value="">All</option>
                    <option value="Local">Local</option>
                    <option value="Abroad">Abroad</option>
                </select>
            </div>
        </div>

        <div class="mb-2 d-flex flex-wrap align-items-center justify-content-between gap-2">
            <div>
                <button type="submit" class="btn btn-primary btn-sm">
                    <i class="fas fa-filter"></i> Apply Filters
                </button>
                <button type="button" class="btn btn-outline-secondary btn-sm" id="filter-reset">
                    <i class="fas fa-undo"></i> Reset
                </button>
            </div>
            <div>
                <button type="button" class="btn btn-outline-secondary btn-sm mr-1" onclick="window.print()">
                    <i class="fas fa-print"></i> Print Report
                </button>
                <span id="export-btns" style="display:none">
                    <a class="btn btn-outline-success btn-sm export-link" data-dataset="summary">
                        <i class="fas fa-file-csv"></i> Summary CSV
                    </a>
                    <a class="btn btn-outline-success btn-sm export-link" data-dataset="programs">
                        <i class="fas fa-file-csv"></i> By Program
                    </a>
                    <a class="btn btn-outline-success btn-sm export-link" data-dataset="feedback">
                        <i class="fas fa-file-csv"></i> Feedback
                    </a>
                </span>
            </div>
        </div>
    </form>
</div>

<div class="card card-outline card-info d-print-none" id="ai-assist">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-robot mr-1"></i> AI Assist</h3>
    </div>
    <div class="card-body">
        <p class="text-muted small mb-2">
            Ask a question about the results for the filters selected above. This free, built-in assistant analyzes only summarized statistics
            (counts and percentages, with small groups withheld). It runs locally without an API key and never uses names, contact details, or written answers.
        </p>

        <div id="ai-unavailable" class="alert alert-warning small" style="display:none"></div>

        <div class="mb-2" id="ai-suggestions" role="group" aria-label="Suggested questions">
            <button type="button" class="btn btn-outline-info btn-xs mb-1 ai-suggest">Summarize the employment outcomes of our Education graduates.</button>
            <button type="button" class="btn btn-outline-info btn-xs mb-1 ai-suggest">Compare employment outcomes across the available graduation years.</button>
            <button type="button" class="btn btn-outline-info btn-xs mb-1 ai-suggest">What patterns are visible in how closely graduates' jobs match their degree?</button>
            <button type="button" class="btn btn-outline-info btn-xs mb-1 ai-suggest">Summarize the available curriculum relevance results.</button>
            <button type="button" class="btn btn-outline-info btn-xs mb-1 ai-suggest">What data limitations should administrators consider when interpreting these results?</button>
            <button type="button" class="btn btn-outline-info btn-xs mb-1 ai-suggest">Based on these statistics, what areas should the department investigate further?</button>
        </div>

        <form id="ai-form" autocomplete="off" onsubmit="return false;">
            <div class="form-group mb-2">
                <label for="ai-question" class="small text-muted mb-0">Your question</label>
                <textarea id="ai-question" class="form-control" rows="2" aria-describedby="ai-hint" placeholder="e.g. How did employment differ between graduation years?"></textarea>
                <small class="text-muted" id="ai-hint"><span id="ai-count">0</span> characters. Do not type personal information. Press Ctrl+Enter to send.</small>
            </div>
            <button type="submit" class="btn btn-info btn-sm" id="ai-analyze">
                <i class="fas fa-magic"></i> Analyze
            </button>
            <button type="button" class="btn btn-outline-secondary btn-sm" id="ai-reset" style="display:none">
                <i class="fas fa-redo"></i> Ask another question
            </button>
            <span id="ai-loading" class="text-muted small ml-2" style="display:none" role="status" aria-live="polite">
                <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Analyzing&hellip;
            </span>
        </form>

        <div id="ai-error" class="alert alert-danger mt-3 mb-0" style="display:none" role="alert"></div>

        <div id="ai-result" class="mt-3" style="display:none" aria-live="polite">
            <div class="small text-muted mb-1" id="ai-scope"></div>
            <div class="border rounded p-3 bg-light pre-line" id="ai-answer" tabindex="-1"></div>
            <div class="small text-muted mt-1" id="ai-meta"></div>
        </div>
    </div>
    <div class="card-footer small text-muted">
        <i class="fas fa-info-circle"></i> These summaries are produced by built-in rules from the available aggregate statistics and may miss context or
        over-interpret small differences. Please verify important findings against the charts and tables below before acting on them.
    </div>
</div>

<div id="low-n" class="alert alert-warning" style="display:none"></div>
<div id="kpis" class="row"></div>

<div class="row">
    <div class="col-lg-6">
        <div class="card card-outline card-secondary">
            <div class="card-header"><h3 class="card-title">Employment Status by Graduation Year</h3></div>
            <div class="card-body"><canvas id="c-state-year" height="200"></canvas></div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card card-outline card-secondary">
            <div class="card-header"><h3 class="card-title">Employment Rate by Program (%)</h3></div>
            <div class="card-body"><canvas id="c-rate-program" height="200"></canvas></div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card card-outline card-secondary">
            <div class="card-header"><h3 class="card-title">Degree-Related Employment by Program (% of Employed)</h3></div>
            <div class="card-body"><canvas id="c-related-program" height="200"></canvas></div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card card-outline card-secondary">
            <div class="card-header"><h3 class="card-title">Local vs Overseas Employment</h3></div>
            <div class="card-body"><canvas id="c-place" height="200"></canvas></div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card card-outline card-secondary">
            <div class="card-header"><h3 class="card-title">Employment by Industry</h3></div>
            <div class="card-body"><canvas id="c-industry" height="260"></canvas></div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card card-outline card-secondary">
            <div class="card-header"><h3 class="card-title">Job Level (Present Job)</h3></div>
            <div class="card-body"><canvas id="c-level" height="260"></canvas></div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card card-outline card-secondary">
            <div class="card-header"><h3 class="card-title">Salary Range (Present Job)</h3></div>
            <div class="card-body"><canvas id="c-salary" height="200"></canvas></div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card card-outline card-secondary">
            <div class="card-header"><h3 class="card-title">Time to First Job</h3></div>
            <div class="card-body"><canvas id="c-time" height="200"></canvas></div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card card-outline card-secondary">
            <div class="card-header"><h3 class="card-title">Curriculum Relevance</h3></div>
            <div class="card-body"><canvas id="c-relevance" height="200"></canvas></div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card card-outline card-secondary">
            <div class="card-header"><h3 class="card-title">Competencies Used in First Job</h3></div>
            <div class="card-body"><canvas id="c-comp" height="200"></canvas></div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card card-outline card-primary">
            <div class="card-header"><h3 class="card-title">Program Summary</h3></div>
            <div class="card-body table-responsive p-0">
                <table class="table table-sm table-striped mb-0" id="t-programs"></table>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card card-outline card-primary">
            <div class="card-header"><h3 class="card-title">Survey Participation by Graduation Year</h3></div>
            <div class="card-body table-responsive p-0">
                <table class="table table-sm table-striped mb-0" id="t-participation"></table>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card card-outline card-info">
            <div class="card-header"><h3 class="card-title">Professional Development</h3></div>
            <div class="card-body" id="dev-body"></div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card card-outline card-info">
            <div class="card-header"><h3 class="card-title">Job Search &amp; Reasons</h3></div>
            <div class="card-body" id="reasons-body"></div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card card-outline card-secondary">
            <div class="card-header"><h3 class="card-title">Alumni Demographics</h3></div>
            <div class="card-body" id="demo-body"></div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card card-outline card-secondary">
            <div class="card-header"><h3 class="card-title">Curriculum Improvement Suggestions</h3></div>
            <div class="card-body" id="feedback-body" style="max-height: 420px; overflow-y: auto;"></div>
        </div>
    </div>
</div>