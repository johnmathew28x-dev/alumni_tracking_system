<?php if (empty($announcements)): ?>
    <div class="alert alert-info d-flex align-items-center mb-0" role="alert">
        <i class="fas fa-info-circle mr-2 fa-lg"></i>
        <div>There are no announcements at this time.</div>
    </div>
<?php else: ?>
    <div class="announcement-list">
        <?php foreach ($announcements as $a): ?>
            <div class="card card-outline card-primary mb-3">
                <div class="card-header border-bottom-0 pb-1">
                    <h5 class="card-title text-bold mb-0">
                        <?= e($a->title) ?>
                    </h5>
                    <div class="card-tools text-muted small">
                        <i class="far fa-clock mr-1"></i>
                        <?= date('F d, Y', strtotime($a->published_at)) ?>
                    </div>
                </div>

                <div class="card-body pt-2">
                    <div class="text-secondary pre-line">
                        <?= e($a->content) ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>