<div class="card card-outline card-primary">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fas fa-bullhorn mr-1"></i> Announcements
        </h3>
        <div class="card-tools">
            <button type="button" class="btn btn-primary btn-sm" data-crud-add>
                <i class="fas fa-plus mr-1"></i> Add Announcement
            </button>
        </div>
    </div>
    <div class="card-body">
        <table id="announcements-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>

<div class="modal fade" id="announcements-modal" tabindex="-1" role="dialog" aria-labelledby="announcementsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <form id="announcements-form" class="modal-content" autocomplete="off">
            <div class="modal-header">
                <h5 class="modal-title" id="announcementsModalLabel">Add Announcement</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <div class="form-group">
                    <label for="announcement-title">Title <span class="text-danger">*</span></label>
                    <input type="text" id="announcement-title" name="title" class="form-control" maxlength="200" placeholder="Enter announcement title" required>
                </div>

                <div class="form-group mb-2">
                    <label for="announcement-content">Content <span class="text-danger">*</span></label>
                    <textarea id="announcement-content" name="content" class="form-control" rows="6" placeholder="Write the announcement content here..." required></textarea>
                </div>

                <div class="callout callout-info mb-0">
                    <p class="small text-muted mb-0">
                        <i class="fas fa-info-circle mr-1"></i>
                        New announcements are saved as drafts by default. Use the <strong>Publish</strong> action button in the list to make them visible to alumni.
                    </p>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save mr-1"></i> Save
                </button>
            </div>
        </form>
    </div>
</div>