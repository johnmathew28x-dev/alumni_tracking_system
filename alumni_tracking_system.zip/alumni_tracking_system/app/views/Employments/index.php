<?php
$statuses = $lookups->employmentStatuses();
$tenures  = $lookups->ref('employment_types');
$inds     = $lookups->ref('industries');
$levels   = $lookups->ref('job_levels');
$salaries = $lookups->ref('salary_ranges');
?>

<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title">Employment History</h3>
        <div class="card-tools">
            <button type="button" class="btn btn-primary btn-sm" data-crud-add>
                <i class="fas fa-plus"></i> Add Employment
            </button>
        </div>
    </div>
    <div class="card-body">
        <table id="employments-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>

<div class="modal fade" id="employments-modal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form id="employments-form" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Employment</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group col-md-8">
                        <label>Employment Status</label>
                        <select name="employment_status_id" class="form-control" required>
                            <option value="">Select status</option>
                            <?php foreach ($statuses as $s): ?>
                                <option value="<?= (int) $s->id ?>"><?= e($s->status_name) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group col-md-4">
                        <label>Employment Type</label>
                        <select name="employment_type_id" class="form-control">
                            <option value="">Not applicable</option>
                            <?php foreach ($tenures as $t): ?>
                                <option value="<?= (int) $t->id ?>"><?= e($t->name) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Employer / Company</label>
                        <input type="text" name="employer" class="form-control">
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label>Job Position</label>
                        <input type="text" name="job_position" class="form-control">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Industry / Major Line of Business</label>
                        <select name="industry_id" class="form-control">
                            <option value="">Select industry</option>
                            <?php foreach ($inds as $i): ?>
                                <option value="<?= (int) $i->id ?>"><?= e($i->name) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label>Work Location (city / country)</label>
                        <input type="text" name="employment_location" class="form-control">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-3">
                        <label>Place of Work</label>
                        <select name="place_of_work" class="form-control">
                            <option value="">Select</option>
                            <option>Local</option>
                            <option>Abroad</option>
                        </select>
                    </div>
                    
                    <div class="form-group col-md-3">
                        <label>Job Level</label>
                        <select name="job_level_id" class="form-control">
                            <option value="">Select</option>
                            <?php foreach ($levels as $l): ?>
                                <option value="<?= (int) $l->id ?>"><?= e($l->name) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group col-md-3">
                        <label>Gross Monthly Earnings</label>
                        <select name="salary_range_id" class="form-control">
                            <option value="">Prefer not to say</option>
                            <?php foreach ($salaries as $s): ?>
                                <option value="<?= (int) $s->id ?>"><?= e($s->name) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group col-md-3">
                        <label>Related to Degree?</label>
                        <select name="related_to_degree" class="form-control">
                            <option value="">Select</option>
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                    </div>
                </div>

                <div class="custom-control custom-checkbox mb-3">
                    <input type="checkbox" class="custom-control-input" id="is_first_job" name="is_first_job" value="1">
                    <label class="custom-control-label" for="is_first_job">This was my first job after graduation</label>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label>Date Hired</label>
                        <input type="date" name="date_hired" class="form-control">
                    </div>
                    
                    <div class="form-group col-md-4" id="ended-wrap">
                        <label>Date Ended</label>
                        <input type="date" name="date_ended" class="form-control">
                    </div>
                    
                    <div class="form-group col-md-4 d-flex align-items-end">
                        <div class="custom-control custom-checkbox mb-2">
                            <input type="checkbox" class="custom-control-input" id="is_current" name="is_current" value="1" checked>
                            <label class="custom-control-label" for="is_current">This is my current job</label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>