<?php
$types    = $lookups->licenseTypes();
$statuses = $lookups->licensureStatuses();
?>

<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title">Licensure Records</h3>
        <div class="card-tools">
            <button id="add-licensure" type="button" class="btn btn-primary btn-sm" data-crud-add>
                <i class="fas fa-plus"></i> Add Licensure
            </button>
        </div>
    </div>
    <div class="card-body">
        <table id="licensures-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>

<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title">Professional Examination History</h3>
        <div class="card-tools">
            <button id="add-examination" type="button" class="btn btn-primary btn-sm" data-crud-add>
                <i class="fas fa-plus"></i> Add Examination
            </button>
        </div>
    </div>
    <div class="card-body">
        <p class="text-muted small">
            Keep your professional and licensure examination name, date, rating, and result here with your licensure records.
        </p>
        <table id="exams-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>

<div class="modal fade" id="licensures-modal" tabindex="-1">
    <div class="modal-dialog">
        <form id="licensures-form" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Licensure</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <div class="form-group">
                    <label>License Type</label>
                    <select name="license_type_id" class="form-control" required>
                        <option value="">Select license</option>
                        <?php foreach ($types as $t): ?>
                            <option value="<?= (int) $t->id ?>"><?= e($t->license_name) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Status</label>
                        <select name="status_id" class="form-control" required>
                            <option value="">Select status</option>
                            <?php foreach ($statuses as $s): ?>
                                <option value="<?= (int) $s->id ?>"><?= e($s->status_name) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group col-md-6">
                        <label>Examination Year</label>
                        <input type="number" name="examination_year" class="form-control" min="1950" max="<?= date('Y') + 1 ?>">
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="exams-modal" tabindex="-1">
    <div class="modal-dialog">
        <form id="exams-form" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Examination</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <div class="form-group">
                    <label>Name of Examination</label>
                    <input type="text" name="exam_name" class="form-control" maxlength="200" required>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label>Date Taken</label>
                        <input type="date" name="date_taken" class="form-control" max="<?= date('Y-m-d') ?>">
                    </div>

                    <div class="form-group col-md-4">
                        <label>Rating</label>
                        <input type="number" step="0.01" min="0" max="100" name="rating" class="form-control">
                    </div>

                    <div class="form-group col-md-4">
                        <label>Result</label>
                        <select name="result" class="form-control">
                            <option value="Passed">Passed</option>
                            <option value="Failed">Failed</option>
                            <option value="Pending">Pending</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>
