<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title">Job Postings</h3>
        <div class="card-tools">
            <button type="button" class="btn btn-primary btn-sm" data-crud-add>
                <i class="fas fa-plus"></i> Add Job
            </button>
        </div>
    </div>
    <div class="card-body">
        <table id="jobs-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>

<div class="modal fade" id="jobs-modal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form id="jobs-form" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Job</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Job Title</label>
                        <input type="text" name="job_title" class="form-control" required>
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label>Company</label>
                        <input type="text" name="company" class="form-control" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Location</label>
                        <input type="text" name="location" class="form-control">
                    </div>
                    
                    <div class="form-group col-md-4">
                        <label>Application Deadline</label>
                        <input type="date" name="deadline" class="form-control">
                    </div>
                    
                    <div class="form-group col-md-2">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="open">Open</option>
                            <option value="closed">Closed</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control" rows="3"></textarea>
                </div>

                <div class="form-group">
                    <label>Qualifications</label>
                    <textarea name="qualifications" class="form-control" rows="3"></textarea>
                </div>

                <div class="form-group mb-0">
                    <label>Application Instructions</label>
                    <textarea name="application_instructions" class="form-control" rows="2"></textarea>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>