<?php if (empty($jobs)): ?>
    <div class="alert alert-info">
        There are no open job postings at this time.
    </div>
<?php else: ?>
    <?php foreach ($jobs as $j): ?>
        <div class="card record-card mb-4">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <h5 class="mb-0"><?= e($j->job_title) ?></h5>
                    
                    <?php if (!empty($j->deadline)): ?>
                        <span class="badge badge-light border">
                            <i class="far fa-calendar-alt"></i> Apply by <?= date('M d, Y', strtotime($j->deadline)) ?>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="text-muted small mb-3">
                    <i class="far fa-building"></i> <?= e($j->company) ?>
                    <?php if (!empty($j->location)): ?>
                        &middot; <i class="fas fa-map-marker-alt"></i> <?= e($j->location) ?>
                    <?php endif; ?>
                </div>

                <?php if (!empty($j->description)): ?>
                    <p class="pre-line"><?= e($j->description) ?></p>
                <?php endif; ?>

                <?php if (!empty($j->qualifications)): ?>
                    <div class="mb-3">
                        <strong>Qualifications</strong>
                        <div class="pre-line"><?= e($j->qualifications) ?></div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($j->application_instructions)): ?>
                    <div class="mb-0">
                        <strong>How to apply</strong>
                        <div class="pre-line"><?= e($j->application_instructions) ?></div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>