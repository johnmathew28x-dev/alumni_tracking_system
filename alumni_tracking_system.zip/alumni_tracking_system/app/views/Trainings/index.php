<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title">Trainings / Advanced Studies</h3>
        <div class="card-tools">
            <button type="button" class="btn btn-primary btn-sm" data-crud-add>
                <i class="fas fa-plus"></i> Add Training
            </button>
        </div>
    </div>
    <div class="card-body">
        <table id="trainings-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>

<div class="modal fade" id="trainings-modal" tabindex="-1">
    <div class="modal-dialog">
        <form id="trainings-form" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Training</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group col-md-8">
                        <label>Title of Training / Advanced Study</label>
                        <input type="text" name="training_title" class="form-control" maxlength="200" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label>Type</label>
                        <select name="training_type" class="form-control">
                            <option>Training</option>
                            <option>Advanced Study</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Training Institution <small class="text-muted">(school / provider)</small></label>
                        <input type="text" name="organizer" class="form-control" maxlength="150">
                    </div>
                    <div class="form-group col-md-6">
                        <label>College / University <small class="text-muted">(advanced studies)</small></label>
                        <input type="text" name="college_university" class="form-control" maxlength="150">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label>Duration</label>
                        <input type="text" name="duration" class="form-control" maxlength="60" placeholder="e.g. 3 days">
                    </div>
                    <div class="form-group col-md-4">
                        <label>Credits Earned</label>
                        <input type="text" name="credits_earned" class="form-control" maxlength="30" placeholder="e.g. 18 units">
                    </div>
                    <div class="form-group col-md-4">
                        <label>Year</label>
                        <input type="number" name="training_year" class="form-control" min="1950" max="<?= (int) date('Y') + 1 ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Purpose</label>
                        <select name="purpose" class="form-control">
                            <option value="">Select</option>
                            <option>Promotion</option>
                            <option>Professional Development</option>
                            <option>Other</option>
                        </select>
                    </div>
                    <div class="form-group col-md-6" id="purpose-other-wrap" style="display:none">
                        <label>Please specify</label>
                        <input type="text" name="purpose_other" class="form-control" maxlength="150">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label>Start Date</label>
                        <input type="date" name="date_start" class="form-control">
                    </div>
                    <div class="form-group col-md-4">
                        <label>End Date</label>
                        <input type="date" name="date_end" class="form-control">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>