<div class="card">
    <div class="card-body login-card-body" style="background: transparent;">
        <p class="login-box-msg">Sign in to start your session</p>

        <?php if (!empty($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?= e($_SESSION['error']) ?></div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <?php if (!empty($_SESSION['success'])): ?>
            <div class="alert alert-success"><?= e($_SESSION['success']) ?></div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <form action="<?= BASE_URL ?>/Auth/login" method="POST">
            <input type="hidden" name="_csrfToken" value="<?= e(csrf_token()) ?>">

            <div class="input-group mb-3">
                <input type="text" name="username" class="form-control" placeholder="Username or email" autofocus required>
                <div class="input-group-append">
                    <div class="input-group-text">
                        <span class="fas fa-user"></span>
                    </div>
                </div>
            </div>

            <div class="input-group mb-3">
                <input type="password" name="password" class="form-control" placeholder="Password" required>
                <div class="input-group-append">
                    <div class="input-group-text">
                        <span class="fas fa-lock"></span>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
        </form>

        <p class="mt-3 mb-0 text-center">
            <a href="<?= BASE_URL ?>/Auth/register">Alumni? Register here</a>
        </p>
    </div>
</div>