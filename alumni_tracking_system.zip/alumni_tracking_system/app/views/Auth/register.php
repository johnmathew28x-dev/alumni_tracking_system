<style>.auth-card { max-width: 560px; }</style>
<div class="card">
    <div class="card-body" style="background: transparent;">
        <p class="login-box-msg">Alumni registration</p>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
        <?php endif; ?>

        <form action="<?= BASE_URL ?>/Auth/register" method="POST">
            <input type="hidden" name="_csrfToken" value="<?= e(csrf_token()) ?>">

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label>First Name</label>
                    <input type="text" name="first_name" class="form-control" value="<?= e($old['first_name'] ?? '') ?>" required>
                </div>
                <div class="form-group col-md-6">
                    <label>Last Name</label>
                    <input type="text" name="last_name" class="form-control" value="<?= e($old['last_name'] ?? '') ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label>Username</label>
                    <input type="text" name="username" class="form-control" value="<?= e($old['username'] ?? '') ?>" required>
                </div>
                <div class="form-group col-md-6">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" value="<?= e($old['email'] ?? '') ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-8">
                    <label>Program</label>
                    <select name="program_id" class="form-control bg-dark-select" required>
                        <option value="">Select program</option>
                        <?php foreach ($programs as $p): ?>
                            <option value="<?= (int) $p->id ?>" <?= ($old['program_id'] ?? '') == $p->id ? 'selected' : '' ?>>
                                <?= e($p->program_code) ?> - <?= e($p->program_name) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group col-md-4">
                    <label>Graduation Year</label>
                    <input type="number" name="graduation_year" class="form-control" min="1950" max="<?= date('Y') + 6 ?>"
                           value="<?= e($old['graduation_year'] ?? '') ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" minlength="8" required>
                    <small>At least 8 characters</small>
                </div>
                <div class="form-group col-md-6">
                    <label>Confirm Password</label>
                    <input type="password" name="confirm_password" class="form-control" minlength="8" required>
                </div>
            </div>

            <button type="submit" class="btn btn-primary btn-block">Register</button>
        </form>

        <p class="mt-3 mb-0 text-center"><a href="<?= BASE_URL ?>/Auth">Back to login</a></p>
    </div>
</div>