<div class="card card-outline card-primary">
    <div class="card-body d-flex flex-wrap align-items-center justify-content-between">
        <div class="d-flex align-items-center">
            <img src="<?= e($profile['picture_url']) ?>" alt="" class="nav-avatar-lg js-avatar mr-3">
            <div>
                <div class="font-weight-bold"><?= e($profile['full_name']) ?></div>
                <div class="text-muted small"><?= e($profile['role']) ?></div>
            </div>
        </div>
        <a href="<?= BASE_URL ?>/Profile" class="btn btn-primary btn-sm mt-2 mt-sm-0">
            <i class="fas fa-user-edit"></i> View / Edit Profile &amp; Picture
        </a>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title">Change Password</h3>
            </div>
            <form id="password-form" autocomplete="off">
                <div class="card-body">
                    <div class="form-group">
                        <label>Current Password</label>
                        <input type="password" name="current_password" class="form-control" required autocomplete="current-password">
                    </div>
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" class="form-control" minlength="8" required autocomplete="new-password">
                        <small class="text-muted">At least 8 characters</small>
                    </div>
                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <input type="password" name="confirm_password" class="form-control" minlength="8" required autocomplete="new-password">
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Update Password</button>
                </div>
            </form>
        </div>
    </div>
</div>