<?php
$badge = ['verified' => 'success', 'pending' => 'warning', 'rejected' => 'danger'][$alumni->verification_status ?? ''] ?? 'secondary';
$isAlumni = $profile['is_alumni'];
?>

<div class="row">
    <div class="col-lg-4">
        <div class="card card-primary card-outline">
            <div class="card-body text-center">
                <img src="<?= e($profile['picture_url']) ?>" alt="Profile picture of <?= e($profile['full_name']) ?>"
                     id="profile-avatar" class="profile-avatar js-avatar" role="button" tabindex="0"
                     title="Click to view larger" data-toggle="tooltip">

                <h4 class="mt-3 mb-1" data-bind="full_name"><?= e($profile['full_name']) ?></h4>
                <div class="mb-2"><span class="badge badge-secondary"><?= e($profile['role']) ?></span></div>

                <?php if ($isAlumni): ?>
                    <div class="text-muted small">Alumni ID: <strong><?= e($alumni->alumni_id) ?></strong></div>
                    <span class="badge badge-<?= $badge ?> mt-1 p-2"><?= e(ucfirst($alumni->verification_status)) ?></span>
                <?php endif; ?>

                <hr>

                <form id="picture-form" enctype="multipart/form-data" novalidate>
                    <input type="file" id="picture-input" name="profile_picture" class="d-none"
                           accept="image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp">

                    <div id="picture-choose">
                        <button type="button" id="picture-pick" class="btn btn-sm btn-outline-primary">
                            <i class="fas fa-camera"></i> Change Picture
                        </button>
                        <button type="button" id="picture-remove" class="btn btn-sm btn-outline-danger <?= $profile['has_picture'] ? '' : 'd-none' ?>">
                            <i class="fas fa-trash"></i> Remove
                        </button>
                        <div class="text-muted small mt-2">JPG, PNG or WEBP &middot; up to 2 MB</div>
                    </div>

                    <div id="picture-preview-box" class="d-none">
                        <div class="text-muted small mb-1">Preview</div>
                        <img id="picture-preview" class="picture-preview" alt="Selected picture preview">
                        <div class="small text-muted mt-1 text-break" id="picture-name"></div>
                        <div class="mt-2">
                            <button type="submit" id="picture-save" class="btn btn-sm btn-primary">
                                <i class="fas fa-upload"></i> Save Picture
                            </button>
                            <button type="button" id="picture-cancel" class="btn btn-sm btn-outline-secondary">Cancel</button>
                        </div>
                    </div>
                    <div id="picture-error" class="text-danger small mt-2 d-none"></div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-body small">
                <a href="<?= BASE_URL ?>/Profile/settings" class="btn btn-sm btn-outline-secondary btn-block">
                    <i class="fas fa-key"></i> Change Password
                </a>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title">Profile Information</h3>
                <div class="card-tools">
                    <?php if ($isAlumni && $locked): ?>
                        <span class="badge badge-success mr-1"><i class="fas fa-lock"></i> Submitted &amp; locked</span>
                        <button type="button" id="request-correction-btn" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-edit"></i> Request Correction
                        </button>
                    <?php else: ?>
                        <button type="button" id="edit-profile-btn" class="btn btn-primary btn-sm">
                            <i class="fas fa-pen"></i> <?= $isAlumni ? 'Complete Personal Information' : 'Edit Profile' ?>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if ($isAlumni && !$locked): ?>
                    <div class="alert alert-warning" role="status">
                        <i class="fas fa-info-circle"></i>
                        <strong>Your personal information has not been submitted yet.</strong>
                        Complete the form and submit it. Once submitted, it is locked and can only be changed through a correction request reviewed by an administrator.
                    </div>
                <?php elseif ($isAlumni): ?>
                    <div class="alert alert-info" role="status">
                        <i class="fas fa-lock"></i>
                        <strong>Your personal information is locked.</strong>
                        It was submitted and can no longer be edited directly. If something is wrong or outdated, use <em>Request Correction</em>; an administrator will review it.
                    </div>
                <?php endif; ?>

                <?php foreach ($profile['sections'] as $i => $section): ?>
                    <h6 class="section-title"><?= e($section['title']) ?></h6>
                    <dl class="row profile-details <?= $i === count($profile['sections']) - 1 ? 'mb-0' : '' ?>">
                        <?php foreach ($section['items'] as $key => $item): ?>
                            <dt class="col-sm-4"><?= e($item['label']) ?></dt>
                            <dd class="col-sm-8" data-bind="<?= e($key) ?>"><?= e($item['value']) ?></dd>
                        <?php endforeach; ?>
                    </dl>
                <?php endforeach; ?>
            </div>
        </div>

        <?php if ($isAlumni && $corrections): ?>
            <div class="card">
                <div class="card-header"><h3 class="card-title">My Correction Requests</h3></div>
                <div class="card-body p-0 table-responsive">
                    <table class="table table-sm mb-0">
                        <thead><tr><th>Filed</th><th>Requested change</th><th>Status</th><th>Admin note</th></tr></thead>
                        <tbody>
                        <?php foreach ($corrections as $c): ?>
                            <?php $cls = ['pending' => 'warning', 'approved' => 'success', 'rejected' => 'danger'][$c->status] ?? 'secondary'; ?>
                            <tr>
                                <td class="text-nowrap"><?= e(date('M d, Y', strtotime($c->created))) ?></td>
                                <td>
                                    <?php foreach ($c->change_list as $ch): ?>
                                        <div><strong><?= e($ch['label']) ?>:</strong> <?= e($ch['old'] ?? '—') ?> &rarr; <?= e($ch['new'] ?? '—') ?></div>
                                    <?php endforeach; ?>
                                    <div class="text-muted small">Reason: <?= e($c->reason) ?></div>
                                </td>
                                <td><span class="badge badge-<?= $cls ?>"><?= e(ucfirst($c->status)) ?></span></td>
                                <td class="small"><?= e($c->review_note ?? '—') ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="modal fade" id="avatar-modal" tabindex="-1" role="dialog" aria-label="Profile picture">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content avatar-modal-content">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title"><?= e($profile['full_name']) ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center">
                <img id="avatar-large" class="avatar-large js-avatar" src="<?= e($profile['picture_url']) ?>" alt="Profile picture (large)">
            </div>
        </div>
    </div>
</div>

<?php if (!$isAlumni): ?>
<div class="modal fade" id="edit-profile-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <form id="profile-form" class="modal-content" novalidate autocomplete="off">
            <div class="modal-header">
                <h5 class="modal-title">Edit Profile</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                    <div class="form-group">
                        <label>Username <span class="text-danger">*</span></label>
                        <input type="text" name="username" class="form-control" minlength="3" maxlength="55" pattern="[A-Za-z0-9_.\-]{3,55}" value="<?= e($account->username) ?>" required>
                        <small class="text-muted">Letters, numbers, dot, dash or underscore.</small>
                    </div>
                    <div class="form-group">
                        <label>Email <span class="text-danger">*</span></label>
                        <input type="email" name="email" class="form-control" maxlength="150" value="<?= e($account->email) ?>" required>
                    </div>
                    <p class="text-muted small mb-0">Your role and account status can only be changed by an administrator.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
            </div>
        </form>
    </div>
</div>
<?php elseif (!$locked): ?>
<div class="modal fade" id="edit-profile-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <form id="profile-form" class="modal-content" novalidate autocomplete="off">
            <div class="modal-header">
                <h5 class="modal-title">Personal Information</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="text-muted small">
                    <strong>Save Draft</strong> keeps your answers and you can keep editing.
                    <strong>Submit &amp; Lock</strong> is final: you will no longer be able to edit this information directly.
                </p>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label>First Name <span class="text-danger">*</span></label>
                            <input type="text" name="first_name" class="form-control" maxlength="100" value="<?= e($alumni->first_name) ?>" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Middle Name</label>
                            <input type="text" name="middle_name" class="form-control" maxlength="100" value="<?= e($alumni->middle_name) ?>">
                        </div>
                        <div class="form-group col-md-4">
                            <label>Last Name <span class="text-danger">*</span></label>
                            <input type="text" name="last_name" class="form-control" maxlength="100" value="<?= e($alumni->last_name) ?>" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-2">
                            <label>Suffix</label>
                            <input type="text" name="suffix" class="form-control" maxlength="10" value="<?= e($alumni->suffix) ?>" placeholder="Jr., III">
                        </div>
                        <div class="form-group col-md-4">
                            <label>Date of Birth <span class="text-danger">*</span></label>
                            <input type="date" name="date_of_birth" class="form-control" max="<?= date('Y-m-d', strtotime('-16 years')) ?>" value="<?= e($alumni->date_of_birth) ?>" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Sex <span class="text-danger">*</span></label>
                            <select name="gender" class="form-control" required>
                                <option value="">Select</option>
                                <?php foreach (['Male', 'Female', 'Other'] as $g): ?>
                                    <option <?= $alumni->gender === $g ? 'selected' : '' ?>><?= $g ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Civil Status <span class="text-danger">*</span></label>
                            <select name="civil_status_id" class="form-control" required>
                                <option value="">Select</option>
                                <?php foreach ($lookups->ref('civil_statuses') as $r): ?>
                                    <option value="<?= (int) $r->id ?>" <?= (int) $alumni->civil_status_id === (int) $r->id ? 'selected' : '' ?>><?= e($r->name) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Mobile Number</label>
                            <input type="text" name="contact_number" class="form-control" maxlength="20" value="<?= e($alumni->contact_number) ?>" placeholder="09171234567">
                        </div>
                        
                        <div class="form-group col-md-6">
                            <label>Email</label>
                            <input type="email" class="form-control" value="<?= e($alumni->email) ?>" disabled>
                            <small class="text-muted">Contact the administrator to change your account email.</small>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Permanent Address</label>
                        <input type="text" name="address" class="form-control" maxlength="255" value="<?= e($alumni->address) ?>">
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label>Region of Origin <span class="text-danger">*</span></label>
                            <select name="region_id" class="form-control" required>
                                <option value="">Select</option>
                                <?php foreach ($lookups->ref('regions') as $r): ?>
                                    <option value="<?= (int) $r->id ?>" <?= (int) $alumni->region_id === (int) $r->id ? 'selected' : '' ?>><?= e($r->name) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Province <span class="text-danger">*</span></label>
                            <input type="text" name="province" class="form-control" maxlength="100" value="<?= e($alumni->province) ?>" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label>City / Municipality</label>
                            <input type="text" name="city_municipality" class="form-control" maxlength="100" value="<?= e($alumni->city_municipality) ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label>Residence Type</label>
                            <select name="residence_type_id" class="form-control">
                                <option value="">Select</option>
                                <?php foreach ($lookups->ref('residence_types') as $r): ?>
                                    <option value="<?= (int) $r->id ?>" <?= (int) $alumni->residence_type_id === (int) $r->id ? 'selected' : '' ?>><?= e($r->name) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="card card-body bg-light small mb-3" id="privacy-notice">
                        <strong>Privacy Notice</strong>
                        <p class="mb-1 mt-1">
                            Northeastern College collects this information for alumni record keeping and tracer-study purposes only.
                            Only you and authorized administrators can see it. Once submitted, it is locked; corrections go through an administrator-reviewed request.
                        </p>
                        <ul class="mb-1 pl-3">
                            <li>Legal basis: <em>[to be provided by the institution]</em></li>
                            <li>Retention period: <em>[to be provided by the institution]</em></li>
                            <li>Data Protection Officer / privacy contact: <em>[to be provided by the institution]</em></li>
                        </ul>
                        <span class="text-muted">This notice is a template and must be reviewed and completed by the institution's Data Protection Officer.</span>
                    </div>
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="privacy-ack" name="privacy_ack" value="1">
                        <label class="custom-control-label" for="privacy-ack">
                            I have read the privacy notice and confirm that the information above is true and correct.
                        </label>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-outline-primary"><i class="fas fa-save"></i> Save Draft</button>
                <button type="button" id="submit-profile-btn" class="btn btn-primary"><i class="fas fa-lock"></i> Submit &amp; Lock</button>
            </div>
        </form>
    </div>
</div>
<?php else: ?>
<div class="modal fade" id="correction-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <form id="correction-form" class="modal-content" novalidate autocomplete="off">
            <div class="modal-header">
                <h5 class="modal-title">Request a Correction</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="text-muted small">
                    Change only the information that is wrong or outdated, then explain why.
                    Your saved information stays unchanged until an administrator approves the request.
                </p>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label>First Name <span class="text-danger">*</span></label>
                            <input type="text" name="first_name" class="form-control" maxlength="100" value="<?= e($alumni->first_name) ?>" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Middle Name</label>
                            <input type="text" name="middle_name" class="form-control" maxlength="100" value="<?= e($alumni->middle_name) ?>">
                        </div>
                        <div class="form-group col-md-4">
                            <label>Last Name <span class="text-danger">*</span></label>
                            <input type="text" name="last_name" class="form-control" maxlength="100" value="<?= e($alumni->last_name) ?>" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-2">
                            <label>Suffix</label>
                            <input type="text" name="suffix" class="form-control" maxlength="10" value="<?= e($alumni->suffix) ?>" placeholder="Jr., III">
                        </div>
                        <div class="form-group col-md-4">
                            <label>Date of Birth <span class="text-danger">*</span></label>
                            <input type="date" name="date_of_birth" class="form-control" max="<?= date('Y-m-d', strtotime('-16 years')) ?>" value="<?= e($alumni->date_of_birth) ?>" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Sex <span class="text-danger">*</span></label>
                            <select name="gender" class="form-control" required>
                                <option value="">Select</option>
                                <?php foreach (['Male', 'Female', 'Other'] as $g): ?>
                                    <option <?= $alumni->gender === $g ? 'selected' : '' ?>><?= $g ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Civil Status <span class="text-danger">*</span></label>
                            <select name="civil_status_id" class="form-control" required>
                                <option value="">Select</option>
                                <?php foreach ($lookups->ref('civil_statuses') as $r): ?>
                                    <option value="<?= (int) $r->id ?>" <?= (int) $alumni->civil_status_id === (int) $r->id ? 'selected' : '' ?>><?= e($r->name) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Mobile Number</label>
                            <input type="text" name="contact_number" class="form-control" maxlength="20" value="<?= e($alumni->contact_number) ?>" placeholder="09171234567">
                        </div>
                        
                        <div class="form-group col-md-6">
                            <label>Email</label>
                            <input type="email" class="form-control" value="<?= e($alumni->email) ?>" disabled>
                            <small class="text-muted">Contact the administrator to change your account email.</small>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Permanent Address</label>
                        <input type="text" name="address" class="form-control" maxlength="255" value="<?= e($alumni->address) ?>">
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label>Region of Origin <span class="text-danger">*</span></label>
                            <select name="region_id" class="form-control" required>
                                <option value="">Select</option>
                                <?php foreach ($lookups->ref('regions') as $r): ?>
                                    <option value="<?= (int) $r->id ?>" <?= (int) $alumni->region_id === (int) $r->id ? 'selected' : '' ?>><?= e($r->name) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Province <span class="text-danger">*</span></label>
                            <input type="text" name="province" class="form-control" maxlength="100" value="<?= e($alumni->province) ?>" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label>City / Municipality</label>
                            <input type="text" name="city_municipality" class="form-control" maxlength="100" value="<?= e($alumni->city_municipality) ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label>Residence Type</label>
                            <select name="residence_type_id" class="form-control">
                                <option value="">Select</option>
                                <?php foreach ($lookups->ref('residence_types') as $r): ?>
                                    <option value="<?= (int) $r->id ?>" <?= (int) $alumni->residence_type_id === (int) $r->id ? 'selected' : '' ?>><?= e($r->name) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                <div class="form-group">
                    <label for="correction-reason">Reason for the correction <span class="text-danger">*</span></label>
                    <textarea id="correction-reason" name="reason" class="form-control" rows="3" minlength="10" maxlength="500" required></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send Request</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
