<?php 
$programs = $lookups->programs(); 
$levels   = $lookups->educationLevels(); 
?>

<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title">Program / Degree Information</h3>
        <div class="card-tools">
            <button type="button" class="btn btn-primary btn-sm" id="add-academic">
                <i class="fas fa-plus"></i> Add Program
            </button>
        </div>
    </div>
    <div class="card-body">
        <table id="academics-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>

<div class="card card-info card-outline">
    <div class="card-header">
        <h3 class="card-title">Further Education</h3>
        <div class="card-tools">
            <button type="button" class="btn btn-primary btn-sm" id="add-education">
                <i class="fas fa-plus"></i> Add Education
            </button>
        </div>
    </div>
    <div class="card-body">
        <table id="educations-table" class="table table-bordered table-striped w-100"></table>
    </div>
</div>

<div class="modal fade" id="academics-modal" tabindex="-1">
    <div class="modal-dialog">
        <form id="academics-form" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Program</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            
            <div class="modal-body">
                <div class="form-group">
                    <label>Program</label>
                    <select name="program_id" class="form-control" required>
                        <option value="">Select program</option>
                        <?php foreach ($programs as $p): ?>
                            <option value="<?= (int) $p->id ?>">
                                <?= e($p->program_code) ?> - <?= e($p->program_name) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Major</label>
                        <input type="text" name="major" class="form-control">
                    </div>
                    <div class="form-group col-md-6">
                        <label>Graduation Year</label>
                        <input type="number" name="graduation_year" class="form-control" min="1950" max="<?= date('Y') + 6 ?>" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Batch</label>
                        <input type="text" name="batch" class="form-control" placeholder="e.g. Batch 2024">
                    </div>
                    <div class="form-group col-md-6">
                        <label>Student ID</label>
                        <input type="text" name="student_id" class="form-control">
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="educations-modal" tabindex="-1">
    <div class="modal-dialog">
        <form id="educations-form" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Education</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Level</label>
                        <select name="education_level_id" class="form-control" required>
                            <option value="">Select level</option>
                            <?php foreach ($levels as $l): ?>
                                <option value="<?= (int) $l->id ?>"><?= e($l->level_name) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="Completed">Completed</option>
                            <option value="Ongoing">Ongoing</option>
                            <option value="Discontinued">Discontinued</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label>Institution</label>
                    <input type="text" name="institution" class="form-control" required>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Degree</label>
                        <input type="text" name="degree" class="form-control">
                    </div>
                    <div class="form-group col-md-6">
                        <label>Field of Study</label>
                        <input type="text" name="field_of_study" class="form-control">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Start Year</label>
                        <input type="number" name="start_year" class="form-control" min="1950" max="<?= date('Y') + 6 ?>">
                    </div>
                    <div class="form-group col-md-6">
                        <label>End Year</label>
                        <input type="number" name="end_year" class="form-control" min="1950" max="<?= date('Y') + 10 ?>">
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>