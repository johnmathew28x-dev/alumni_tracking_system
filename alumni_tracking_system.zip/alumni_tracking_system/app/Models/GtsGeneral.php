<?php

namespace Models;

use DateTime;
use ArrayAccess;

class GtsGeneral
{
    public static function validate(ArrayAccess $d): array
    {
        $errors = [];
        $lookups = new Lookups();

        if (trim($d['first_name'] ?? '') === '' || trim($d['last_name'] ?? '') === '') {
            $errors['first_name'] = 'First and last name are required.';
        }

        if (!in_array($d['gender'] ?? '', ['Male', 'Female', 'Other'], true)) {
            $errors['gender'] = 'Please choose your sex.';
        }

        $dob = $d['date_of_birth'] ?? '';
        if ($dob === '') {
            $errors['date_of_birth'] = 'Birthday is required.';
        } else {
            $dt = DateTime::createFromFormat('Y-m-d', $dob);
            $minAgeDate = date('Y-m-d', strtotime('-16 years'));

            if (!$dt || $dt->format('Y-m-d') !== $dob || $dob >= $minAgeDate) {
                $errors['date_of_birth'] = 'Please enter a valid birthday.';
            }
        }

        if (!in_array((int) ($d['civil_status_id'] ?? 0), $lookups->validIds('civil_statuses'), true)) {
            $errors['civil_status_id'] = 'Please choose your civil status.';
        }

        if (!in_array((int) ($d['region_id'] ?? 0), $lookups->validIds('regions'), true)) {
            $errors['region_id'] = 'Please choose your region of origin.';
        }

        if (trim($d['province'] ?? '') === '') {
            $errors['province'] = 'Province is required.';
        }

        $residenceTypeId = $d['residence_type_id'] ?? '';
        if ($residenceTypeId !== '' && !in_array((int) $residenceTypeId, $lookups->validIds('residence_types'), true)) {
            $errors['residence_type_id'] = 'Invalid residence type.';
        }

        $phoneFields = [
            'contact_number' => 'Mobile number'
        ];

        foreach ($phoneFields as $field => $label) {
            $value = $d[$field] ?? '';
            if ($value !== '' && !preg_match('/^[0-9+\-\s()]{7,20}$/', $value)) {
                $errors[$field] = $label . ' may only contain digits, spaces, + - ( ) (7-20 characters).';
            }
        }

        if (strlen($d['address'] ?? '') > 255) {
            $errors['address'] = 'Address is too long.';
        }

        $row = [
            'first_name'          => $d['first_name'] ?? null,
            'middle_name'         => !empty($d['middle_name']) ? $d['middle_name'] : null,
            'last_name'           => $d['last_name'] ?? null,
            'suffix'              => !empty($d['suffix']) ? $d['suffix'] : null,
            'date_of_birth'       => !empty($d['date_of_birth']) ? $d['date_of_birth'] : null,
            'gender'              => $d['gender'] ?? null,
            'contact_number'      => !empty($d['contact_number']) ? $d['contact_number'] : null,
            'address'             => !empty($d['address']) ? $d['address'] : null,
            'civil_status_id'     => ($d['civil_status_id'] ?? '') !== '' ? (int) $d['civil_status_id'] : null,
            'region_id'           => ($d['region_id'] ?? '') !== '' ? (int) $d['region_id'] : null,
            'province'            => !empty($d['province']) ? substr($d['province'], 0, 100) : null,
            'city_municipality'   => !empty($d['city_municipality']) ? substr($d['city_municipality'], 0, 100) : null,
            'residence_type_id'   => ($d['residence_type_id'] ?? '') !== '' ? (int) $d['residence_type_id'] : null,
            'last_profile_update' => date('Y-m-d H:i:s'),
        ];

        return [$errors, $row];
    }
}