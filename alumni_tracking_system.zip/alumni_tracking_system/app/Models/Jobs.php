<?php

namespace Models;

use Core\Model;

class Jobs extends Model
{
    public function find(): array
    {
        return db_run($this->db, 
            'SELECT j.id, 
                    j.job_title, 
                    j.company, 
                    j.location, 
                    j.description, 
                    j.qualifications,
                    j.application_instructions, 
                    j.deadline, 
                    j.status, 
                    j.created, 
                    u.username AS created_by_name
             FROM job_postings j
             JOIN users u ON u.id = j.created_by
             ORDER BY j.created DESC'
        )->fetchAll();
    }

    public function open(): array
    {
        return db_run($this->db, 
            "SELECT id, 
                    job_title, 
                    company, 
                    location, 
                    description, 
                    qualifications, 
                    application_instructions, 
                    deadline
             FROM job_postings
             WHERE status = 'open'
             ORDER BY created DESC"
        )->fetchAll();
    }

    public function findByID(int|string $id): ?object
    {
        return db_run($this->db, 
            'SELECT id, 
                    job_title, 
                    company, 
                    location, 
                    description, 
                    qualifications,
                    application_instructions, 
                    deadline, 
                    status
             FROM job_postings 
             WHERE id = ?',
            [$id]
        )->fetch() ?: null;
    }

    public function save(array $data): bool|int
    {
        $allowed = [
            'id', 
            'job_title', 
            'company', 
            'location', 
            'description', 
            'qualifications',
            'application_instructions', 
            'deadline', 
            'status', 
            'created_by'
        ];

        return db_save($this->db, 'job_postings', array_intersect_key($data, array_flip($allowed)));
    }

    public function setStatus(int|string $id, string $status): bool
    {
        return db_run($this->db, 
            'UPDATE job_postings SET status = ?, modified = ? WHERE id = ?',
            [$status, date('Y-m-d H:i:s'), $id]
        )->rowCount() > 0;
    }

    public function openCount(): int
    {
        return (int) db_run($this->db, "SELECT COUNT(*) FROM job_postings WHERE status = 'open'")->fetchColumn();
    }

    public function delete(int|string $id): bool
    {
        return db_run($this->db, 'DELETE FROM job_postings WHERE id = ?', [$id])->rowCount() > 0;
    }
}