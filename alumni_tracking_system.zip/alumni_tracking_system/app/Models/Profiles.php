<?php

namespace Models;

use Core\Model;

class Profiles extends Model
{
    public function forUser(int $userId): array
    {
        $user = (new Users())->findByID($userId);

        $out = [
            'picture_url' => avatar_url($user->profile_picture ?? null),
            'has_picture' => !empty($user->profile_picture) && is_file(PROFILE_UPLOAD_DIR . '/' . $user->profile_picture),
            'full_name'   => $user->username,
            'username'    => $user->username,
            'role'        => $user->role,
            'is_alumni'   => $user->role === Users::ALUMNI,
            'sections'    => [],
        ];

        $dash = fn($v) => ($v === null || $v === '') ? '—' : (string) $v;

        if (!$out['is_alumni']) {
            $out['sections'][] = [
                'title' => 'Account Information',
                'items' => [
                    'username'     => ['label' => 'Username', 'value' => $dash($user->username)],
                    'email'        => ['label' => 'Email', 'value' => $dash($user->email)],
                    'role'         => ['label' => 'Role', 'value' => $dash($user->role)],
                    'status'       => ['label' => 'Account Status', 'value' => ucfirst($user->status)],
                    'member_since' => ['label' => 'Member Since', 'value' => date('M d, Y', strtotime($user->created))],
                ],
            ];

            return $out;
        }

        $a = db_run($this->db, 
            'SELECT a.*, 
                    cs.name AS civil_status, 
                    rg.name AS region, 
                    rt.name AS residence_type,
                    p.program_code, 
                    p.program_name, 
                    d.department_name,
                    aa.major, 
                    aa.graduation_year, 
                    aa.batch, 
                    aa.honors_awards, 
                    aa.student_id
             FROM alumni a
             LEFT JOIN civil_statuses cs ON cs.id = a.civil_status_id
             LEFT JOIN regions rg ON rg.id = a.region_id
             LEFT JOIN residence_types rt ON rt.id = a.residence_type_id
             LEFT JOIN alumni_academic aa ON aa.id = (SELECT MAX(x.id) FROM alumni_academic x WHERE x.alumni_id = a.id)
             LEFT JOIN programs p ON p.id = aa.program_id
             LEFT JOIN departments d ON d.id = p.department_id
             WHERE a.user_id = ?',
            [$userId]
        )->fetch();

        if (!$a) {
            return $out;
        }

        $out['full_name'] = trim(implode(' ', array_filter([$a->first_name, $a->middle_name, $a->last_name, $a->suffix])));

        $out['sections'][] = [
            'title' => 'Personal Information',
            'items' => [
                'full_name'        => ['label' => 'Full Name', 'value' => $dash($out['full_name'])],
                'alumni_id'        => ['label' => 'Alumni ID', 'value' => $dash($a->alumni_id)],
                'username'         => ['label' => 'Username', 'value' => $dash($user->username)],
                'email'            => ['label' => 'Email', 'value' => $dash($a->email ?: $user->email)],
                'gender'           => ['label' => 'Sex', 'value' => $dash($a->gender)],
                'date_of_birth'    => ['label' => 'Date of Birth', 'value' => $a->date_of_birth ? date('M d, Y', strtotime($a->date_of_birth)) : '—'],
                'civil_status'     => ['label' => 'Civil Status', 'value' => $dash($a->civil_status)],
                'contact_number'   => ['label' => 'Mobile Number', 'value' => $dash($a->contact_number)],
                'address'          => ['label' => 'Permanent Address', 'value' => $dash($a->address)],
                'location'         => ['label' => 'City / Province', 'value' => $dash(implode(', ', array_filter([$a->city_municipality, $a->province])))],
                'region'           => ['label' => 'Region of Origin', 'value' => $dash($a->region)],
                'residence_type'   => ['label' => 'Residence Type', 'value' => $dash($a->residence_type)],
            ],
        ];

        $out['sections'][] = [
            'title' => 'Academic / Graduation Information',
            'items' => [
                'program'         => ['label' => 'Course / Program', 'value' => $a->program_name ? $a->program_code . ' - ' . $a->program_name : '—'],
                'department'      => ['label' => 'Department', 'value' => $dash($a->department_name)],
                'major'           => ['label' => 'Major', 'value' => $dash($a->major)],
                'graduation_year' => ['label' => 'Graduation Year', 'value' => $dash($a->graduation_year)],
                'batch'           => ['label' => 'Batch', 'value' => $dash($a->batch)],
                'honors_awards'   => ['label' => 'Honors / Awards', 'value' => $dash($a->honors_awards)],
                'student_id'      => ['label' => 'Student ID', 'value' => $dash($a->student_id)],
            ],
        ];

        $out['sections'][] = [
            'title' => 'Alumni Record',
            'items' => [
                'submission_status'   => ['label' => 'Profile Submission', 'value' => ($a->submission_status ?? 'draft') === 'submitted' ? 'Submitted (locked)' : 'Not yet submitted'],
                'submitted_at'        => ['label' => 'Submitted On', 'value' => !empty($a->submitted_at) ? date('M d, Y g:i A', strtotime($a->submitted_at)) : '—'],
                'verification_status' => ['label' => 'Review Status', 'value' => ['pending' => 'Awaiting review', 'verified' => 'Approved', 'rejected' => 'Rejected'][$a->verification_status] ?? ucfirst($a->verification_status)],
                'profile_status'      => ['label' => 'Alumni Status', 'value' => ucfirst($a->profile_status)],
                'last_profile_update' => ['label' => 'Last Profile Update', 'value' => $a->last_profile_update ? date('M d, Y g:i A', strtotime($a->last_profile_update)) : '—'],
            ],
        ];

        return $out;
    }

    public function flatten(array $profile): array
    {
        $flat = ['full_name' => $profile['full_name']];

        foreach ($profile['sections'] as $section) {
            foreach ($section['items'] as $key => $item) {
                $flat[$key] = $item['value'];
            }
        }

        return $flat;
    }
}