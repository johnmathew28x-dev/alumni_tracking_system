<?php

namespace Models;

use Core\Model;

class TracerQuestions extends Model
{
    public function forStudy(int $studyId): array
    {
        return db_run($this->db, 
            'SELECT id, tracer_study_id, question, question_type, options, is_required, sort_order
             FROM tracer_questions
             WHERE tracer_study_id = ?
             ORDER BY sort_order, id',
            [$studyId]
        )->fetchAll();
    }

    public function findByID(int $id): ?object
    {
        return db_run($this->db, 
            'SELECT id, tracer_study_id, question, question_type, options, is_required, sort_order
             FROM tracer_questions 
             WHERE id = ?',
            [$id]
        )->fetch() ?: null;
    }

    public function save(array $data)
    {
        $allowed = ['id', 'tracer_study_id', 'question', 'question_type', 'options', 'is_required', 'sort_order'];
        
        return db_save($this->db, 'tracer_questions', array_intersect_key($data, array_flip($allowed)));
    }

    public function delete(int $id): bool
    {
        return db_run($this->db, 'DELETE FROM tracer_questions WHERE id = ?', [$id])->rowCount() > 0;
    }
}