<?php

namespace Models;

use Core\Model;

class Events extends Model
{
    public function find()
    {
        return db_run($this->db, 
            "SELECT e.id, e.title, e.description, e.event_date, e.event_time, e.location,
                    e.registration_deadline, e.status, u.username AS created_by_name,
                    (SELECT COUNT(*) FROM event_registrations r
                      WHERE r.event_id = e.id AND r.registration_status IN ('registered', 'attended')) AS registered_count,
                    (SELECT COUNT(*) FROM event_registrations r
                      WHERE r.event_id = e.id AND r.registration_status = 'attended') AS attended_count
             FROM events e
             JOIN users u ON u.id = e.created_by
             ORDER BY e.event_date DESC"
        )->fetchAll();
    }

    public function upcoming($alumniId = null)
    {
        return db_run($this->db, 
            "SELECT e.id, e.title, e.description, e.event_date, e.event_time, e.location,
                    e.registration_deadline, e.status,
                    (SELECT COUNT(*) FROM event_registrations r
                      WHERE r.event_id = e.id AND r.alumni_id = ? AND r.registration_status IN ('registered', 'attended')) AS is_registered
             FROM events e
             WHERE e.status IN ('upcoming', 'ongoing')
             ORDER BY e.event_date ASC",
            [(int) $alumniId]
        )->fetchAll();
    }

    public function findByID($id)
    {
        return db_run($this->db, 
            'SELECT id, title, description, event_date, event_time, location, registration_deadline, status
             FROM events WHERE id = ?',
            [$id]
        )->fetch() ?: null;
    }

    public function save($data)
    {
        $allowed = [
            'id', 'title', 'description', 'event_date', 'event_time', 'location',
            'registration_deadline', 'status', 'created_by',
        ];

        return db_save($this->db, 'events', array_intersect_key($data, array_flip($allowed)));
    }

    public function delete($id): bool
    {
        return db_run($this->db, 'DELETE FROM events WHERE id = ?', [$id])->rowCount() > 0;
    }

    public function participants($eventId)
    {
        return db_run($this->db, 
            'SELECT r.id, r.registration_status, r.created, a.alumni_id AS alumni_number, a.first_name, a.last_name,
                    a.profile_status, e.status AS event_status
             FROM event_registrations r
             JOIN alumni a ON a.id = r.alumni_id
             JOIN events e ON e.id = r.event_id
             WHERE r.event_id = ?
             ORDER BY r.created DESC',
            [$eventId]
        )->fetchAll();
    }

    public function findRegistration($eventId, $alumniId)
    {
        return db_run($this->db, 
            'SELECT id, registration_status FROM event_registrations WHERE event_id = ? AND alumni_id = ?',
            [$eventId, $alumniId]
        )->fetch() ?: null;
    }

    public function register($eventId, $alumniId): bool
    {
        $existing = $this->findRegistration($eventId, $alumniId);

        return db_save($this->db, 'event_registrations', [
            'id'                  => $existing->id ?? null,
            'event_id'            => $eventId,
            'alumni_id'           => $alumniId,
            'registration_status' => 'registered',
        ]);
    }

    public function cancelRegistration($eventId, $alumniId): bool
    {
        return db_run($this->db, 
            "UPDATE event_registrations SET registration_status = 'cancelled', modified = ?
             WHERE event_id = ? AND alumni_id = ?",
            [date('Y-m-d H:i:s'), $eventId, $alumniId]
        )->rowCount() > 0;
    }

    public function findRegistrationByID($id)
    {
        return db_run($this->db, 
            'SELECT r.id, r.event_id, r.alumni_id, r.registration_status, e.status AS event_status
             FROM event_registrations r
             JOIN events e ON e.id = r.event_id
             WHERE r.id = ?',
            [$id]
        )->fetch() ?: null;
    }

    public function setAttendance($registrationId, string $status): bool
    {
        return db_run($this->db, 
            'UPDATE event_registrations SET registration_status = ?, modified = ? WHERE id = ?',
            [$status, date('Y-m-d H:i:s'), $registrationId]
        )->rowCount() > 0;
    }

    public function attendanceFor($alumniId): array
    {
        $total = (int) db_run($this->db, "SELECT COUNT(*) FROM events WHERE status = 'completed'")->fetchColumn();

        $stmt = db_run($this->db, 
            "SELECT COUNT(*) FROM event_registrations r
             JOIN events e ON e.id = r.event_id AND e.status = 'completed'
             WHERE r.alumni_id = ? AND r.registration_status = 'attended'",
            [(int) $alumniId]
        );
        $attended = (int) $stmt->fetchColumn();

        return [
            'attended' => $attended,
            'total'    => $total,
            'rate'     => $total > 0 ? round($attended / $total * 100, 1) : null,
        ];
    }

    public function attendedBy($alumniId)
    {
        return db_run($this->db, 
            "SELECT e.id, e.title, e.event_date, e.location
             FROM event_registrations r
             JOIN events e ON e.id = r.event_id
             WHERE r.alumni_id = ? AND r.registration_status = 'attended'
             ORDER BY e.event_date DESC",
            [(int) $alumniId]
        )->fetchAll();
    }

    public function upcomingCount(): int
    {
        return (int) db_run($this->db, 
            "SELECT COUNT(*) FROM events WHERE status IN ('upcoming', 'ongoing')"
        )->fetchColumn();
    }
}