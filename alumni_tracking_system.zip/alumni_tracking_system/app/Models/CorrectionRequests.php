<?php

namespace Models;

use ArrayObject;
use Core\Model;

class CorrectionRequests extends Model
{
    public const LABELS = [
        'first_name'        => 'First Name',
        'middle_name'       => 'Middle Name',
        'last_name'         => 'Last Name',
        'suffix'            => 'Suffix',
        'date_of_birth'     => 'Date of Birth',
        'gender'            => 'Sex',
        'contact_number'    => 'Mobile Number',
        'address'           => 'Permanent Address',
        'civil_status_id'   => 'Civil Status',
        'region_id'         => 'Region of Origin',
        'province'          => 'Province',
        'city_municipality' => 'City / Municipality',
        'residence_type_id' => 'Residence Type',
    ];

    private const LOOKUP_TABLES = [
        'civil_status_id'   => 'civil_statuses',
        'region_id'         => 'regions',
        'residence_type_id' => 'residence_types',
    ];

    public const SENSITIVE = ['first_name', 'middle_name', 'last_name', 'suffix', 'date_of_birth'];

    public function buildChanges($alumni, $input): array
    {
        $current = Alumni::snapshot($alumni);
        $merged  = $current;

        foreach (Alumni::PERSONAL_FIELDS as $field) {
            if (isset($input[$field])) {
                $merged[$field] = $input[$field];
            }
        }

        [$errors, $row] = GtsGeneral::validate(new ArrayObject($merged));

        $changes = Alumni::diff($current, $row);

        return [$this->relevantErrors($errors, $changes), $this->withLabels($changes)];
    }

    private function relevantErrors(array $errors, array $changes): array
    {
        $fields = array_keys($changes);

        if (in_array('last_name', $fields, true)) {
            $fields[] = 'first_name';
        }

        return array_intersect_key($errors, array_flip($fields));
    }

    private function withLabels(array $changes): array
    {
        $Lookups = new Lookups();

        foreach ($changes as $field => &$change) {
            if (!isset(self::LOOKUP_TABLES[$field])) {
                continue;
            }

            $names = [];
            foreach ($Lookups->ref(self::LOOKUP_TABLES[$field], false) as $r) {
                $names[(int) $r->id] = $r->name;
            }

            $change['old_label'] = $change['old'] !== null ? ($names[$change['old']] ?? null) : null;
            $change['new_label'] = $change['new'] !== null ? ($names[$change['new']] ?? null) : null;
        }

        return $changes;
    }

    public function create(int $alumniId, array $changes, string $reason)
    {
        try {
            $this->db->beginTransaction();

            db_run($this->db, 'SELECT id FROM alumni WHERE id = ? FOR UPDATE', [$alumniId]);

            $pending = (int) db_run(
                $this->db,
                "SELECT COUNT(*) FROM alumni_correction_requests WHERE alumni_id = ? AND status = 'pending'",
                [$alumniId]
            )->fetchColumn();

            if ($pending > 0) {
                $this->db->rollBack();
                return false;
            }

            db_run(
                $this->db,
                "INSERT INTO alumni_correction_requests (alumni_id, source, changes, reason, status, created, modified)
                 VALUES (?, 'alumni', ?, ?, 'pending', ?, ?)",
                [$alumniId, json_encode($changes, JSON_UNESCAPED_UNICODE), $reason, date('Y-m-d H:i:s'), date('Y-m-d H:i:s')]
            );

            $id = (int) $this->db->lastInsertId();
            $this->db->commit();

            return $id;
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            error_log($e);
            return false;
        }
    }

    public function forAlumni(int $alumniId): array
    {
        $rows = db_run(
            $this->db,
            'SELECT id, source, changes, reason, status, reviewed_at, review_note, created
             FROM alumni_correction_requests
             WHERE alumni_id = ? AND source = \'alumni\'
             ORDER BY id DESC LIMIT 20',
            [$alumniId]
        )->fetchAll();

        return $this->decode($rows);
    }

    public function all(string $status = ''): array
    {
        $sql = "SELECT r.id, r.alumni_id, r.source, r.changes, r.reason, r.status, r.reviewed_at, r.review_note, r.created,
                       a.alumni_id AS alumni_number, a.first_name, a.last_name,
                       u.username AS reviewer
                FROM alumni_correction_requests r
                JOIN alumni a ON a.id = r.alumni_id
                LEFT JOIN users u ON u.id = r.reviewed_by
                WHERE r.source = 'alumni'";
        $params = [];

        if (in_array($status, ['pending', 'approved', 'rejected'], true)) {
            $sql .= ' AND r.status = ?';
            $params[] = $status;
        }

        $sql .= ' ORDER BY (r.status = \'pending\') DESC, r.id DESC LIMIT 500';

        return $this->decode(db_run($this->db, $sql, $params)->fetchAll());
    }

    private function decode(array $rows): array
    {
        foreach ($rows as $row) {
            $row->changes = json_decode((string) $row->changes, true) ?: [];

            $row->change_list = [];
            foreach ($row->changes as $field => $c) {
                $row->change_list[] = [
                    'field'     => $field,
                    'label'     => self::LABELS[$field] ?? $field,
                    'sensitive' => in_array($field, self::SENSITIVE, true),
                    'old'       => $c['old_label'] ?? $c['old'] ?? null,
                    'new'       => $c['new_label'] ?? $c['new'] ?? null,
                ];
            }

            unset($row->changes);
        }

        return $rows;
    }

    public function countPending(): int
    {
        return (int) db_run(
            $this->db,
            "SELECT COUNT(*) FROM alumni_correction_requests WHERE status = 'pending' AND source = 'alumni'"
        )->fetchColumn();
    }

    public function approve(int $id, int $adminId, string $note): array
    {
        try {
            $this->db->beginTransaction();

            $req = db_run(
                $this->db,
                "SELECT * FROM alumni_correction_requests WHERE id = ? AND source = 'alumni' FOR UPDATE",
                [$id]
            )->fetch();

            if (!$req || $req->status !== 'pending') {
                $this->db->rollBack();
                return [false, 'This request is no longer pending.'];
            }

            $alumni = db_run($this->db, 'SELECT * FROM alumni WHERE id = ? FOR UPDATE', [$req->alumni_id])->fetch();

            if (!$alumni || !Alumni::isLocked($alumni)) {
                $this->db->rollBack();
                return [false, 'The alumni profile is not in a submitted state.'];
            }

            $stored = json_decode((string) $req->changes, true) ?: [];
            $merged = Alumni::snapshot($alumni);
            $apply  = [];

            foreach ($stored as $field => $change) {
                if (in_array($field, Alumni::PERSONAL_FIELDS, true)) {
                    $merged[$field] = $change['new'] ?? null;
                    $apply[$field]  = true;
                }
            }

            if (empty($apply)) {
                $this->db->rollBack();
                return [false, 'The request contains no valid changes.'];
            }

            [$errors, $row] = GtsGeneral::validate(new ArrayObject($merged));
            $errors = $this->relevantErrors($errors, array_intersect_key($stored, $apply));

            if ($errors) {
                $this->db->rollBack();
                return [false, 'Requested values are invalid: ' . reset($errors)];
            }

            $set    = [];
            $params = [];

            foreach (array_keys($apply) as $field) {
                $set[]    = "`$field` = ?";
                $params[] = $row[$field];
            }

            $now = date('Y-m-d H:i:s');
            $set[] = 'last_profile_update = ?';
            $params[] = $now;
            $params[] = $req->alumni_id;

            db_run($this->db, 'UPDATE alumni SET ' . implode(', ', $set) . ' WHERE id = ?', $params);

            db_run(
                $this->db,
                "UPDATE alumni_correction_requests
                 SET status = 'approved', reviewed_by = ?, reviewed_at = ?, review_note = ?
                 WHERE id = ? AND status = 'pending'",
                [$adminId, $now, $note !== '' ? $note : null, $id]
            );

            $this->db->commit();

            return [true, 'Correction approved and applied.'];
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            error_log($e);
            return [false, 'Unable to apply the correction.'];
        }
    }

    public function reject(int $id, int $adminId, string $note): bool
    {
        return db_run(
            $this->db,
            "UPDATE alumni_correction_requests
             SET status = 'rejected', reviewed_by = ?, reviewed_at = ?, review_note = ?
             WHERE id = ? AND status = 'pending' AND source = 'alumni'",
            [$adminId, date('Y-m-d H:i:s'), $note, $id]
        )->rowCount() > 0;
    }

    public function logAdminEdit(int $alumniId, int $adminId, array $changes): void
    {
        $now = date('Y-m-d H:i:s');

        db_run(
            $this->db,
            "INSERT INTO alumni_correction_requests
                (alumni_id, source, changes, reason, status, reviewed_by, reviewed_at, created, modified)
             VALUES (?, 'admin', ?, 'Direct edit by administrator', 'approved', ?, ?, ?, ?)",
            [$alumniId, json_encode($changes, JSON_UNESCAPED_UNICODE), $adminId, $now, $now, $now]
        );
    }
}
