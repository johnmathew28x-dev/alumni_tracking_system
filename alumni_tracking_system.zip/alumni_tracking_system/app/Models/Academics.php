<?php

namespace Models;

use Core\Model;

class Academics extends Model
{
    public function forAlumni($alumniId)
    {
        return db_run($this->db, 
            'SELECT aa.id, aa.alumni_id, aa.program_id, aa.major, aa.graduation_year, aa.batch, aa.student_id,
                    p.program_name, p.program_code
             FROM alumni_academic aa
             JOIN programs p ON p.id = aa.program_id
             WHERE aa.alumni_id = ?
             ORDER BY aa.graduation_year DESC',
            [$alumniId]
        )->fetchAll();
    }

    public function findByID($id)
    {
        return db_run($this->db, 
            'SELECT id, alumni_id, program_id, major, graduation_year, batch, student_id
             FROM alumni_academic WHERE id = ?',
            [$id]
        )->fetch() ?: null;
    }

    public function save($data)
    {
        $allowed = ['id', 'alumni_id', 'program_id', 'major', 'graduation_year', 'batch', 'student_id'];
        return db_save($this->db, 'alumni_academic', array_intersect_key($data, array_flip($allowed)));
    }

    public function delete($id): bool
    {
        return db_run($this->db, 'DELETE FROM alumni_academic WHERE id = ?', [$id])->rowCount() > 0;
    }
}