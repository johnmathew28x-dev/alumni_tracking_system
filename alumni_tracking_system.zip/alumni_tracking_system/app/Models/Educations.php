<?php

namespace Models;

use Core\Model;

class Educations extends Model
{
    public function forAlumni($alumniId)
    {
        return db_run($this->db, 
            'SELECT er.id, er.alumni_id, er.education_level_id, er.institution, er.degree, er.field_of_study,
                    er.start_year, er.end_year, er.status, el.level_name
             FROM education_records er
             JOIN education_levels el ON el.id = er.education_level_id
             WHERE er.alumni_id = ?
             ORDER BY er.start_year DESC',
            [$alumniId]
        )->fetchAll();
    }

    public function findByID($id)
    {
        return db_run($this->db, 
            'SELECT id, alumni_id, education_level_id, institution, degree, field_of_study, start_year, end_year, status
             FROM education_records WHERE id = ?',
            [$id]
        )->fetch() ?: null;
    }

    public function save($data)
    {
        $allowed = [
            'id', 'alumni_id', 'education_level_id', 'institution', 'degree', 'field_of_study',
            'start_year', 'end_year', 'status',
        ];

        return db_save($this->db, 'education_records', array_intersect_key($data, array_flip($allowed)));
    }

    public function delete($id): bool
    {
        return db_run($this->db, 'DELETE FROM education_records WHERE id = ?', [$id])->rowCount() > 0;
    }
}