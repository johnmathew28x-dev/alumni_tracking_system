<?php

namespace Models;

class AiPayload
{
    public const FLOOR = 5;

    private const SINGLE = [
        'employment_state'      => 'Employment status',
        'employment_type'       => 'Employment type (employed respondents)',
        'industry'              => 'Industry (employed respondents)',
        'place_of_work'         => 'Local or abroad (employed respondents)',
        'job_level'             => 'Present job level (employed respondents)',
        'salary'                => 'Present salary bracket (employed respondents)',
        'time_to_first_job'     => 'Time to first job',
        'search_method'         => 'How the first job was found',
        'curriculum_relevance'  => 'Curriculum relevant to first job',
    ];

    private const MULTI = [
        'competencies'   => 'Competencies used in first job (multiple answers allowed)',
        'course_reasons' => 'Reasons for taking the course (multiple answers allowed)',
    ];

    public static function threshold(int $configured): int
    {
        return max(self::FLOOR, $configured);
    }

    public static function build(array $summary, array $scope, int $k): array
    {
        $kpis = $summary['kpis'];
        $n    = (int) $kpis['respondents'];

        if ($n < $k) {
            return ['ok' => false, 'respondents' => $n];
        }

        $metrics = [
            'respondents' => $n,
            'participation' => self::participation($summary['participation'], $k),
            'employment_by_graduation_year' => self::byYear($summary['employment_by_year'], $k),
            'by_program' => self::byProgram($summary['by_program'], $k),
            'degree_related_employment' => self::partition([
                ['label' => 'Related to degree', 'total' => (int) $kpis['related']],
                ['label' => 'Not related to degree', 'total' => (int) $kpis['not_related']],
            ], $k),
            'professional_development' => self::development($summary['development'], $k),
        ];

        foreach (self::SINGLE as $key => $title) {
            $metrics[$key] = ['title' => $title] + self::partition(self::items($summary[$key] ?? []), $k);
        }

        foreach (self::MULTI as $key => $title) {
            $metrics[$key] = ['title' => $title] + self::multi(self::items($summary[$key] ?? []), $n, $k);
        }

        return [
            'ok'      => true,
            'payload' => [
                'institution' => 'Northeastern College, Education Department',
                'source'      => 'Submitted Graduate Tracer Surveys; statistics computed by the system, not by the model.',
                'scope'       => $scope,
                'privacy'     => 'Groups smaller than ' . $k . ' respondents are combined or withheld. Withheld values are unknown, not zero.',
                'definitions' => [
                    'employment_rate'    => 'employed respondents divided by respondents',
                    'degree_related'     => 'employed respondents whose present job is related to their degree',
                    'response_rate'      => 'respondents divided by alumni on record in the selected scope',
                    'percentages'        => 'calculated by the system from the counts shown',
                ],
                'limitations' => [
                    'Answers are self-reported by alumni who chose to respond.',
                    'Results describe respondents, not necessarily all graduates.',
                    'Counts are cross-sectional and do not show cause and effect.',
                ],
                'metrics'     => $metrics,
            ],
        ];
    }

    public static function cellsOk(array $cells, int $k): bool
    {
        foreach ($cells as $c) {
            if ($c < 0 || ($c > 0 && $c < $k)) {
                return false;
            }
        }

        return true;
    }

    public static function pct(int $part, int $whole): ?float
    {
        return $whole > 0 ? round($part * 100 / $whole, 1) : null;
    }

    public static function clean($label): string
    {
        $label = preg_replace('/[\x00-\x1F\x7F]/u', ' ', (string) $label);

        return function_exists('mb_substr') ? mb_substr(trim((string) $label), 0, 80) : substr(trim((string) $label), 0, 80);
    }

    private static function items(array $rows): array
    {
        $out = [];

        foreach ($rows as $r) {
            $out[] = ['label' => self::clean($r['label'] ?? ''), 'total' => (int) ($r['total'] ?? 0)];
        }

        return $out;
    }

    public static function partition(array $items, int $k): array
    {
        $n = array_sum(array_column($items, 'total'));

        if ($n < $k) {
            return ['status' => 'withheld: too few responses'];
        }

        $small = [];
        $big   = [];

        foreach ($items as $i => $row) {
            if ($row['total'] < $k) {
                $small[] = $i;
            } else {
                $big[$i] = $row['total'];
            }
        }

        $absorbed = $small;

        if ($small) {
            $other = 0;
            foreach ($small as $i) {
                $other += $items[$i]['total'];
            }

            asort($big);

            while ($other < $k && $big) {
                $i = array_key_first($big);
                $other += $items[$i]['total'];
                $absorbed[] = $i;
                unset($big[$i]);
            }

            if ($other < $k || !$big) {
                return ['status' => 'withheld: groups too small to report separately'];
            }
        }

        $rows = [];

        foreach ($items as $i => $row) {
            if (!in_array($i, $absorbed, true)) {
                $rows[] = ['label' => $row['label'], 'count' => $row['total'], 'percent' => self::pct($row['total'], $n)];
            }
        }

        if ($absorbed) {
            $other = 0;
            foreach ($absorbed as $i) {
                $other += $items[$i]['total'];
            }
            $rows[] = ['label' => 'Other (small groups combined)', 'count' => $other, 'percent' => self::pct($other, $n)];
        }

        return ['base' => $n, 'rows' => $rows];
    }

    private static function multi(array $items, int $base, int $k): array
    {
        $rows = [];

        foreach ($items as $row) {
            if ($row['total'] >= $k) {
                $rows[] = ['label' => $row['label'], 'count' => $row['total'], 'percent_of_respondents' => self::pct($row['total'], $base)];
            }
        }

        if (!$rows) {
            return ['status' => 'withheld: too few responses'];
        }

        return ['base' => $base, 'rows' => $rows, 'note' => 'Choices selected by fewer than ' . $k . ' respondents are omitted.'];
    }

    private static function mergeSmall(array $rows, string $totalKey, array $sumKeys, int $k, string $labelKey, string $otherLabel): ?array
    {
        $small = [];
        $big   = [];

        foreach ($rows as $i => $row) {
            if ($row[$totalKey] < $k) {
                $small[] = $i;
            } else {
                $big[$i] = $row[$totalKey];
            }
        }

        if (!$small) {
            return $rows;
        }

        $absorbed = $small;
        $other    = 0;

        foreach ($small as $i) {
            $other += $rows[$i][$totalKey];
        }

        asort($big);

        while ($other < $k && $big) {
            $i = array_key_first($big);
            $other += $rows[$i][$totalKey];
            $absorbed[] = $i;
            unset($big[$i]);
        }

        if ($other < $k || !$big) {
            return null;
        }

        $merged = [$labelKey => $otherLabel];
        foreach ($sumKeys as $key) {
            $merged[$key] = 0;
            foreach ($absorbed as $i) {
                $merged[$key] += (int) $rows[$i][$key];
            }
        }

        $kept = [];
        foreach ($rows as $i => $row) {
            if (!in_array($i, $absorbed, true)) {
                $kept[] = $row;
            }
        }
        $kept[] = $merged;

        return $kept;
    }

    private static function byYear(array $years, int $k): array
    {
        $rows = [];

        foreach ($years as $y) {
            $e = (int) $y['employed'];
            $s = (int) $y['not_employed'];
            $v = (int) $y['never_employed'];
            $rows[] = ['label' => self::clean($y['label']), 'total' => $e + $s + $v, 'employed' => $e, 'not_employed' => $s, 'never_employed' => $v];
        }

        $rows = self::mergeSmall($rows, 'total', ['total', 'employed', 'not_employed', 'never_employed'], $k, 'label', 'Other years (small groups combined)');

        if ($rows === null) {
            return ['status' => 'withheld: groups too small to report separately'];
        }

        $out = [];

        foreach ($rows as $r) {
            $line = ['graduation_year' => $r['label'], 'respondents' => $r['total']];

            if (self::cellsOk([$r['employed'], $r['not_employed'], $r['never_employed']], $k)) {
                $line['employed'] = $r['employed'];
                $line['not_currently_employed'] = $r['not_employed'];
                $line['never_employed'] = $r['never_employed'];
                $line['employment_rate_percent'] = self::pct($r['employed'], $r['total']);
            } else {
                $line['employment_detail'] = 'withheld: small group';
            }

            $out[] = $line;
        }

        return ['rows' => $out];
    }

    private static function byProgram(array $programs, int $k): array
    {
        $rows = [];

        foreach ($programs as $p) {
            $rows[] = [
                'label'       => self::clean($p['code'] . ' - ' . $p['name']),
                'total'       => (int) $p['respondents'],
                'employed'    => (int) $p['employed'],
                'related'     => (int) $p['related'],
            ];
        }

        $rows = self::mergeSmall($rows, 'total', ['total', 'employed', 'related'], $k, 'label', 'Other programs (small groups combined)');

        if ($rows === null) {
            return ['status' => 'withheld: groups too small to report separately'];
        }

        $out = [];

        foreach ($rows as $r) {
            $line = ['program' => $r['label'], 'respondents' => $r['total']];

            if (self::cellsOk([$r['employed'], $r['total'] - $r['employed']], $k)) {
                $line['employed'] = $r['employed'];
                $line['employment_rate_percent'] = self::pct($r['employed'], $r['total']);

                if (self::cellsOk([$r['related'], $r['employed'] - $r['related']], $k)) {
                    $line['degree_related_of_employed'] = $r['related'];
                    $line['degree_related_percent'] = self::pct($r['related'], $r['employed']);
                } else {
                    $line['degree_related'] = 'withheld: small group';
                }
            } else {
                $line['employment_detail'] = 'withheld: small group';
            }

            $out[] = $line;
        }

        return ['rows' => $out];
    }

    private static function participation(array $p, int $k): array
    {
        $out = [
            'alumni_on_record' => (int) $p['total_alumni'],
            'responded'        => (int) $p['responded'],
            'response_rate_percent' => $p['rate'],
        ];

        $rows = [];
        foreach ($p['by_year'] as $y) {
            $rows[] = ['label' => self::clean($y['label']), 'alumni' => (int) $y['alumni'], 'responded' => (int) $y['responded']];
        }

        $rows = self::mergeSmall($rows, 'alumni', ['alumni', 'responded'], $k, 'label', 'Other years (small groups combined)');

        if ($rows === null) {
            $out['by_graduation_year'] = 'withheld: groups too small to report separately';
            return $out;
        }

        foreach ($rows as $r) {
            $line = ['graduation_year' => $r['label'], 'alumni_on_record' => $r['alumni']];

            if (self::cellsOk([$r['responded'], $r['alumni'] - $r['responded']], $k)) {
                $line['responded'] = $r['responded'];
                $line['response_rate_percent'] = self::pct($r['responded'], $r['alumni']);
            } else {
                $line['response_detail'] = 'withheld: small group';
            }

            $out['by_graduation_year'][] = $line;
        }

        return $out;
    }

    private static function development(array $d, int $k): array
    {
        $n   = (int) $d['respondents'];
        $out = ['respondents' => $n];

        $fields = [
            'with_professional_examination' => 'with_exam',
            'passed_professional_examination' => 'exam_passers',
            'with_training' => 'with_training',
            'with_advanced_study' => 'with_advanced_study',
        ];

        foreach ($fields as $label => $key) {
            $count = (int) $d[$key];

            if (self::cellsOk([$count, $n - $count], $k)) {
                $out[$label] = ['count' => $count, 'percent_of_respondents' => self::pct($count, $n)];
            } else {
                $out[$label] = 'withheld: small group';
            }
        }

        return $out;
    }
}
