<?php

namespace Models;

use Core\Model;

class Employments extends Model
{
    public function forAlumni($alumniId)
    {
        return db_run($this->db, 
            'SELECT er.id, er.alumni_id, er.employment_status_id, er.employer, er.job_position, er.industry,
                    er.employment_location, er.employment_type, er.date_hired, er.date_ended, er.is_current,
                    er.is_first_job, er.employment_type_id, er.industry_id, er.place_of_work, er.job_level_id,
                    er.salary_range_id, er.related_to_degree,
                    es.status_name, et.name AS tenure_name, ind.name AS industry_name,
                    jl.name AS job_level_name, sr.name AS salary_name
             FROM employment_records er
             JOIN employment_statuses es ON es.id = er.employment_status_id
             LEFT JOIN employment_types et ON et.id = er.employment_type_id
             LEFT JOIN industries ind ON ind.id = er.industry_id
             LEFT JOIN job_levels jl ON jl.id = er.job_level_id
             LEFT JOIN salary_ranges sr ON sr.id = er.salary_range_id
             WHERE er.alumni_id = ?
             ORDER BY er.is_current DESC, er.date_hired DESC',
            [$alumniId]
        )->fetchAll();
    }

    public function findByID($id)
    {
        return db_run($this->db, 
            'SELECT id, alumni_id, employment_status_id, employer, job_position, industry, employment_location,
                    employment_type, date_hired, date_ended, is_current,
                    is_first_job, employment_type_id, industry_id, place_of_work, job_level_id,
                    salary_range_id, related_to_degree
             FROM employment_records WHERE id = ?',
            [$id]
        )->fetch() ?: null;
    }

    public function save($data)
    {
        $allowed = [
            'id', 'alumni_id', 'employment_status_id', 'employer', 'job_position', 'industry',
            'employment_location', 'employment_type', 'date_hired', 'date_ended', 'is_current',
            'is_first_job', 'employment_type_id', 'industry_id', 'place_of_work', 'job_level_id',
            'salary_range_id', 'related_to_degree',
        ];

        return db_save($this->db, 'employment_records', array_intersect_key($data, array_flip($allowed)));
    }

    public function delete($id): bool
    {
        return db_run($this->db, 'DELETE FROM employment_records WHERE id = ?', [$id])->rowCount() > 0;
    }
}