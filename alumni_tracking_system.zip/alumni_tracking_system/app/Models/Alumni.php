<?php

namespace Models;

use Core\Model;

class Alumni extends Model
{
    public const PERSONAL_FIELDS = [
        'first_name', 'middle_name', 'last_name', 'suffix', 'date_of_birth', 'gender',
        'contact_number', 'address', 'civil_status_id', 'region_id', 'province',
        'city_municipality', 'residence_type_id',
    ];

    private const ID_FIELDS = ['civil_status_id', 'region_id', 'residence_type_id'];

    private const LIST_SQL =
        "SELECT a.id, a.alumni_id, a.first_name, a.middle_name, a.last_name, a.email,
                a.contact_number, a.verification_status, a.submission_status, a.profile_status, a.gender,
                a.province, a.city_municipality, u.profile_picture,
                p.id AS program_id, p.program_code, p.program_name,
                aa.major, aa.graduation_year, aa.batch, aa.student_id
         FROM alumni a
         LEFT JOIN users u ON u.id = a.user_id
         LEFT JOIN alumni_academic aa
                ON aa.id = (SELECT MAX(x.id) FROM alumni_academic x WHERE x.alumni_id = a.id)
         LEFT JOIN programs p ON p.id = aa.program_id";

    public function find(array $filters = [])
    {
        $sql = self::LIST_SQL . ' WHERE 1 = 1';
        $params = [];

        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            $kw = '%' . addcslashes($keyword, '%_\\') . '%';
            $sql .= ' AND (a.first_name LIKE ? OR a.last_name LIKE ? OR a.alumni_id LIKE ? OR a.email LIKE ?
                           OR CONCAT(a.first_name, \' \', a.last_name) LIKE ?)';
            array_push($params, $kw, $kw, $kw, $kw, $kw);
        }

        $id = fn($v) => (is_scalar($v) && ctype_digit((string) $v) && (int) $v > 0) ? (int) $v : null;

        if ($v = $id($filters['program_id'] ?? null)) {
            $sql .= ' AND p.id = ?';
            $params[] = $v;
        }

        if ($v = $id($filters['graduation_year'] ?? null)) {
            $sql .= ' AND aa.graduation_year = ?';
            $params[] = $v;
        }

        if (in_array($filters['verification_status'] ?? '', ['verified', 'pending', 'rejected'], true)) {
            $sql .= ' AND a.verification_status = ?';
            $params[] = $filters['verification_status'];
        }

        if (in_array($filters['profile_status'] ?? '', ['active', 'inactive', 'archived'], true)) {
            $sql .= ' AND a.profile_status = ?';
            $params[] = $filters['profile_status'];
        }

        if (in_array($filters['gender'] ?? '', ['Male', 'Female', 'Other'], true)) {
            $sql .= ' AND a.gender = ?';
            $params[] = $filters['gender'];
        }

        if (trim((string) ($filters['province'] ?? '')) !== '') {
            $sql .= ' AND a.province = ?';
            $params[] = trim($filters['province']);
        }

        if ($v = $id($filters['employment_status_id'] ?? null)) {
            $sql .= ' AND (SELECT er.employment_status_id FROM employment_records er WHERE er.alumni_id = a.id
                           ORDER BY er.is_current DESC, er.id DESC LIMIT 1) = ?';
            $params[] = $v;
        }

        if ($v = $id($filters['licensure_status_id'] ?? null)) {
            $sql .= ' AND (SELECT lr.status_id FROM licensure_records lr WHERE lr.alumni_id = a.id
                           ORDER BY lr.examination_year DESC, lr.id DESC LIMIT 1) = ?';
            $params[] = $v;
        }

        $sql .= ' ORDER BY a.last_name, a.first_name';

        return db_run($this->db, $sql, $params)->fetchAll();
    }

    public function findByID($id)
    {
        return db_run($this->db,
            self::LIST_SQL . ' WHERE a.id = ?',
            [$id]
        )->fetch() ?: null;
    }

    public function details($id)
    {
        return db_run($this->db,
            'SELECT a.*, u.username, u.status AS account_status, u.profile_picture
             FROM alumni a
             JOIN users u ON u.id = a.user_id
             WHERE a.id = ?',
            [$id]
        )->fetch() ?: null;
    }

    public function findByUserID($userId)
    {
        return db_run($this->db,
            'SELECT * FROM alumni WHERE user_id = ?',
            [$userId]
        )->fetch() ?: null;
    }

    public function save($data)
    {
        $allowed = [
            'id', 'user_id', 'alumni_id', 'first_name', 'middle_name', 'last_name', 'suffix',
            'date_of_birth', 'gender', 'contact_number', 'email', 'address', 'verification_status',
            'civil_status_id', 'region_id', 'province', 'city_municipality', 'residence_type_id',
            'profile_status', 'last_profile_update',
        ];

        return db_save($this->db, 'alumni', array_intersect_key($data, array_flip($allowed)));
    }

    public static function isLocked($alumni): bool
    {
        return (is_object($alumni) ? ($alumni->submission_status ?? 'draft') : ($alumni['submission_status'] ?? 'draft')) === 'submitted';
    }

    public static function normalize(string $field, $value)
    {
        if (in_array($field, self::ID_FIELDS, true)) {
            return ($value === null || $value === '') ? null : (int) $value;
        }

        return ($value === null || trim((string) $value) === '') ? null : (string) $value;
    }

    public static function snapshot($alumni): array
    {
        $out = [];

        foreach (self::PERSONAL_FIELDS as $field) {
            $value = is_object($alumni) ? ($alumni->$field ?? null) : ($alumni[$field] ?? null);
            $out[$field] = self::normalize($field, $value);
        }

        return $out;
    }

    public static function diff(array $old, array $new): array
    {
        $changes = [];

        foreach (self::PERSONAL_FIELDS as $field) {
            if (!array_key_exists($field, $new)) {
                continue;
            }

            $before = self::normalize($field, $old[$field] ?? null);
            $after  = self::normalize($field, $new[$field]);

            if ($before !== $after) {
                $changes[$field] = ['old' => $before, 'new' => $after];
            }
        }

        return $changes;
    }

    private function writePersonal(int $id, array $row, array $extra = []): void
    {
        $data = [];

        foreach (self::PERSONAL_FIELDS as $field) {
            if (array_key_exists($field, $row)) {
                $data[$field] = $row[$field];
            }
        }

        $data = $extra + $data + ['modified' => date('Y-m-d H:i:s')];
        $set  = implode(', ', array_map(fn($c) => "`$c` = ?", array_keys($data)));

        db_run($this->db, "UPDATE alumni SET $set WHERE id = ?", [...array_values($data), $id]);
    }

    public function saveDraft(int $id, array $row): bool
    {
        return $this->guardedWrite($id, $row, false);
    }

    public function submitInitial(int $id, array $row): bool
    {
        return $this->guardedWrite($id, $row, true);
    }

    private function guardedWrite(int $id, array $row, bool $lock): bool
    {
        try {
            $this->db->beginTransaction();

            $state = db_run($this->db, 'SELECT submission_status FROM alumni WHERE id = ? FOR UPDATE', [$id])->fetchColumn();

            if ($state !== 'draft') {
                $this->db->rollBack();
                return false;
            }

            $now   = date('Y-m-d H:i:s');
            $extra = ['last_profile_update' => $now];

            if ($lock) {
                $extra += ['submission_status' => 'submitted', 'submitted_at' => $now];
            }

            $this->writePersonal($id, $row, $extra);
            $this->db->commit();

            return true;
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            error_log($e);
            return false;
        }
    }

    public function setVerification($id, $status)
    {
        return db_run($this->db,
            'UPDATE alumni SET verification_status = ?, modified = ? WHERE id = ?',
            [$status, date('Y-m-d H:i:s'), $id]
        )->rowCount() > 0;
    }

    public static function numberFor($userId): string
    {
        return 'NEC-' . date('Y') . '-' . str_pad((string) $userId, 5, '0', STR_PAD_LEFT);
    }

    public function countTotal(): int
    {
        return (int) db_run($this->db, 'SELECT COUNT(*) FROM alumni')->fetchColumn();
    }

    public function countByVerification($status): int
    {
        return (int) db_run($this->db,
            'SELECT COUNT(*) FROM alumni WHERE verification_status = ?',
            [$status]
        )->fetchColumn();
    }

    public function countEmployed(): int
    {
        return (int) db_run($this->db,
            "SELECT COUNT(DISTINCT er.alumni_id)
             FROM employment_records er
             JOIN employment_statuses es ON es.id = er.employment_status_id
             WHERE er.is_current = 1
               AND (es.status_name LIKE 'Employed%' OR es.status_name = 'Self-Employed')"
        )->fetchColumn();
    }

    public function countUnemployed(): int
    {
        return (int) db_run($this->db,
            "SELECT COUNT(DISTINCT er.alumni_id)
             FROM employment_records er
             JOIN employment_statuses es ON es.id = er.employment_status_id
             WHERE es.status_name = 'Unemployed'"
        )->fetchColumn();
    }

    public function countLetPassers(): int
    {
        return (int) db_run($this->db,
            "SELECT COUNT(DISTINCT lr.alumni_id)
             FROM licensure_records lr
             JOIN licensure_statuses ls ON ls.id = lr.status_id
             WHERE ls.status_name = 'Passed'"
        )->fetchColumn();
    }
}