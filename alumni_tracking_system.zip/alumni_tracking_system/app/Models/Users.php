<?php

namespace Models;

use Core\Model;

class Users extends Model
{
    public const ADMIN   = 'Administrator';
    public const ALUMNI  = 'Alumni';
    public const FACULTY = 'Faculty';
    public const QA      = 'Quality Assurance';

    public const ROLES = [self::ADMIN, self::ALUMNI, self::FACULTY, self::QA];

    public function find(): array
    {
        return db_run($this->db, 
            'SELECT id, username, email, role, status, profile_picture, created
             FROM users
             ORDER BY username'
        )->fetchAll();
    }

    public function findByID(int $id): ?object
    {
        return db_run($this->db, 
            'SELECT id, username, email, role, status, profile_picture, created
             FROM users
             WHERE id = ?',
            [$id]
        )->fetch() ?: null;
    }

    public function findByLogin(string $identifier): ?object
    {
        return db_run($this->db, 
            'SELECT id, username, email, password, role, status
             FROM users
             WHERE username = ? OR email = ?
             LIMIT 1',
            [$identifier, $identifier]
        )->fetch() ?: null;
    }

    public function findByUsername(string $username): ?object
    {
        return db_run($this->db, 
            'SELECT id, username, email, password, role, status
             FROM users
             WHERE username = ?',
            [$username]
        )->fetch() ?: null;
    }

    public function count(): int
    {
        return (int) db_run($this->db, 'SELECT COUNT(*) FROM users')->fetchColumn();
    }

    public function usernameExists(string $username, ?int $exceptId = null): bool
    {
        $stmt = db_run($this->db, 
            'SELECT COUNT(*) FROM users WHERE username = ? AND id <> ?',
            [$username, (int) $exceptId]
        );

        return (int) $stmt->fetchColumn() > 0;
    }

    public function emailExists(string $email, ?int $exceptId = null): bool
    {
        $stmt = db_run($this->db, 
            'SELECT COUNT(*) FROM users WHERE email = ? AND id <> ?',
            [$email, (int) $exceptId]
        );

        return (int) $stmt->fetchColumn() > 0;
    }

    public function save(array $data)
    {
        $row = [
            'id'       => $data['id'] ?? null,
            'username' => $data['username'],
            'email'    => $data['email'],
            'role'     => $data['role'],
        ];

        if (!empty($data['status'])) {
            $row['status'] = $data['status'];
        }

        if (!empty($data['password'])) {
            $row['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        }

        return db_save($this->db, 'users', $row);
    }

    public function pictureFor(int $id): ?string
    {
        $value = db_run($this->db, 'SELECT profile_picture FROM users WHERE id = ?', [$id])->fetchColumn();

        return $value ?: null;
    }

    public function setProfilePicture(int $id, ?string $file): bool
    {
        return db_run($this->db, 
            'UPDATE users SET profile_picture = ?, modified = ? WHERE id = ?',
            [$file, date('Y-m-d H:i:s'), $id]
        )->rowCount() > 0;
    }

    public function updateAccount(int $id, string $username, string $email): bool
    {
        return db_run($this->db, 
            'UPDATE users SET username = ?, email = ?, modified = ? WHERE id = ?',
            [$username, $email, date('Y-m-d H:i:s'), $id]
        )->rowCount() > 0;
    }

    public function setPassword(int $id, string $password): bool
    {
        return db_run($this->db, 
            'UPDATE users SET password = ?, modified = ? WHERE id = ?',
            [password_hash($password, PASSWORD_DEFAULT), date('Y-m-d H:i:s'), $id]
        )->rowCount() > 0;
    }

    public function setStatus(int $id, string $status): bool
    {
        return db_run($this->db, 
            'UPDATE users SET status = ?, modified = ? WHERE id = ?',
            [$status, date('Y-m-d H:i:s'), $id]
        )->rowCount() > 0;
    }

    public function delete(int $id): bool
    {
        return db_run($this->db, 'DELETE FROM users WHERE id = ?', [$id])->rowCount() > 0;
    }

    public function createUser(array $user, ?array $alumni = null, ?array $academic = null): bool
    {
        try {
            $this->db->beginTransaction();

            $this->save($user);
            $userId = (int) $this->db->lastInsertId();

            if ($alumni !== null) {
                db_save($this->db, 'alumni', $alumni + [
                    'user_id'   => $userId,
                    'alumni_id' => Alumni::numberFor($userId),
                ]);
                $alumniId = (int) $this->db->lastInsertId();

                if ($academic !== null) {
                    db_save($this->db, 'alumni_academic', $academic + ['alumni_id' => $alumniId]);
                }
            }

            $this->db->commit();
            return true;
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            error_log($e);
            return false;
        }
    }
}
