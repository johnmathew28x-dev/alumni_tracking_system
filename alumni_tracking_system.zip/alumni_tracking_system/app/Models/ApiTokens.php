<?php

namespace Models;

use Core\Model;

class ApiTokens extends Model
{
    private const TTL_DAYS       = 30;
    private const MAX_FAILURES   = 5;
    private const WINDOW_SECONDS = 60;

    public function issue(int $userId, string $device, ?int $days = null): string
    {
        $raw = bin2hex(random_bytes(32));
        $now = date('Y-m-d H:i:s');

        db_run($this->db,
            'INSERT INTO api_tokens (user_id, token_hash, device_name, last_used_at, expires_at, created)
             VALUES (?, ?, ?, ?, ?, ?)',
            [
                $userId,
                hash('sha256', $raw),
                substr($device, 0, 100),
                $now,
                date('Y-m-d H:i:s', strtotime('+' . ($days ?? self::TTL_DAYS) . ' days')),
                $now,
            ]
        );

        return $raw;
    }

    public function resolve(string $raw): ?array
    {
        $row = db_run($this->db,
            "SELECT t.id AS token_id, u.id AS user_id, u.username, u.role
             FROM api_tokens t
             JOIN users u ON u.id = t.user_id
             WHERE t.token_hash = ? AND t.expires_at > ? AND u.status = 'active'",
            [hash('sha256', $raw), date('Y-m-d H:i:s')]
        )->fetch(\PDO::FETCH_ASSOC);

        if (!$row) {
            return null;
        }

        db_run($this->db,
            'UPDATE api_tokens SET last_used_at = ? WHERE id = ? AND (last_used_at IS NULL OR last_used_at < ?)',
            [date('Y-m-d H:i:s'), $row['token_id'], date('Y-m-d H:i:s', time() - 300)]
        );

        return $row;
    }

    public function revoke(int $tokenId): bool
    {
        return db_run($this->db, 'DELETE FROM api_tokens WHERE id = ?', [$tokenId])->rowCount() > 0;
    }

    public function revokeAllForUser(int $userId, ?int $exceptId = null): int
    {
        return db_run($this->db,
            'DELETE FROM api_tokens WHERE user_id = ? AND id <> ?',
            [$userId, (int) $exceptId]
        )->rowCount();
    }

    public function tooManyFailures(string $identifier, string $ip): bool
    {
        $count = (int) db_run($this->db,
            'SELECT COUNT(*) FROM api_login_attempts
             WHERE identifier = ? AND ip_address = ? AND attempted_at > ?',
            [$this->key($identifier), $ip, date('Y-m-d H:i:s', time() - self::WINDOW_SECONDS)]
        )->fetchColumn();

        return $count >= self::MAX_FAILURES;
    }

    public function tooManyAttempts(string $identifier, string $ip, int $max, int $windowSeconds): bool
    {
        $count = (int) db_run($this->db,
            'SELECT COUNT(*) FROM api_login_attempts
             WHERE identifier = ? AND ip_address = ? AND attempted_at > ?',
            [$this->key($identifier), $ip, date('Y-m-d H:i:s', time() - $windowSeconds)]
        )->fetchColumn();

        return $count >= $max;
    }

    public function recordFailure(string $identifier, string $ip): void
    {
        db_run($this->db,
            'INSERT INTO api_login_attempts (identifier, ip_address, attempted_at) VALUES (?, ?, ?)',
            [$this->key($identifier), $ip, date('Y-m-d H:i:s')]
        );

        db_run($this->db,
            'DELETE FROM api_login_attempts WHERE attempted_at < ?',
            [date('Y-m-d H:i:s', time() - 86400)]
        );
    }

    public function clearFailures(string $identifier, string $ip): void
    {
        db_run($this->db,
            'DELETE FROM api_login_attempts WHERE identifier = ? AND ip_address = ?',
            [$this->key($identifier), $ip]
        );
    }

    private function key(string $identifier): string
    {
        return substr(strtolower($identifier), 0, 150);
    }
}
