<?php

namespace Models;

use Core\Model;

class Lookups extends Model
{
    public const REF_TABLES = [
        'civil_statuses', 
        'regions', 
        'residence_types', 
        'employment_types', 
        'industries', 
        'job_levels',
        'salary_ranges', 
        'job_search_methods', 
        'duration_ranges', 
        'course_reasons', 
        'employment_reasons',
        'unemployment_reasons', 
        'competencies',
    ];

    public function programs(): array
    {
        return db_run($this->db, 
            'SELECT p.id, 
                    p.program_code, 
                    p.program_name, 
                    p.department_id, 
                    d.department_name
             FROM programs p
             JOIN departments d ON d.id = p.department_id
             ORDER BY p.program_name'
        )->fetchAll();
    }

    public function departments(): array
    {
        return db_run($this->db, 
            'SELECT id, department_name 
             FROM departments 
             ORDER BY department_name'
        )->fetchAll();
    }

    public function employmentStatuses(): array
    {
        return db_run($this->db, 
            'SELECT id, status_name 
             FROM employment_statuses 
             ORDER BY status_name'
        )->fetchAll();
    }

    public function licenseTypes(): array
    {
        return db_run($this->db, 
            'SELECT id, license_name 
             FROM license_types 
             ORDER BY license_name'
        )->fetchAll();
    }

    public function licensureStatuses(): array
    {
        return db_run($this->db, 
            'SELECT id, status_name 
             FROM licensure_statuses 
             ORDER BY id'
        )->fetchAll();
    }

    public function educationLevels(): array
    {
        return db_run($this->db, 
            'SELECT id, level_name 
             FROM education_levels 
             ORDER BY level_name'
        )->fetchAll();
    }

    public function ref(string $table, bool$onlyActive = true): array
    {
        if (!in_array($table, self::REF_TABLES, true)) {
            return [];
        }

        $where =$onlyActive ? 'WHERE is_active = 1' : '';

        return db_run($this->db, 
            "SELECT * 
             FROM `$table` $where 
             ORDER BY sort_order, name"
        )->fetchAll();
    }

    public function employmentReasons(string $type): array
    {
        return db_run($this->db, 
            'SELECT * 
             FROM employment_reasons 
             WHERE reason_type = ? AND is_active = 1 
             ORDER BY sort_order, name',
            [$type]
        )->fetchAll();
    }

    public function graduationYears(): array
    {
        return db_run($this->db, 
            'SELECT DISTINCT graduation_year 
             FROM alumni_academic 
             ORDER BY graduation_year DESC'
        )->fetchAll();
    }

    public function provinces(): array
    {
        return db_run($this->db, 
            "SELECT DISTINCT province 
             FROM alumni 
             WHERE province IS NOT NULL AND province <> '' 
             ORDER BY province"
        )->fetchAll();
    }

    public function events(): array
    {
        return db_run($this->db, 
            'SELECT id, title, event_date, status 
             FROM events 
             ORDER BY event_date DESC'
        )->fetchAll();
    }

    public function academicYears(): array
    {
        return db_run($this->db, 
            'SELECT DISTINCT academic_year 
             FROM alumni_academic 
             WHERE academic_year IS NOT NULL 
             ORDER BY academic_year DESC'
        )->fetchAll();
    }

    public function gtsStudies(): array
    {
        return db_run($this->db, 
            "SELECT id, title, survey_year, status 
             FROM tracer_studies 
             WHERE survey_type = 'gts' 
             ORDER BY survey_year DESC, id DESC"
        )->fetchAll();
    }

    public function validIds(string $table, ?string $reasonType = null): array
    {
        if (!in_array($table, self::REF_TABLES, true)) {
            return [];
        }

        if ($reasonType !== null &&$table === 'employment_reasons') {
            $rows =db_run($this->db, 
                'SELECT id 
                 FROM employment_reasons 
                 WHERE reason_type = ? AND is_active = 1', 
                [$reasonType]
            )->fetchAll();
        } else {
            $rows =db_run($this->db, 
                "SELECT id 
                 FROM `$table` 
                 WHERE is_active = 1"
            )->fetchAll();
        }

        return array_map(fn($r) => (int) $r->id,$rows);
    }
}