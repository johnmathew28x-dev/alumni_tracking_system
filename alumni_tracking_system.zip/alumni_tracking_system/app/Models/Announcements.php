<?php

namespace Models;

use Core\Model;

class Announcements extends Model
{
    public function find()
    {
        return db_run($this->db, 
            'SELECT a.id, a.title, a.content, a.status, a.published_at, a.created, u.username AS created_by_name
             FROM announcements a
             JOIN users u ON u.id = a.created_by
             ORDER BY a.created DESC'
        )->fetchAll();
    }

    public function published()
    {
        return db_run($this->db, 
            "SELECT id, title, content, published_at
             FROM announcements
             WHERE status = 'published'
             ORDER BY published_at DESC"
        )->fetchAll();
    }

    public function findByID($id)
    {
        return db_run($this->db, 
            'SELECT id, title, content, status, published_at FROM announcements WHERE id = ?',
            [$id]
        )->fetch() ?: null;
    }

    public function save($data)
    {
        $allowed = ['id', 'title', 'content', 'created_by', 'status', 'published_at'];
        return db_save($this->db, 'announcements', array_intersect_key($data, array_flip($allowed)));
    }

    public function setPublished($id, bool $published)
    {
        return db_run($this->db, 
            'UPDATE announcements SET status = ?, published_at = ?, modified = ? WHERE id = ?',
            [
                $published ? 'published' : 'draft',
                $published ? date('Y-m-d H:i:s') : null,
                date('Y-m-d H:i:s'),
                $id,
            ]
        )->rowCount() > 0;
    }

    public function delete($id): bool
    {
        return db_run($this->db, 'DELETE FROM announcements WHERE id = ?', [$id])->rowCount() > 0;
    }
}