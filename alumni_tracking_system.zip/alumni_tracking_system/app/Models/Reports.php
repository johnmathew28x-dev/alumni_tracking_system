<?php

namespace Models;

use Core\Model;

class Reports extends Model
{
    public const TYPES = [
        'alumni' => [
            'title'   => 'Alumni Report',
            'roles'   => ['Administrator', 'Faculty', 'Quality Assurance'],
            'method'  => 'alumni',
            'filters' => [
                'keyword', 'program_id', 'graduation_year', 'employment_status_id', 'licensure_status_id',
                'profile_status', 'verification_status', 'gender', 'province',
            ],
            'columns' => [
                'alumni_id' => 'Alumni ID', 'name' => 'Name', 'gender' => 'Gender',
                'contact_number' => 'Contact No.', 'email' => 'Email', 'address' => 'Address',
                'location' => 'Location',
                'program_name' => 'Program', 'department_name' => 'Department',
                'graduation_year' => 'Grad. Year', 'batch' => 'Batch', 'honors_awards' => 'Honors / Awards',
                'employment_status' => 'Employment Status', 'employer' => 'Employer',
                'job_position' => 'Position', 'industry' => 'Industry', 'employment_type' => 'Employment Type',
                'license_name' => 'License', 'licensure_status' => 'License Status', 'examination_year' => 'Exam Year',
                'profile_status' => 'Alumni Status', 'verification_status' => 'Verification',
            ],
            'licensure_roles'   => ['Administrator', 'Quality Assurance'],
            'licensure_columns' => ['license_name', 'licensure_status', 'examination_year'],
            'licensure_filters' => ['licensure_status_id'],
            'hidden'  => ['contact_number', 'address', 'department_name', 'batch', 'honors_awards', 'industry', 'employment_type', 'verification_status'],
        ],
        'tracer' => [
            'title'   => 'Tracer Study Report',
            'roles'   => ['Administrator', 'Faculty', 'Quality Assurance'],
            'method'  => 'tracer',
            'filters' => [],
            'columns' => [
                'title' => 'Study', 'status' => 'Status', 'start_date' => 'Start', 'end_date' => 'End',
                'respondents' => 'Respondents', 'created_by_name' => 'Created By',
            ],
        ],
        'program' => [
            'title'   => 'Program Report',
            'roles'   => ['Administrator', 'Quality Assurance'],
            'method'  => 'program',
            'filters' => [],
            'columns' => [
                'program_code' => 'Code', 'program_name' => 'Program', 'total_graduates' => 'Graduates',
                'employed_count' => 'Employed', 'let_passers' => 'LET Passers',
            ],
        ],
        'engagement' => [
            'title'   => 'Engagement Report',
            'roles'   => ['Administrator'],
            'method'  => 'engagement',
            'filters' => [],
            'columns' => [
                'category' => 'Category', 'item' => 'Item', 'metric' => 'Metric', 'value' => 'Value',
            ],
        ],
        'engagementAlumni' => [
            'title'   => 'Active Alumni Attendance',
            'page'    => false,
            'roles'   => ['Administrator'],
            'method'  => 'activeAttendance',
            'filters' => ['program_id', 'graduation_year', 'engagement_level'],
        ],
        'engagementEvents' => [
            'title'   => 'Event Attendance',
            'page'    => false,
            'roles'   => ['Administrator'],
            'method'  => 'eventAttendance',
            'filters' => ['event_status'],
        ],
        'engagementRecords' => [
            'title'   => 'Attendance Records',
            'page'    => false,
            'roles'   => ['Administrator'],
            'method'  => 'attendanceRecords',
            'filters' => ['event_id', 'program_id', 'graduation_year', 'attendance_status'],
        ],
    ];

    public const ENGAGEMENT_LEVELS = [
        'highly'   => 'Highly Engaged (75% and above)',
        'moderate' => 'Moderately Engaged (40% - 74%)',
        'low'      => 'Low Engagement (below 40%)',
        'none'     => 'Not Engaged (no attendance)',
    ];

    private const JOIN_ACADEMIC =
        "LEFT JOIN alumni_academic aa
                ON aa.id = (SELECT MAX(x.id) FROM alumni_academic x WHERE x.alumni_id = a.id)
         LEFT JOIN programs p ON p.id = aa.program_id
         LEFT JOIN departments d ON d.id = p.department_id";

    private const JOIN_EMPLOYMENT =
        "LEFT JOIN employment_records er
                ON er.id = (SELECT x.id FROM employment_records x WHERE x.alumni_id = a.id
                            ORDER BY x.is_current DESC, x.id DESC LIMIT 1)
         LEFT JOIN employment_statuses es ON es.id = er.employment_status_id";

    private const JOIN_LICENSURE =
        "LEFT JOIN licensure_records lr
                ON lr.id = (SELECT x.id FROM licensure_records x WHERE x.alumni_id = a.id
                            ORDER BY x.examination_year DESC, x.id DESC LIMIT 1)
         LEFT JOIN license_types lt ON lt.id = lr.license_type_id
         LEFT JOIN licensure_statuses ls ON ls.id = lr.status_id";

    public static function configFor(string $type, ?string $role): ?array
    {
        $config = self::TYPES[$type] ?? null;

        if ($config && !empty($config['licensure_roles']) && !in_array($role, $config['licensure_roles'], true)) {
            foreach ($config['licensure_columns'] as $c) {
                unset($config['columns'][$c]);
            }
            $config['filters'] = array_values(array_diff($config['filters'], $config['licensure_filters']));
        }

        return $config;
    }

    public static function pageTypes(): array
    {
        return array_filter(self::TYPES, fn($c) => ($c['page'] ?? true) !== false);
    }

    public static function levelFor(?float $rate, int $attended): string
    {
        if ($rate === null) {
            return 'none';
        }
        if ($rate >= 75) {
            return 'highly';
        }
        if ($rate >= 40) {
            return 'moderate';
        }
        return $attended > 0 ? 'low' : 'none';
    }

    public function alumni(array $filters = []): array
    {
        $f = [
            'program_id'           => $this->intOrBlank($filters['program_id'] ?? ''),
            'graduation_year'      => $this->intOrBlank($filters['graduation_year'] ?? ''),
            'employment_status_id' => $this->intOrBlank($filters['employment_status_id'] ?? ''),
            'licensure_status_id'  => $this->intOrBlank($filters['licensure_status_id'] ?? ''),
            'profile_status'       => $this->oneOf($filters['profile_status'] ?? '', ['active', 'inactive', 'archived']),
            'verification_status'  => $this->oneOf($filters['verification_status'] ?? '', ['verified', 'pending', 'rejected']),
            'gender'               => $this->oneOf($filters['gender'] ?? '', ['Male', 'Female', 'Other']),
            'province'             => trim((string) ($filters['province'] ?? '')),
        ];

        $params = [];
        $sql = "SELECT a.id, a.alumni_id, CONCAT(a.last_name, ', ', a.first_name) AS name, a.gender,
                       a.contact_number, a.email, a.address,
                       CONCAT_WS(', ', a.city_municipality, a.province) AS location,
                       a.profile_status, a.verification_status,
                       p.program_code, p.program_name, d.department_name,
                       aa.graduation_year, aa.batch, aa.honors_awards,
                       es.status_name AS employment_status, er.employer, er.job_position,
                       er.industry, er.employment_type,
                       lt.license_name, ls.status_name AS licensure_status, lr.examination_year,
                       u.profile_picture
                FROM alumni a LEFT JOIN users u ON u.id = a.user_id "
             . self::JOIN_ACADEMIC . ' ' . self::JOIN_EMPLOYMENT . ' ' . self::JOIN_LICENSURE . "
                WHERE 1 = 1"
             . $this->where($f, [
                    'program_id'           => 'p.id',
                    'graduation_year'      => 'aa.graduation_year',
                    'employment_status_id' => 'es.id',
                    'licensure_status_id'  => 'ls.id',
                    'profile_status'       => 'a.profile_status',
                    'verification_status'  => 'a.verification_status',
                    'gender'               => 'a.gender',
                    'province'             => 'a.province',
               ], $params);

        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            $kw = '%' . addcslashes($keyword, '%_\\') . '%';
            $sql .= ' AND (a.first_name LIKE ? OR a.last_name LIKE ? OR a.alumni_id LIKE ? OR a.email LIKE ?
                           OR CONCAT(a.first_name, \' \', a.last_name) LIKE ? OR er.employer LIKE ?)';
            array_push($params, $kw, $kw, $kw, $kw, $kw, $kw);
        }

        return db_run($this->db, $sql . ' ORDER BY a.last_name, a.first_name', $params)->fetchAll();
    }

    public function tracer(): array
    {
        return db_run($this->db, 
            "SELECT ts.title, ts.status, ts.start_date, ts.end_date, u.username AS created_by_name,
                    (SELECT COUNT(DISTINCT r.alumni_id) FROM tracer_responses r WHERE r.tracer_study_id = ts.id) AS respondents
             FROM tracer_studies ts
             JOIN users u ON u.id = ts.created_by
             ORDER BY ts.created DESC"
        )->fetchAll();
    }

    public function program(): array
    {
        return db_run($this->db, 
            "SELECT p.program_code, p.program_name,
                    COUNT(DISTINCT aa.alumni_id) AS total_graduates,
                    COUNT(DISTINCT CASE WHEN er.is_current = 1 AND es.status_name LIKE 'Employed%' THEN aa.alumni_id END) AS employed_count,
                    COUNT(DISTINCT CASE WHEN ls.status_name = 'Passed' THEN lr.alumni_id END) AS let_passers
             FROM programs p
             LEFT JOIN alumni_academic aa ON aa.program_id = p.id
             LEFT JOIN employment_records er ON er.alumni_id = aa.alumni_id AND er.is_current = 1
             LEFT JOIN employment_statuses es ON es.id = er.employment_status_id
             LEFT JOIN licensure_records lr ON lr.alumni_id = aa.alumni_id
             LEFT JOIN licensure_statuses ls ON ls.id = lr.status_id
             GROUP BY p.id, p.program_code, p.program_name
             ORDER BY p.program_name"
        )->fetchAll();
    }

    public function engagement(): array
    {
        $rows = [];

        $events = db_run($this->db, 
            "SELECT e.title, e.event_date, COUNT(r.id) AS registrants
             FROM events e
             LEFT JOIN event_registrations r ON r.event_id = e.id AND r.registration_status IN ('registered', 'attended')
             GROUP BY e.id, e.title, e.event_date
             ORDER BY e.event_date DESC"
        )->fetchAll();

        foreach ($events as $r) {
            $rows[] = (object) [
                'category' => 'Event Registrations',
                'item'     => $r->title . ' (' . date('M d, Y', strtotime($r->event_date)) . ')',
                'metric'   => 'Registrants',
                'value'    => (int) $r->registrants,
            ];
        }

        $tracers = db_run($this->db, 
            "SELECT ts.title, COUNT(DISTINCT r.alumni_id) AS respondents
             FROM tracer_studies ts
             LEFT JOIN tracer_responses r ON r.tracer_study_id = ts.id
             GROUP BY ts.id, ts.title
             ORDER BY ts.created DESC"
        )->fetchAll();

        foreach ($tracers as $r) {
            $rows[] = (object) [
                'category' => 'Tracer Study Participation',
                'item'     => $r->title,
                'metric'   => 'Respondents',
                'value'    => (int) $r->respondents,
            ];
        }

        return $rows;
    }

    public function attendanceSummary(): array
    {
        $totalEvents = (int) db_run($this->db, "SELECT COUNT(*) FROM events WHERE status = 'completed'")->fetchColumn();
        $active = (int) db_run($this->db, "SELECT COUNT(*) FROM alumni WHERE profile_status = 'active'")->fetchColumn();

        $attended = (int) db_run($this->db, 
            "SELECT COUNT(*) FROM event_registrations r
             JOIN events e ON e.id = r.event_id AND e.status = 'completed'
             JOIN alumni a ON a.id = r.alumni_id AND a.profile_status = 'active'
             WHERE r.registration_status = 'attended'"
        )->fetchColumn();

        $attendees = (int) db_run($this->db, 
            "SELECT COUNT(DISTINCT r.alumni_id) FROM event_registrations r
             JOIN events e ON e.id = r.event_id AND e.status = 'completed'
             JOIN alumni a ON a.id = r.alumni_id AND a.profile_status = 'active'
             WHERE r.registration_status = 'attended'"
        )->fetchColumn();

        $possible = $totalEvents * $active;

        return [
            'completed_events'   => $totalEvents,
            'active_alumni'      => $active,
            'active_attendees'   => $attendees,
            'attendance_records' => $attended,
            'average_rate'       => $possible > 0 ? round($attended / $possible * 100, 1) : null,
        ];
    }

    public function activeAttendance(array $filters = []): array
    {
        $f = [
            'program_id'      => $this->intOrBlank($filters['program_id'] ?? ''),
            'graduation_year' => $this->intOrBlank($filters['graduation_year'] ?? ''),
        ];
        $level = $this->oneOf($filters['engagement_level'] ?? '', array_keys(self::ENGAGEMENT_LEVELS));

        $params = [];
        $sql = "SELECT a.id, a.alumni_id, CONCAT(a.last_name, ', ', a.first_name) AS name,
                       p.program_code, p.program_name, aa.graduation_year,
                       COUNT(DISTINCT CASE WHEN e.id IS NOT NULL AND r.registration_status IN ('registered', 'attended') THEN e.id END) AS events_registered,
                       COUNT(DISTINCT CASE WHEN e.id IS NOT NULL AND r.registration_status = 'attended' THEN e.id END) AS events_attended,
                       (SELECT COUNT(*) FROM events WHERE status = 'completed') AS total_events,
                       u.profile_picture
                FROM alumni a LEFT JOIN users u ON u.id = a.user_id "
             . self::JOIN_ACADEMIC . "
                LEFT JOIN event_registrations r ON r.alumni_id = a.id
                LEFT JOIN events e ON e.id = r.event_id AND e.status = 'completed'
                WHERE a.profile_status = 'active'"
             . $this->where($f, ['program_id' => 'p.id', 'graduation_year' => 'aa.graduation_year'], $params)
             . " GROUP BY a.id, a.alumni_id, a.last_name, a.first_name, p.program_code, p.program_name, aa.graduation_year, u.profile_picture
                ORDER BY a.last_name, a.first_name";

        $rows = [];
        foreach (db_run($this->db, $sql, $params)->fetchAll() as $r) {
            $total    = (int) $r->total_events;
            $attended = (int) $r->events_attended;

            $r->events_registered = (int) $r->events_registered;
            $r->events_attended   = $attended;
            $r->total_events      = $total;
            $r->attendance_rate   = $total > 0 ? round($attended / $total * 100, 1) : null;
            $r->engagement_key    = self::levelFor($r->attendance_rate, $attended);
            $r->engagement_status = $total === 0 ? 'No completed events yet' : explode(' (', self::ENGAGEMENT_LEVELS[$r->engagement_key])[0];

            if ($level === '' || $r->engagement_key === $level) {
                $rows[] = $r;
            }
        }

        return $rows;
    }

    public function eventAttendance(array $filters = []): array
    {
        $f = ['event_status' => $this->oneOf($filters['event_status'] ?? '', ['upcoming', 'ongoing', 'completed', 'cancelled'])];

        $params = [];
        $sql = "SELECT e.id, e.title, e.event_date, e.status,
                       COUNT(CASE WHEN r.registration_status IN ('registered', 'attended') THEN 1 END) AS registered_count,
                       COUNT(CASE WHEN r.registration_status = 'attended' THEN 1 END) AS attended_count,
                       COUNT(CASE WHEN r.registration_status = 'attended' AND a.profile_status = 'active' THEN 1 END) AS active_attended,
                       (SELECT COUNT(*) FROM alumni WHERE profile_status = 'active') AS active_alumni
                FROM events e
                LEFT JOIN event_registrations r ON r.event_id = e.id
                LEFT JOIN alumni a ON a.id = r.alumni_id
                WHERE 1 = 1"
             . $this->where($f, ['event_status' => 'e.status'], $params)
             . " GROUP BY e.id, e.title, e.event_date, e.status
                ORDER BY e.event_date DESC";

        $rows = db_run($this->db, $sql, $params)->fetchAll();

        foreach ($rows as $r) {
            $held = in_array($r->status, ['ongoing', 'completed'], true);
            $r->registered_count = (int) $r->registered_count;
            $r->attended_count   = (int) $r->attended_count;
            $r->active_attended  = (int) $r->active_attended;
            $r->attendance_rate  = ($held && $r->registered_count > 0) ? round($r->attended_count / $r->registered_count * 100, 1) : null;
            $r->active_rate      = ($held && (int) $r->active_alumni > 0) ? round($r->active_attended / (int) $r->active_alumni * 100, 1) : null;
        }

        return $rows;
    }

    public function attendanceRecords(array $filters = []): array
    {
        $f = [
            'event_id'        => $this->intOrBlank($filters['event_id'] ?? ''),
            'program_id'      => $this->intOrBlank($filters['program_id'] ?? ''),
            'graduation_year' => $this->intOrBlank($filters['graduation_year'] ?? ''),
        ];
        $status = $this->oneOf($filters['attendance_status'] ?? '', ['attended', 'absent', 'registered', 'cancelled']);

        $params = [];
        $sql = "SELECT r.id, a.alumni_id, CONCAT(a.last_name, ', ', a.first_name) AS name,
                       p.program_code, aa.graduation_year,
                       e.title AS event_title, e.event_date, e.status AS event_status,
                       r.registration_status, u.profile_picture,
                       CASE WHEN r.registration_status = 'attended' THEN 'attended'
                            WHEN r.registration_status = 'cancelled' THEN 'cancelled'
                            WHEN e.status = 'completed' THEN 'absent'
                            ELSE 'registered' END AS attendance_status
                FROM event_registrations r
                JOIN alumni a ON a.id = r.alumni_id AND a.profile_status = 'active'
                LEFT JOIN users u ON u.id = a.user_id
                JOIN events e ON e.id = r.event_id "
             . self::JOIN_ACADEMIC . "
                WHERE 1 = 1"
             . $this->where($f, ['event_id' => 'e.id', 'program_id' => 'p.id', 'graduation_year' => 'aa.graduation_year'], $params)
             . " ORDER BY e.event_date DESC, a.last_name, a.first_name";

        $rows = db_run($this->db, $sql, $params)->fetchAll();

        return $status === '' ? $rows : array_values(array_filter($rows, fn($r) => $r->attendance_status === $status));
    }

    private function where(array $filters, array $map, array &$params): string
    {
        $sql = '';
        foreach ($map as $key => $column) {
            if (isset($filters[$key]) && $filters[$key] !== '') {
                $sql .= " AND {$column} = ?";
                $params[] = $filters[$key];
            }
        }
        return $sql;
    }

    private function oneOf($value, array $allowed): string
    {
        return in_array((string) $value, $allowed, true) ? (string) $value : '';
    }

    private function intOrBlank($value): string
    {
        return (is_scalar($value) && ctype_digit((string) $value) && (int) $value > 0) ? (string) (int) $value : '';
    }
}