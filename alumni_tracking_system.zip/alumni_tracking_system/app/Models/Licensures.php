<?php

namespace Models;

use Core\Model;

class Licensures extends Model
{
    public function forAlumni(int|string $alumniId): array
    {
        return db_run($this->db, 
            'SELECT lr.id, 
                    lr.alumni_id, 
                    lr.license_type_id, 
                    lr.status_id, 
                    lr.examination_year,
                    lt.license_name, 
                    ls.status_name
             FROM licensure_records lr
             JOIN license_types lt ON lt.id = lr.license_type_id
             JOIN licensure_statuses ls ON ls.id = lr.status_id
             WHERE lr.alumni_id = ?
             ORDER BY lr.examination_year DESC',
            [$alumniId]
        )->fetchAll();
    }

    public function findByID(int|string $id): ?object
    {
        return db_run($this->db, 
            'SELECT id, 
                    alumni_id, 
                    license_type_id, 
                    status_id, 
                    examination_year
             FROM licensure_records 
             WHERE id = ?',
            [$id]
        )->fetch() ?: null;
    }

    public function save(array $data): bool|int
    {
        $allowed = [
            'id', 
            'alumni_id', 
            'license_type_id', 
            'status_id', 
            'examination_year'
        ];

        return db_save($this->db, 'licensure_records', array_intersect_key($data, array_flip($allowed)));
    }

    public function delete(int|string $id): bool
    {
        return db_run($this->db, 'DELETE FROM licensure_records WHERE id = ?', [$id])->rowCount() > 0;
    }
}