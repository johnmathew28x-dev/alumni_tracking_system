<?php

namespace Models;

use Core\Model;

class GtsReports extends Model
{
    public const MIN_RELIABLE = 5;

    public const FILTERS = [
        'department_id',
        'program_id',
        'graduation_year',
        'academic_year',
        'study_id',
        'survey_year',
        'employment_state',
        'industry_id',
        'place_of_work'
    ];

    private string $from = '';
    private array $params = [];
    private array $f = [];

    private function scope(array $filters): void
    {
        $this->f = [];
        foreach (self::FILTERS as $k) {
            $this->f[$k] = isset($filters[$k]) ? trim((string) $filters[$k]) : '';
        }

        $this->from = " FROM tracer_surveys s
            JOIN tracer_studies ts ON ts.id = s.tracer_study_id AND ts.survey_type = 'gts'
            JOIN alumni a ON a.id = s.alumni_id
            LEFT JOIN alumni_academic aa ON aa.id = (SELECT MAX(x.id) FROM alumni_academic x WHERE x.alumni_id = a.id)
            LEFT JOIN programs p ON p.id = aa.program_id
            LEFT JOIN employment_records cj ON cj.survey_id = s.id AND cj.is_current = 1
            LEFT JOIN employment_records fj ON fj.survey_id = s.id AND fj.is_first_job = 1
            WHERE s.status = 'submitted'";

        $this->params = [];

        $map = [
            'department_id'    => 'p.department_id',
            'program_id'       => 'p.id',
            'graduation_year'  => 'aa.graduation_year',
            'academic_year'    => 'aa.academic_year',
            'study_id'         => 's.tracer_study_id',
            'survey_year'      => 'ts.survey_year',
            'employment_state' => 's.employment_state',
            'industry_id'      => 'cj.industry_id',
            'place_of_work'    => 'cj.place_of_work',
        ];

        foreach ($map as $key => $col) {
            if ($this->f[$key] !== '') {
                $this->from .= " AND $col = ?";
                $this->params[] = $this->f[$key];
            }
        }
    }

    private function dist(string $labelExpr, string $extraJoin = '', string $extraWhere = '', string $order = 'total DESC'): array
    {
        $sql = "SELECT $labelExpr AS label, COUNT(*) AS total" . $this->injectJoin($extraJoin) . ' ' . $extraWhere
             . " GROUP BY label ORDER BY $order";

        return array_map(
            fn($r) => ['label' => $r->label, 'total' => (int) $r->total],
            db_run($this->db, $sql, $this->params)->fetchAll()
        );
    }

    private function injectJoin(string $join): string
    {
        return $join === '' ? $this->from : str_replace(' WHERE s.status', ' ' . $join . ' WHERE s.status', $this->from);
    }

    private function count(string $extraWhere = ''): int
    {
        return (int) db_run($this->db, 'SELECT COUNT(DISTINCT s.id)' . $this->from . ' ' . $extraWhere, $this->params)->fetchColumn();
    }

    private static function pct(int $part, int $whole): ?float
    {
        return $whole > 0 ? round($part * 100 / $whole, 1) : null;
    }

    public function summary(array $filters): array
    {
        $this->scope($filters);

        $respondents = $this->count();
        $employed    = $this->count("AND s.employment_state = 'employed'");
        $notEmployed = $this->count("AND s.employment_state = 'not_employed'");
        $never       = $this->count("AND s.employment_state = 'never_employed'");
        $selfEmp     = $this->count("AND s.employment_state = 'employed' AND cj.employment_type_id = (SELECT id FROM employment_types WHERE name = 'Self-employed')");
        $local       = $this->count("AND s.employment_state = 'employed' AND cj.place_of_work = 'Local'");
        $abroad      = $this->count("AND s.employment_state = 'employed' AND cj.place_of_work = 'Abroad'");
        $related     = $this->count("AND s.employment_state = 'employed' AND cj.related_to_degree = 1");
        $notRelated  = $this->count("AND s.employment_state = 'employed' AND cj.related_to_degree = 0");
        $relevantYes = $this->count('AND s.curriculum_relevant = 1');
        $relevantNo  = $this->count('AND s.curriculum_relevant = 0');

        $employedEver = $employed + $notEmployed;

        $kpis = [
            'respondents'      => $respondents,
            'employed'         => $employed,
            'not_employed'     => $notEmployed,
            'never_employed'   => $never,
            'self_employed'    => $selfEmp,
            'local'            => $local,
            'abroad'           => $abroad,
            'related'          => $related,
            'not_related'      => $notRelated,
            'employment_rate'  => self::pct($employed, $respondents),
            'related_rate'     => self::pct($related, $employed),
            'relevant_yes'     => $relevantYes,
            'relevant_no'      => $relevantNo,
            'relevance_rate'   => self::pct($relevantYes, $relevantYes + $relevantNo),
            'ever_employed'    => $employedEver,
            'reliable'         => $respondents >= self::MIN_RELIABLE,
        ];

        $out = [
            'kpis'                 => $kpis,
            'participation'        => $this->participation(),
            'employment_by_year'   => $this->employmentByYear(),
            'by_program'           => $this->byProgram(),
            'employment_state'     => $this->dist(
                "CASE s.employment_state WHEN 'employed' THEN 'Employed' WHEN 'not_employed' THEN 'Not currently employed' ELSE 'Never employed' END",
                '',
                'AND s.employment_state IS NOT NULL'
            ),
            'employment_type'      => $this->dist('et.name', 'JOIN employment_types et ON et.id = cj.employment_type_id', "AND s.employment_state = 'employed'"),
            'occupation'           => array_slice($this->dist('cj.job_position', '', "AND s.employment_state = 'employed' AND cj.job_position IS NOT NULL"), 0, 10),
            'industry'             => $this->dist('ind.name', 'JOIN industries ind ON ind.id = cj.industry_id', "AND s.employment_state = 'employed'"),
            'place_of_work'        => $this->dist('cj.place_of_work', '', "AND s.employment_state = 'employed' AND cj.place_of_work IS NOT NULL"),
            'first_job_status'     => $this->dist("CASE WHEN s.current_is_first_job = 1 THEN 'Current job is first job' ELSE 'Changed jobs' END", '', "AND s.employment_state = 'employed' AND s.current_is_first_job IS NOT NULL"),
            'job_level'            => $this->dist('jl.name', 'JOIN job_levels jl ON jl.id = cj.job_level_id', "AND s.employment_state = 'employed'", 'MIN(jl.sort_order)'),
            'first_job_level'      => $this->dist('jl.name', 'JOIN job_levels jl ON jl.id = fj.job_level_id', '', 'MIN(jl.sort_order)'),
            'salary'               => $this->dist('sr.name', 'JOIN salary_ranges sr ON sr.id = cj.salary_range_id', "AND s.employment_state = 'employed'", 'MIN(sr.sort_order)'),
            'first_salary'         => $this->dist('sr.name', 'JOIN salary_ranges sr ON sr.id = fj.salary_range_id', '', 'MIN(sr.sort_order)'),
            'time_to_first_job'    => $this->dist('dr.name', 'JOIN duration_ranges dr ON dr.id = fj.time_to_job_id', '', 'MIN(dr.sort_order)'),
            'first_job_duration'   => $this->dist('dr.name', 'JOIN duration_ranges dr ON dr.id = fj.duration_id', '', 'MIN(dr.sort_order)'),
            'search_method'        => $this->dist('jm.name', 'JOIN job_search_methods jm ON jm.id = fj.search_method_id', '', 'total DESC'),
            'curriculum_relevance' => $this->dist("CASE WHEN s.curriculum_relevant = 1 THEN 'Relevant' ELSE 'Not relevant' END", '', 'AND s.curriculum_relevant IS NOT NULL'),
            'competencies'         => $this->dist('c.name', 'JOIN survey_competencies sc ON sc.survey_id = s.id JOIN competencies c ON c.id = sc.competency_id'),
            'course_reasons'       => $this->dist('cr.name', 'JOIN survey_course_reasons scr ON scr.survey_id = s.id JOIN course_reasons cr ON cr.id = scr.course_reason_id'),
            'unemployment_reasons' => $this->dist('ur.name', 'JOIN survey_unemployment_reasons sur ON sur.survey_id = s.id JOIN unemployment_reasons ur ON ur.id = sur.unemployment_reason_id'),
            'accept_reasons'       => $this->dist('er.name', 'JOIN employment_record_reasons l ON l.employment_record_id = fj.id JOIN employment_reasons er ON er.id = l.employment_reason_id AND er.reason_type = \'accept\''),
            'change_reasons'       => $this->dist('er.name', 'JOIN employment_record_reasons l ON l.employment_record_id = cj.id JOIN employment_reasons er ON er.id = l.employment_reason_id AND er.reason_type = \'change\''),
            'sex'                  => $this->dist("COALESCE(a.gender, 'Not stated')"),
            'civil_status'         => $this->dist("COALESCE(cs.name, 'Not stated')", 'LEFT JOIN civil_statuses cs ON cs.id = a.civil_status_id'),
            'region'               => $this->dist("COALESCE(rg.name, 'Not stated')", 'LEFT JOIN regions rg ON rg.id = a.region_id'),
            'residence'            => $this->dist("COALESCE(rt.name, 'Not stated')", 'LEFT JOIN residence_types rt ON rt.id = a.residence_type_id'),
            'honors'               => $this->dist("CASE WHEN aa.honors_awards IS NULL OR aa.honors_awards = '' THEN 'No honors / awards' ELSE 'With honors / awards' END"),
            'program_distribution' => $this->dist('COALESCE(p.program_code, \'Unknown\')'),
            'graduation_years'     => $this->dist('aa.graduation_year', '', 'AND aa.graduation_year IS NOT NULL', 'label'),
            'development'          => $this->development(),
            'feedback'             => $this->feedback(),
        ];

        $out['salary_n'] = array_sum(array_column($out['salary'], 'total'));

        return $out;
    }

    private function development(): array
    {
        $base = $this->from;
        $p    = $this->params;

        $respondents = (int) db_run($this->db, "SELECT COUNT(DISTINCT s.alumni_id) $base", $p)->fetchColumn();
        $exam        = (int) db_run($this->db, "SELECT COUNT(DISTINCT pe.alumni_id) FROM professional_examinations pe WHERE pe.alumni_id IN (SELECT s.alumni_id $base)", $p)->fetchColumn();
        $pass        = (int) db_run($this->db, "SELECT COUNT(DISTINCT pe.alumni_id) FROM professional_examinations pe WHERE pe.result = 'Passed' AND pe.alumni_id IN (SELECT s.alumni_id $base)", $p)->fetchColumn();
        $train       = (int) db_run($this->db, "SELECT COUNT(DISTINCT t.alumni_id) FROM training_records t WHERE t.training_type = 'Training' AND t.alumni_id IN (SELECT s.alumni_id $base)", $p)->fetchColumn();
        $adv         = (int) db_run($this->db, "SELECT COUNT(DISTINCT t.alumni_id) FROM training_records t WHERE t.training_type = 'Advanced Study' AND t.alumni_id IN (SELECT s.alumni_id $base)", $p)->fetchColumn();

        $exams = db_run($this->db, 
            "SELECT pe.exam_name AS label, COUNT(*) AS total, SUM(pe.result = 'Passed') AS passed
             FROM professional_examinations pe WHERE pe.alumni_id IN (SELECT s.alumni_id $base)
             GROUP BY pe.exam_name ORDER BY total DESC LIMIT 10",
            $p
        )->fetchAll();

        return [
            'respondents'         => $respondents,
            'with_exam'           => $exam,
            'exam_passers'        => $pass,
            'with_training'       => $train,
            'with_advanced_study' => $adv,
            'exam_rate'           => self::pct($exam, $respondents),
            'training_rate'       => self::pct($train, $respondents),
            'advanced_rate'       => self::pct($adv, $respondents),
            'exams'               => array_map(fn($r) => ['label' => $r->label, 'total' => (int) $r->total, 'passed' => (int) $r->passed], $exams),
        ];
    }

    private function participation(): array
    {
        $where = " WHERE a.profile_status = 'active'";
        $params = [];
        $sId = $this->f['study_id'];

        $filterMap = [
            'department_id'   => 'p.department_id',
            'program_id'      => 'p.id',
            'graduation_year' => 'aa.graduation_year',
            'academic_year'   => 'aa.academic_year'
        ];

        foreach ($filterMap as $k => $col) {
            if ($this->f[$k] !== '') {
                $where .= " AND $col = ?";
                $params[] = $this->f[$k];
            }
        }

        $studyCond = $sId !== '' ? ' AND sv.tracer_study_id = ?' : '';
        $yearCond  = ($sId === '' && $this->f['survey_year'] !== '') ? ' AND ts2.survey_year = ?' : '';
        $sub = "SELECT COUNT(DISTINCT sv.alumni_id) FROM tracer_surveys sv JOIN tracer_studies ts2 ON ts2.id = sv.tracer_study_id AND ts2.survey_type = 'gts'
                WHERE sv.status = 'submitted' AND sv.alumni_id = a.id" . $studyCond . $yearCond;

        $subParams = [];
        if ($sId !== '') {
            $subParams[] = $sId;
        }
        if ($yearCond !== '') {
            $subParams[] = $this->f['survey_year'];
        }

        $rows = db_run($this->db, 
            "SELECT aa.graduation_year AS label, COUNT(DISTINCT a.id) AS alumni, SUM(($sub) > 0) AS responded
             FROM alumni a
             JOIN alumni_academic aa ON aa.id = (SELECT MAX(x.id) FROM alumni_academic x WHERE x.alumni_id = a.id)
             JOIN programs p ON p.id = aa.program_id
             $where GROUP BY aa.graduation_year ORDER BY aa.graduation_year",
            array_merge($subParams, $params)
        )->fetchAll();

        $total = ['alumni' => 0, 'responded' => 0];
        $byYear = [];

        foreach ($rows as $r) {
            $total['alumni'] += (int) $r->alumni;
            $total['responded'] += (int) $r->responded;
            $byYear[] = [
                'label'     => (string) $r->label,
                'alumni'    => (int) $r->alumni,
                'responded' => (int) $r->responded,
                'rate'      => self::pct((int) $r->responded, (int) $r->alumni)
            ];
        }

        return [
            'total_alumni' => $total['alumni'],
            'responded'    => $total['responded'],
            'rate'         => self::pct($total['responded'], $total['alumni']),
            'by_year'      => $byYear
        ];
    }

    private function employmentByYear(): array
    {
        $rows = db_run($this->db, 
            "SELECT aa.graduation_year AS label, s.employment_state AS state, COUNT(*) AS total" . $this->from
            . " AND aa.graduation_year IS NOT NULL AND s.employment_state IS NOT NULL
               GROUP BY aa.graduation_year, s.employment_state ORDER BY aa.graduation_year",
            $this->params
        )->fetchAll();

        $years = [];
        foreach ($rows as $r) {
            $years[$r->label] ??= ['label' => (string) $r->label, 'employed' => 0, 'not_employed' => 0, 'never_employed' => 0];
            $years[$r->label][$r->state] = (int) $r->total;
        }

        return array_values($years);
    }

    private function byProgram(): array
    {
        $rows = db_run($this->db, 
            "SELECT p.program_code AS code, p.program_name AS name, COUNT(DISTINCT s.id) AS respondents,
                    COUNT(DISTINCT CASE WHEN s.employment_state = 'employed' THEN s.id END) AS employed,
                    COUNT(DISTINCT CASE WHEN s.employment_state = 'not_employed' THEN s.id END) AS not_employed,
                    COUNT(DISTINCT CASE WHEN s.employment_state = 'never_employed' THEN s.id END) AS never_employed,
                    COUNT(DISTINCT CASE WHEN s.employment_state = 'employed' AND cj.related_to_degree = 1 THEN s.id END) AS related,
                    COUNT(DISTINCT CASE WHEN s.employment_state = 'employed' AND cj.place_of_work = 'Local' THEN s.id END) AS local_n,
                    COUNT(DISTINCT CASE WHEN s.employment_state = 'employed' AND cj.place_of_work = 'Abroad' THEN s.id END) AS abroad_n"
            . $this->from . ' AND p.id IS NOT NULL GROUP BY p.id, p.program_code, p.program_name ORDER BY p.program_name',
            $this->params
        )->fetchAll();

        return array_map(fn($r) => [
            'code'            => $r->code,
            'name'            => $r->name,
            'respondents'     => (int) $r->respondents,
            'employed'        => (int) $r->employed,
            'not_employed'    => (int) $r->not_employed,
            'never_employed'  => (int) $r->never_employed,
            'employment_rate' => self::pct((int) $r->employed, (int) $r->respondents),
            'related'         => (int) $r->related,
            'related_rate'    => self::pct((int) $r->related, (int) $r->employed),
            'local'           => (int) $r->local_n,
            'abroad'          => (int) $r->abroad_n,
        ], $rows);
    }

    private function feedback(): array
    {
        $rows = db_run($this->db, 
            "SELECT cf.feedback AS label, p.program_code AS program, aa.graduation_year AS year, ts.survey_year AS survey_year"
            . str_replace(' WHERE s.status', ' JOIN curriculum_feedback cf ON cf.survey_id = s.id WHERE s.status', $this->from)
            . " AND cf.feedback IS NOT NULL AND cf.feedback <> '' ORDER BY cf.modified DESC LIMIT 200",
            $this->params
        )->fetchAll();

        return array_map(fn($r) => [
            'text'        => $r->label,
            'program'     => $r->program,
            'year'        => $r->year,
            'survey_year' => $r->survey_year
        ], $rows);
    }

    public function overview(): array
    {
        $s = $this->summary([]);
        $alumni = (int) db_run($this->db, "SELECT COUNT(*) FROM alumni WHERE profile_status = 'active'")->fetchColumn();
        $registered = (int) db_run($this->db, "SELECT COUNT(*) FROM alumni WHERE verification_status = 'verified'")->fetchColumn();

        return [
            'total_alumni' => $alumni,
            'registered'   => $registered,
            'summary'      => $s
        ];
    }
}