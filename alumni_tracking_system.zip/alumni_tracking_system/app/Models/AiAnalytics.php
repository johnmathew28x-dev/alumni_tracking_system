<?php

namespace Models;

class AiAnalytics
{
    private const CACHE_TTL = 600;
    private const CACHE_MAX = 5;

    public static function status(): array
    {
        return [
            'enabled'     => (bool) AI_ENABLED,
            'configured'  => true,
            'offline'     => true,
            'maxQuestion' => (int) AI_MAX_QUESTION_CHARS,
        ];
    }

    public function ask(string $question, array $filters, bool $isAdmin): array
    {
        if (!AI_ENABLED) {
            return $this->fail('disabled', 'AI Assist is currently turned off by the administrator.', 200);
        }

        $max = (int) AI_MAX_QUESTION_CHARS;

        if (strlen($question) > $max * 4 + 100) {
            return $this->fail('long_question', 'Please keep your question under ' . $max . ' characters.', 200);
        }

        $question = $this->cleanQuestion($question);

        if ($question === '') {
            return $this->fail('empty_question', 'Please type a question or choose a suggested one.', 200);
        }

        if ($this->length($question) > $max) {
            return $this->fail('long_question', 'Please keep your question under ' . $max . ' characters.', 200);
        }

        $scope = $this->scope($filters);
        if ($scope === null) {
            return $this->fail('invalid_filter', 'One of the selected filters is not valid. Please reset the filters and try again.', 200);
        }

        $k       = AiPayload::threshold((int) AI_MIN_GROUP_SIZE);
        $summary = (new GtsReports())->summary($filters);
        $built   = AiPayload::build($summary, $scope, $k);

        if (!$built['ok']) {
            return $this->fail(
                'insufficient_data',
                'Only ' . (int) $built['respondents'] . ' submitted survey(s) match these filters. At least ' . $k
                . ' are needed to analyse results safely. Broaden the filters or wait for more responses.',
                200
            );
        }

        $payload = $built['payload'];
        $hash = hash('sha256', 'offline-v1|' . serialize($payload) . '|' . $question);
        $cached = $this->cacheGet($hash);
        if ($cached) {
            return $cached + ['ok' => true, 'cached' => true, 'scope' => $payload['scope']];
        }

        if ($limit = $this->rateCheck()) {
            return $this->fail('rate_limited', $limit, 429);
        }
        $this->rateRecord();

        $answer = $this->localAnswer($question, $payload);
        $out = [
            'ok' => true,
            'answer' => $answer,
            'usage' => null,
            'generated_at' => date('Y-m-d H:i:s'),
            'model' => 'Built-in statistics assistant (offline)',
            'scope' => $payload['scope'],
            'cached' => false,
        ];
        $this->cachePut($hash, ['answer' => $answer, 'generated_at' => $out['generated_at'], 'model' => $out['model'], 'usage' => null]);
        audit('AI_ANALYTICS', 'Requested an offline summary of privacy-filtered aggregate GTS statistics.', 'analytics');
        return $out;
    }

    private function localAnswer(string $question, array $payload): string
    {
        $metrics = $payload['metrics'] ?? [];
        $n = (int) ($metrics['respondents'] ?? 0);
        $q = strtolower($question);
        $lines = [];
        $lines[] = 'This is a local, rule-based summary of the available aggregate statistics (no external AI service was used).';
        $lines[] = 'Respondents in the selected filters: ' . $n . '. Filters: ' . $this->scopeText($payload['scope'] ?? [] ) . '.';

        $employment = $this->metricRows($metrics['employment_state'] ?? []);
        $years = is_array($metrics['employment_by_graduation_year']['rows'] ?? null) ? $metrics['employment_by_graduation_year']['rows'] : [];
        $programs = is_array($metrics['by_program']['rows'] ?? null) ? $metrics['by_program']['rows'] : [];
        $degree = $this->metricRows($metrics['degree_related_employment'] ?? []);
        $curriculum = $this->metricRows($metrics['curriculum_relevance'] ?? []);

        $wantsYear = preg_match('/year|graduat|compare|trend|differ/i', $q);
        $wantsDegree = preg_match('/degree|related|match|curriculum|relevance|relevant/i', $q);
        $wantsLimit = preg_match('/limitation|caveat|reliable|confidence|quality|sample|response rate|non.response/i', $q);
        $wantsNext = preg_match('/investigat|recommend|improv|next step|should|area|action|suggest/i', $q);
        $wantsProgram = preg_match('/program|programme|course/i', $q);
        $wantsEmploy = preg_match('/employ|job|work|outcome|career|summari|overall|pattern/i', $q);

        if ($wantsNext) {
            $wantsEmploy = true;
            $wantsDegree = true;
        }

        if (!$wantsYear && !$wantsDegree && !$wantsLimit && !$wantsNext && !$wantsProgram && !$wantsEmploy) {
            $wantsEmploy = true;
            $wantsDegree = true;
            $wantsLimit = true;
        }

        if ($wantsEmploy) {
            $lines[] = 'Employment status: ' . ($employment ? $this->describeRows($employment) : $this->withheldText($metrics['employment_state'] ?? []));
        }

        if ($wantsYear) {
            if ($years) {
                $visible = [];
                foreach ($years as $row) {
                    if (isset($row['employment_rate_percent'])) {
                        $visible[] = (string) ($row['graduation_year'] ?? 'Unspecified year') . ': ' . $row['employment_rate_percent'] . '% employed (' . (int) ($row['employed'] ?? 0) . ' of ' . (int) ($row['respondents'] ?? 0) . ' respondents)';
                    } else {
                        $visible[] = (string) ($row['graduation_year'] ?? 'Grouped years') . ': employment details withheld for privacy.';
                    }
                }
                $lines[] = 'Employment by graduation year: ' . implode('; ', $visible) . '.';
            } else {
                $lines[] = 'The system does not have enough safely reportable year-level detail for this selection.';
            }
        }

        if ($wantsDegree) {
            $lines[] = 'Degree-related employment: ' . ($degree ? $this->describeRows($degree) : $this->withheldText($metrics['degree_related_employment'] ?? []));
            $lines[] = 'Curriculum relevance: ' . ($curriculum ? $this->describeRows($curriculum) : $this->withheldText($metrics['curriculum_relevance'] ?? []));
        }

        if ($wantsProgram) {
            if ($programs) {
                $items = [];
                foreach ($programs as $row) {
                    if (isset($row['employment_rate_percent'])) {
                        $items[] = (string) ($row['program'] ?? 'Grouped programs') . ': ' . $row['employment_rate_percent'] . '% employed among ' . (int) ($row['respondents'] ?? 0) . ' respondents';
                    } else {
                        $items[] = (string) ($row['program'] ?? 'Grouped programs') . ': employment detail withheld for privacy.';
                    }
                }
                $lines[] = 'Program comparison: ' . implode('; ', $items) . '.';
            } else {
                $lines[] = 'No program-level results are safely reportable for these filters.';
            }
        }

        if ($wantsLimit) {
            $participation = $metrics['participation'] ?? [];
            $rate = $participation['response_rate_percent'] ?? null;
            $lines[] = 'Limitations: these results describe submitted survey respondents, not necessarily every graduate. Responses are self-reported, non-response may bias the picture, and the data does not establish causes. ' .
                (is_numeric($rate) ? 'The overall response rate in this scope is ' . $rate . '% (' . (int) ($participation['responded'] ?? 0) . ' of ' . (int) ($participation['alumni_on_record'] ?? 0) . ' alumni on record).' : 'The response rate is unavailable or withheld for this scope.');
        }

        if ($wantsNext) {
            $lines[] = 'Areas to investigate: (1) whether response rates differ by graduation year or program; (2) whether reported job-to-degree alignment varies across groups with enough responses; and (3) whether curriculum relevance feedback points to skills or training that deserve closer review. Treat these as follow-up questions, not conclusions about causes.';
        }

        $lines[] = 'Privacy note: small groups are combined or withheld. A withheld value is unknown, not zero, and is not estimated here.';
        return implode("\n\n", $lines);
    }

    private function metricRows(array $metric): array
    {
        return is_array($metric['rows'] ?? null) ? $metric['rows'] : [];
    }

    private function describeRows(array $rows): string
    {
        $parts = [];
        foreach ($rows as $row) {
            if (!is_array($row) || !isset($row['label'])) continue;
            $part = (string) $row['label'];
            if (isset($row['count'])) $part .= ': ' . (int) $row['count'] . ' (' . ($row['percent'] ?? $row['percent_of_respondents'] ?? 'percentage unavailable') . (is_numeric($row['percent'] ?? $row['percent_of_respondents'] ?? null) ? '%' : '') . ')';
            $parts[] = $part;
        }
        return $parts ? implode('; ', $parts) . '.' : 'No safely reportable categories are available.';
    }

    private function withheldText(array $metric): string
    {
        $status = (string) ($metric['status'] ?? '');
        return $status !== '' ? ucfirst($status) . '; values are not inferred.' : 'No safely reportable values are available; values are not inferred.';
    }

    private function scopeText(array $scope): string
    {
        $parts = [];
        foreach ($scope as $key => $value) $parts[] = $key . ': ' . $value;
        return $parts ? implode(', ', $parts) : 'all available submitted surveys';
    }

    private function fail(string $category, string $message, int $http): array
    {
        return ['ok' => false, 'category' => $category, 'message' => $message, 'http' => $http];
    }

    private function cleanQuestion(string $q): string
    {
        $q = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $q) ?? '';
        $q = str_replace(['<<<', '>>>'], '', $q);

        return trim(preg_replace('/\s+/u', ' ', $q) ?? '');
    }

    private function length(string $s): int
    {
        return function_exists('mb_strlen') ? mb_strlen($s) : strlen($s);
    }

private function scope(array $f): ?array
{
    $L     = new Lookups();
    $scope = [];

    $lists = [
        'department_id' => [
            'Department',
            fn() => $L->departments(),
            fn($r) => $r->department_name
        ],
        'program_id' => [
            'Program',
            fn() => $L->programs(),
            fn($r) => $r->program_code . ' - ' . $r->program_name
        ],
        'study_id' => [
            'Survey period',
            fn() => $L->gtsStudies(),
            fn($r) => $r->title
        ],
        'industry_id' => [
            'Industry',
            fn() => $L->ref('industries', false),
            fn($r) => $r->name
        ],
    ];

    foreach ($lists as $key => [$title, $rows, $label]) {
        if (($f[$key] ?? '') === '') {
            continue;
        }

        $name = null;
        $selectedId = (string) $f[$key];

        $lookupRows = call_user_func($rows);
        foreach ($lookupRows as $row) {
            if ((string) $row->id === $selectedId) {
                $name = call_user_func($label, $row);
                break;
            }
        }

        if ($name === null) {
            return null;
        }

        $scope[$title] = AiPayload::clean($name);
    }

    $years = [
        'graduation_year' => [
            'Graduation year',
            array_map(fn($r) => (string) $r->graduation_year, $L->graduationYears())
        ],
        'academic_year' => [
            'Academic year',
            array_map(fn($r) => (string) $r->academic_year, $L->academicYears())
        ],
        'survey_year' => [
            'Survey year',
            array_map(fn($r) => (string) $r->survey_year, $L->gtsStudies())
        ],
    ];

    foreach ($years as $key => [$title, $allowed]) {
        if (($f[$key] ?? '') === '') {
            continue;
        }

        if (!in_array((string) $f[$key], $allowed, true)) {
            return null;
        }

        $scope[$title] = (string) $f[$key];
    }

    $states = [
        'employed' => 'Employed',
        'not_employed' => 'Not currently employed',
        'never_employed' => 'Never employed'
    ];

    if (($f['employment_state'] ?? '') !== '') {
        if (!isset($states[$f['employment_state']])) {
            return null;
        }

        $scope['Employment status'] = $states[$f['employment_state']];
    }

    if (($f['place_of_work'] ?? '') !== '') {
        if (!in_array($f['place_of_work'], ['Local', 'Abroad'], true)) {
            return null;
        }

        $scope['Location of work'] = $f['place_of_work'];
    }

    return $scope ?: [
        'Selection' => 'All submitted Graduate Tracer Surveys (no filters)'
    ];
}

    private function rateCheck(): ?string
    {
        $now  = time();
        $hits = array_values(array_filter($_SESSION['ai_hits'] ?? [], fn($t) => $t > $now - 3600));
        $_SESSION['ai_hits'] = $hits;

        $last = $hits ? max($hits) : 0;
        if ($last && $now - $last < (int) AI_COOLDOWN_SECONDS) {
            return 'Please wait a few seconds before asking another question.';
        }

        if (count($hits) >= (int) AI_RATE_LIMIT_PER_HOUR) {
            return 'You have reached the hourly limit for AI questions. Please try again later.';
        }

        return null;
    }

    private function rateRecord(): void
    {
        $_SESSION['ai_hits'][] = time();
    }

    private function cacheGet(string $hash): ?array
    {
        $entry = $_SESSION['ai_cache'][$hash] ?? null;

        if (!$entry || strtotime($entry['generated_at']) < time() - self::CACHE_TTL) {
            return null;
        }

        return $entry;
    }

    private function cachePut(string $hash, array $entry): void
    {
        $cache = $_SESSION['ai_cache'] ?? [];
        $cache[$hash] = $entry;

        if (count($cache) > self::CACHE_MAX) {
            $cache = array_slice($cache, -self::CACHE_MAX, null, true);
        }

        $_SESSION['ai_cache'] = $cache;
    }
}
