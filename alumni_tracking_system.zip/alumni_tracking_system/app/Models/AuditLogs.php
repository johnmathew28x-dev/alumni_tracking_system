<?php

namespace Models;

use Core\Model;

class AuditLogs extends Model
{
    public function find($limit = 500)
    {
        $limit = max(1, (int) $limit);

        return db_run($this->db, 
            "SELECT l.id, l.action, l.description, l.module, l.record_id, l.ip_address, l.created,
                    COALESCE(u.username, 'System') AS username, u.profile_picture
             FROM audit_logs l
             LEFT JOIN users u ON u.id = l.user_id
             ORDER BY l.created DESC, l.id DESC
             LIMIT {$limit}"
        )->fetchAll();
    }

    public function log($userId, $action, $description = '', $module = null, $recordId = null)
    {
        return db_run($this->db, 
            'INSERT INTO audit_logs (user_id, action, description, module, record_id, ip_address, created)
             VALUES (?, ?, ?, ?, ?, ?, ?)',
            [
                $userId,
                $action,
                substr((string) $description, 0, 500),
                $module,
                $recordId,
                $_SERVER['REMOTE_ADDR'] ?? 'CLI',
                date('Y-m-d H:i:s'),
            ]
        );
    }
}