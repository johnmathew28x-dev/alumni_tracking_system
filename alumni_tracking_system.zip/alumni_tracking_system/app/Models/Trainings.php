<?php

namespace Models;

use Core\Model;

class Trainings extends Model
{
    public function forAlumni(int $alumniId): array
    {
        return db_run($this->db, 
            'SELECT id, alumni_id, training_title, organizer, date_start, date_end,
                    training_type, duration, credits_earned, college_university, training_year, purpose, purpose_other
             FROM training_records
             WHERE alumni_id = ?
             ORDER BY training_year DESC, date_start DESC, id DESC',
            [$alumniId]
        )->fetchAll();
    }

    public function findByID(int $id): ?object
    {
        return db_run($this->db, 
            'SELECT id, alumni_id, training_title, organizer, date_start, date_end,
                    training_type, duration, credits_earned, college_university, training_year, purpose, purpose_other
             FROM training_records 
             WHERE id = ?',
            [$id]
        )->fetch() ?: null;
    }

    public function save(array $data)
    {
        $allowed = [
            'id', 'alumni_id', 'training_title', 'organizer', 'date_start', 'date_end', 
            'training_type', 'duration', 'credits_earned', 
            'college_university', 'training_year', 'purpose', 'purpose_other'
        ];

        return db_save($this->db, 'training_records', array_intersect_key($data, array_flip($allowed)));
    }

    public function delete(int $id): bool
    {
        return db_run($this->db, 'DELETE FROM training_records WHERE id = ?', [$id])->rowCount() > 0;
    }
}