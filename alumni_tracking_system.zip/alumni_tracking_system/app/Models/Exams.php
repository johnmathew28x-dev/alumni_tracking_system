<?php

namespace Models;

use Core\Model;

class Exams extends Model
{
    public function forAlumni($alumniId)
    {
        return db_run($this->db, 
            'SELECT id, alumni_id, exam_name, date_taken, rating, result
             FROM professional_examinations WHERE alumni_id = ? ORDER BY date_taken DESC, id DESC',
            [$alumniId]
        )->fetchAll();
    }

    public function findByID($id)
    {
        return db_run($this->db, 
            'SELECT id, alumni_id, exam_name, date_taken, rating, result FROM professional_examinations WHERE id = ?',
            [$id]
        )->fetch() ?: null;
    }

    public function save($data)
    {
        $allowed = ['id', 'alumni_id', 'exam_name', 'date_taken', 'rating', 'result'];

        return db_save($this->db, 'professional_examinations', array_intersect_key($data, array_flip($allowed)));
    }

    public function delete($id): bool
    {
        return db_run($this->db, 'DELETE FROM professional_examinations WHERE id = ?', [$id])->rowCount() > 0;
    }
}