<?php

namespace Models;

use Core\Model;

class TracerResponses extends Model
{
    public function forStudyAndAlumni(int $studyId, int $alumniId): array
    {
        $rows = db_run($this->db, 
            'SELECT tracer_question_id, answer 
             FROM tracer_responses
             WHERE tracer_study_id = ? AND alumni_id = ?',
            [$studyId, $alumniId]
        )->fetchAll();

        $map = [];
        foreach ($rows as $r) {
            $map[$r->tracer_question_id] = $r->answer;
        }

        return $map;
    }

    public function saveAnswer(int $studyId, int $questionId, int $alumniId, ?string $answer)
    {
        $existing = db_run($this->db, 
            'SELECT id FROM tracer_responses WHERE tracer_question_id = ? AND alumni_id = ?',
            [$questionId, $alumniId]
        )->fetch();

        return db_save($this->db, 'tracer_responses', [
            'id'                 => $existing->id ?? null,
            'tracer_study_id'    => $studyId,
            'tracer_question_id' => $questionId,
            'alumni_id'          => $alumniId,
            'answer'             => $answer,
        ]);
    }

    public function saveAnswers(int $studyId, int $alumniId, array $answers): bool
    {
        try {
            $this->db->beginTransaction();

            foreach ($answers as $questionId => $answer) {
                if (!$this->saveAnswer($studyId, (int) $questionId, $alumniId, (string) $answer)) {
                    throw new \RuntimeException('A tracer response could not be saved.');
                }
            }

            $this->db->commit();
            return true;
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            error_log('Tracer response save failed: ' . $e->getMessage());
            return false;
        }
    }

    public function countRespondents(int $studyId): int
    {
        return (int) db_run($this->db, 
            'SELECT COUNT(DISTINCT alumni_id) FROM tracer_responses WHERE tracer_study_id = ?',
            [$studyId]
        )->fetchColumn();
    }

    public function countActiveRespondents(): int
    {
        return (int) db_run($this->db, 
            "SELECT COUNT(DISTINCT r.alumni_id) 
             FROM tracer_responses r
             JOIN tracer_studies ts ON ts.id = r.tracer_study_id
             WHERE ts.status = 'active'"
        )->fetchColumn();
    }

    public function breakdown(int $questionId): array
    {
        return db_run($this->db, 
            'SELECT answer, COUNT(*) AS total
             FROM tracer_responses
             WHERE tracer_question_id = ?
             GROUP BY answer
             ORDER BY total DESC',
            [$questionId]
        )->fetchAll();
    }
}
