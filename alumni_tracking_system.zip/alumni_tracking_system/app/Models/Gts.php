<?php

namespace Models;

use Core\Model;

class Gts extends Model
{
    public const SECTIONS = [
        1  => 'General Information',
        2  => 'Educational Background',
        3  => 'Professional Examinations',
        4  => 'Reasons for Taking the Course',
        5  => 'Trainings / Advanced Studies',
        6  => 'Employment Status',
        7  => 'Current Employment',
        8  => 'First Job',
        9  => 'Job Search',
        10 => 'Job Level and Earnings',
        11 => 'Curriculum Relevance',
        12 => 'Competencies',
        13 => 'Curriculum Feedback',
        14 => 'Review and Submit',
    ];

    private array $nameCache = [];

    public function findSurvey(int $studyId, int $alumniId)
    {
        return db_run($this->db, 
            'SELECT * FROM tracer_surveys WHERE tracer_study_id = ? AND alumni_id = ?',
            [$studyId, $alumniId]
        )->fetch() ?: null;
    }

    public function surveyById(int $id)
    {
        return db_run($this->db, 'SELECT * FROM tracer_surveys WHERE id = ?', [$id])->fetch() ?: null;
    }

    public function ensureSurvey(int $studyId, int $alumniId)
    {
        $survey = $this->findSurvey($studyId, $alumniId);
        if ($survey) {
            return $survey;
        }

        try {
            db_save($this->db, 'tracer_surveys', [
                'tracer_study_id' => $studyId,
                'alumni_id'       => $alumniId,
                'status'          => 'draft',
                'last_section'    => 1,
            ]);
        } catch (\PDOException $e) {
        }

        return $this->findSurvey($studyId, $alumniId);
    }

    public function isEditable($survey, $study): bool
    {
        return $study && $study->status === 'active' && $survey->status === 'draft';
    }

    public function touch(int $surveyId, int $section): void
    {
        db_run($this->db, 
            'UPDATE tracer_surveys SET last_section = GREATEST(last_section, ?), modified = ? WHERE id = ?',
            [$section, date('Y-m-d H:i:s'), $surveyId]
        );
    }

    public function submit(int $surveyId): void
    {
        db_run($this->db, 
            "UPDATE tracer_surveys SET status = 'submitted', submitted_at = ?, allow_resubmission = 0,
                    last_section = 14, modified = ? WHERE id = ?",
            [date('Y-m-d H:i:s'), date('Y-m-d H:i:s'), $surveyId]
        );
    }

    public function allowResubmission(int $surveyId): void
    {
        db_run($this->db, 
            "UPDATE tracer_surveys SET status = 'draft', allow_resubmission = 1, modified = ? WHERE id = ?",
            [date('Y-m-d H:i:s'), $surveyId]
        );
    }

    public function load($survey): array
    {
        $sid = (int) $survey->id;
        $aid = (int) $survey->alumni_id;

        $general = db_run($this->db, 
            'SELECT first_name, middle_name, last_name, suffix, date_of_birth, gender, contact_number,
                    email, address, civil_status_id, region_id, province, city_municipality,
                    residence_type_id
             FROM alumni WHERE id = ?',
            [$aid]
        )->fetch(\PDO::FETCH_ASSOC) ?: [];

        $education = db_run($this->db, 
            'SELECT aa.degree, aa.major AS specialization, aa.honors_awards, aa.academic_year, aa.graduation_year,
                    aa.student_id, p.program_name, d.department_name
             FROM alumni_academic aa
             JOIN programs p ON p.id = aa.program_id
             JOIN departments d ON d.id = p.department_id
             WHERE aa.id = (SELECT MAX(x.id) FROM alumni_academic x WHERE x.alumni_id = ?)',
            [$aid]
        )->fetch(\PDO::FETCH_ASSOC) ?: [];

        $current = $this->findRecord($sid, 'current');
        $first   = $this->findRecord($sid, 'first');

        $feedback = db_run($this->db, 'SELECT feedback FROM curriculum_feedback WHERE survey_id = ?', [$sid])->fetchColumn();

        return [
            'survey' => [
                'id'                   => $sid,
                'status'               => $survey->status,
                'employment_state'     => $survey->employment_state,
                'current_is_first_job' => $survey->current_is_first_job,
                'curriculum_relevant'  => $survey->curriculum_relevant,
                'last_section'         => (int) $survey->last_section,
                'submitted_at'         => $survey->submitted_at,
            ],
            'general'      => $general,
            'education'    => $education,
            'course'       => $this->links('survey_course_reasons', 'survey_id', $sid, 'course_reason_id', 'course_reasons'),
            'unemployment' => $this->links('survey_unemployment_reasons', 'survey_id', $sid, 'unemployment_reason_id', 'unemployment_reasons'),
            'current'      => $current,
            'first'        => $first,
            'accept'       => $first ? $this->recordReasons((int) $first['id'], 'accept') : ['ids' => [], 'other' => ''],
            'change'       => $current ? $this->recordReasons((int) $current['id'], 'change') : ['ids' => [], 'other' => ''],
            'competencies' => $this->links('survey_competencies', 'survey_id', $sid, 'competency_id', 'competencies'),
            'feedback'     => $feedback === false ? '' : (string) $feedback,
        ];
    }

    public function findRecord(int $surveyId, string $kind): ?array
    {
        $sql = $kind === 'current'
            ? 'SELECT * FROM employment_records WHERE survey_id = ? AND is_current = 1 ORDER BY id LIMIT 1'
            : 'SELECT * FROM employment_records WHERE survey_id = ? AND is_first_job = 1 ORDER BY is_current ASC, id LIMIT 1';

        return db_run($this->db, $sql, [$surveyId])->fetch(\PDO::FETCH_ASSOC) ?: null;
    }

    public function saveSection(int $n, $survey, \ArrayAccess $d): array
    {
        $sid   = (int) $survey->id;
        $aid   = (int) $survey->alumni_id;
        $state = $survey->employment_state;
        $L     = new Lookups();

        switch ($n) {
            case 1:
                [$errors, $row] = GtsGeneral::validate($d);
                if (!$errors) {
                    $row['id'] = $aid;
                    db_save($this->db, 'alumni', $row);
                }
                return $errors;

            case 2:
                return $this->saveEducation($aid, $d);

            case 3:
            case 5:
                return [];

            case 4:
                $ids = $this->idList($d['course_reason_ids']);
                if (!$ids || array_diff($ids, $L->validIds('course_reasons'))) {
                    return ['course_reason_ids' => 'Please select at least one reason.'];
                }
                if ($err = $this->otherRequired('course_reasons', $ids, $d['course_reason_other'], 'course_reason_other')) {
                    return $err;
                }
                $this->replaceLinks('survey_course_reasons', 'survey_id', $sid, 'course_reason_id', 'course_reasons', $ids, $d['course_reason_other']);
                return [];

            case 6:
                return $this->saveEmploymentState($survey, $d);
        }

        if ($state === null) {
            return ['employment_state' => 'Please complete the Employment Status section first.'];
        }

        switch ($n) {
            case 7:
                return $state === 'employed' ? $this->saveCurrentJob($survey, $d)
                    : ['_' => 'This section only applies if you are currently employed.'];
            case 8:
                return $state === 'employed' ? $this->saveFirstJob($survey, $d)
                    : ['_' => 'This section does not apply to you.'];
            case 9:
                return $state === 'employed' ? $this->saveJobSearch($survey, $d)
                    : ['_' => 'This section does not apply to you.'];
            case 10:
                return $state === 'employed' ? $this->saveLevelAndEarnings($survey, $d)
                    : ['_' => 'This section does not apply to you.'];
            case 11:
                if ($state !== 'employed') {
                    return ['_' => 'This section does not apply to you.'];
                }
                if (!in_array($d['curriculum_relevant'], ['0', '1'], true)) {
                    return ['curriculum_relevant' => 'Please answer Yes or No.'];
                }
                db_run($this->db, 'UPDATE tracer_surveys SET curriculum_relevant = ?, modified = ? WHERE id = ?',
                    [(int) $d['curriculum_relevant'], date('Y-m-d H:i:s'), $sid]);
                if ($d['curriculum_relevant'] === '0') {
                    db_run($this->db, 'DELETE FROM survey_competencies WHERE survey_id = ?', [$sid]);
                }
                return [];
            case 12:
                if ($state !== 'employed' || (string) $survey->curriculum_relevant !== '1') {
                    return ['_' => 'Competencies are only asked when the curriculum was relevant to your first job.'];
                }
                $ids = $this->idList($d['competency_ids']);
                if (!$ids || array_diff($ids, $L->validIds('competencies'))) {
                    return ['competency_ids' => 'Please select at least one competency.'];
                }
                if ($err = $this->otherRequired('competencies', $ids, $d['competency_other'], 'competency_other')) {
                    return $err;
                }
                $this->replaceLinks('survey_competencies', 'survey_id', $sid, 'competency_id', 'competencies', $ids, $d['competency_other']);
                return [];
            case 13:
                $text = trim(strip_tags((string) $d['curriculum_feedback']));
                if (strlen($text) > 2000) {
                    return ['curriculum_feedback' => 'Please keep your suggestions under 2000 characters.'];
                }
                $exists = db_run($this->db, 'SELECT id FROM curriculum_feedback WHERE survey_id = ?', [$sid])->fetchColumn();
                db_save($this->db, 'curriculum_feedback', ['id' => $exists ?: null, 'survey_id' => $sid, 'feedback' => $text !== '' ? $text : null]);
                return [];
        }

        return ['_' => 'Unknown survey section.'];
    }

    public function missing(array $data): array
    {
        $m  = [];
        $s  = $data['survey'];
        $g  = $data['general'];
        $st = $s['employment_state'];

        foreach (['gender' => 'sex', 'date_of_birth' => 'birthday', 'civil_status_id' => 'civil status',
                  'region_id' => 'region of origin', 'province' => 'province'] as $f => $label) {
            if (empty($g[$f])) {
                $m[] = '1. General Information: ' . $label . ' is missing.';
            }
        }
        if (empty($data['education']['degree'])) {
            $m[] = '2. Educational Background: degree is missing.';
        }
        if (!$data['course']['ids']) {
            $m[] = '4. Reasons for taking the course: select at least one.';
        }
        if (!$st) {
            $m[] = '6. Employment Status: not answered.';
            return $m;
        }
        if ($st !== 'employed' && !$data['unemployment']['ids']) {
            $m[] = '6. Employment Status: select at least one reason.';
        }
        if ($st !== 'employed') {
            return $m;
        }

        $cur    = $data['current'];
        $first  = $data['first'];
        $merged = $st === 'employed' && (string) $s['current_is_first_job'] === '1';

        if ($st === 'employed') {
            if (!$cur || !$cur['employment_type_id'] || !$cur['job_position'] || !$cur['industry_id']
                || !$cur['place_of_work'] || $cur['related_to_degree'] === null || $s['current_is_first_job'] === null) {
                $m[] = '7. Current Employment: incomplete.';
            }
        }
        if (!$first || !$first['duration_id'] || !$data['accept']['ids']
            || (!$merged && (!$first['job_position'] || !$first['industry_id'] || $first['related_to_degree'] === null))) {
            $m[] = '8. First Job: incomplete.';
        }
        if (!$first || !$first['search_method_id'] || !$first['time_to_job_id']
            || ($st === 'employed' && !$merged && !$data['change']['ids'])) {
            $m[] = '9. Job Search: incomplete.';
        }
        if (!$first || !$first['job_level_id'] || ($st === 'employed' && !$merged && (!$cur || !$cur['job_level_id']))) {
            $m[] = '10. Job Level and Earnings: incomplete.';
        }
        if ($s['curriculum_relevant'] === null) {
            $m[] = '11. Curriculum Relevance: not answered.';
        } elseif ((string) $s['curriculum_relevant'] === '1' && !$data['competencies']['ids']) {
            $m[] = '12. Competencies: select at least one.';
        }
        return $m;
    }

    public function review(array $data): array
    {
        $g  = $data['general'];
        $ed = $data['education'];
        $s  = $data['survey'];
        $yn = fn($v) => $v === null || $v === '' ? '' : ((int) $v === 1 ? 'Yes' : 'No');
        $nm = fn(string $t, $id) => $id ? ($this->names($t)[(int) $id] ?? '') : '';
        $list = function (string $table, array $block) {
            $out = [];
            foreach ($block['ids'] as $id) {
                $label = $this->names($table)[$id] ?? '';
                if ($label === 'Other' && $block['other'] !== '') {
                    $label = 'Other: ' . $block['other'];
                }
                $out[] = $label;
            }
            return implode('; ', $out);
        };

        $sections = [];
        $sections[] = ['title' => '1. General Information', 'rows' => [
            ['Name', trim($g['first_name'] . ' ' . $g['middle_name'] . ' ' . $g['last_name'] . ' ' . $g['suffix'])],
            ['Sex', $g['gender']], ['Civil status', $nm('civil_statuses', $g['civil_status_id'])],
            ['Birthday', $g['date_of_birth']], ['Mobile number', $g['contact_number']],
            ['Permanent address', $g['address']], ['Region of origin', $nm('regions', $g['region_id'])],
            ['Province', $g['province']], ['Residence', trim($g['city_municipality'] . ' ' . $nm('residence_types', $g['residence_type_id']))],
        ]];
        $sections[] = ['title' => '2. Educational Background', 'rows' => [
            ['Degree', $ed['degree'] ?? ''], ['Specialization', $ed['specialization'] ?? ''],
            ['Program', $ed['program_name'] ?? ''], ['Year graduated', $ed['graduation_year'] ?? ''],
            ['Honors / awards', $ed['honors_awards'] ?? ''],
        ]];

        $exams = db_run($this->db, 'SELECT exam_name, date_taken, rating, result FROM professional_examinations WHERE alumni_id = ? ORDER BY date_taken',
            [$this->aid($s['id'])])->fetchAll();
        $sections[] = ['title' => '3. Professional Examinations', 'rows' => $exams
            ? array_map(fn($x) => [$x->exam_name, trim(($x->date_taken ?: '') . ' | rating ' . ($x->rating ?: '-') . ' | ' . $x->result)], $exams)
            : [['None recorded', '']]];

        $sections[] = ['title' => '4. Reasons for Taking the Course', 'rows' => [['Reasons', $list('course_reasons', $data['course'])]]];

        $trainings = db_run($this->db, 'SELECT training_title, training_type, organizer, training_year FROM training_records WHERE alumni_id = ? ORDER BY training_year DESC',
            [$this->aid($s['id'])])->fetchAll();
        $sections[] = ['title' => '5. Trainings / Advanced Studies', 'rows' => $trainings
            ? array_map(fn($x) => [$x->training_title, trim($x->training_type . ' | ' . ($x->organizer ?: '-') . ' | ' . ($x->training_year ?: ''), ' |')], $trainings)
            : [['None recorded', '']]];

        $states = ['employed' => 'Presently employed', 'not_employed' => 'Not currently employed', 'never_employed' => 'Never employed'];
        $rows6  = [['Employment status', $states[$s['employment_state']] ?? '']];
        if ($s['employment_state'] && $s['employment_state'] !== 'employed') {
            $rows6[] = ['Reasons', $list('unemployment_reasons', $data['unemployment'])];
        }
        $sections[] = ['title' => '6. Employment Status', 'rows' => $rows6];

        if ($s['employment_state'] === 'employed' && $data['current']) {
            $c = $data['current'];
            $sections[] = ['title' => '7. Current Employment', 'rows' => [
                ['Employment type', $nm('employment_types', $c['employment_type_id'])],
                ['Occupation', $c['job_position']], ['Employer', $c['employer']],
                ['Line of business', $nm('industries', $c['industry_id'])], ['Place of work', $c['place_of_work']],
                ['Related to degree', $yn($c['related_to_degree'])], ['Is this the first job?', $yn($s['current_is_first_job'])],
            ]];
        }
        if ($s['employment_state'] === 'employed' && $data['first']) {
            $f = $data['first'];
            $sections[] = ['title' => '8-10. First Job', 'rows' => [
                ['Position', $f['job_position']], ['Industry', $nm('industries', $f['industry_id'])],
                ['Location', $f['employment_location']], ['Related to degree', $yn($f['related_to_degree'])],
                ['Reasons for accepting', $list('employment_reasons', $data['accept'])],
                ['Duration in first job', $nm('duration_ranges', $f['duration_id'])],
                ['How the job was found', $nm('job_search_methods', $f['search_method_id'])],
                ['Time to land first job', $nm('duration_ranges', $f['time_to_job_id'])],
                ['Job level', $nm('job_levels', $f['job_level_id'])],
                ['Initial gross monthly earnings', $nm('salary_ranges', $f['salary_range_id']) ?: 'Prefer not to say'],
            ]];
            if ($data['current'] && (int) $data['current']['is_first_job'] === 0 && $s['employment_state'] === 'employed') {
                $c = $data['current'];
                $sections[] = ['title' => 'Present Job (different from first job)', 'rows' => [
                    ['Reasons for changing jobs', $list('employment_reasons', $data['change'])],
                    ['Job level', $nm('job_levels', $c['job_level_id'])],
                    ['Gross monthly earnings', $nm('salary_ranges', $c['salary_range_id']) ?: 'Prefer not to say'],
                ]];
            }
            $sections[] = ['title' => '11-12. Curriculum Relevance and Competencies', 'rows' => [
                ['Curriculum relevant to first job', $yn($s['curriculum_relevant'])],
                ['Competencies used', $list('competencies', $data['competencies'])],
            ]];
        }
        $sections[] = ['title' => '13. Curriculum Feedback', 'rows' => [['Suggestions', $data['feedback']]]];

        return $sections;
    }

    public function responses(array $f): array
    {
        $sql = "SELECT s.id, s.status, s.employment_state, s.submitted_at, s.allow_resubmission,
                       a.alumni_id AS alumni_no, CONCAT(a.last_name, ', ', a.first_name) AS name,
                       p.program_code, aa.graduation_year, ts.title AS study_title, ts.survey_year,
                       u.profile_picture
                FROM tracer_surveys s
                JOIN tracer_studies ts ON ts.id = s.tracer_study_id
                JOIN alumni a ON a.id = s.alumni_id
                LEFT JOIN users u ON u.id = a.user_id
                LEFT JOIN alumni_academic aa ON aa.id = (SELECT MAX(x.id) FROM alumni_academic x WHERE x.alumni_id = a.id)
                LEFT JOIN programs p ON p.id = aa.program_id
                WHERE ts.survey_type = 'gts'";
        $params = [];

        foreach (['study_id' => 's.tracer_study_id', 'program_id' => 'p.id', 'graduation_year' => 'aa.graduation_year',
                  'employment_state' => 's.employment_state', 'status' => 's.status'] as $key => $col) {
            if (!empty($f[$key])) {
                $sql .= " AND $col = ?";
                $params[] = $f[$key];
            }
        }
        if (!empty($f['keyword'])) {
            $kw = '%' . $f['keyword'] . '%';
            $sql .= ' AND (a.first_name LIKE ? OR a.last_name LIKE ? OR a.alumni_id LIKE ?)';
            array_push($params, $kw, $kw, $kw);
        }

        return db_run($this->db, $sql . ' ORDER BY s.modified DESC LIMIT 1000', $params)->fetchAll();
    }

    private function saveEducation(int $aid, \ArrayAccess $d): array
    {
        $errors = [];
        if ($d['degree'] === '') {
            $errors['degree'] = 'Degree is required.';
        }
        foreach (['degree' => 150, 'specialization' => 150, 'honors_awards' => 255] as $f => $max) {
            if (strlen($d[$f]) > $max) {
                $errors[$f] = 'Too long (maximum ' . $max . ' characters).';
            }
        }
        if ($d['academic_year'] !== '') {
            if (!preg_match('/^(\d{4})-(\d{4})$/', $d['academic_year'], $m) || (int) $m[2] !== (int) $m[1] + 1) {
                $errors['academic_year'] = 'Academic year must look like 2022-2023.';
            }
        }

        $id = db_run($this->db, 'SELECT MAX(id) FROM alumni_academic WHERE alumni_id = ?', [$aid])->fetchColumn();
        if (!$id) {
            $errors['degree'] = 'No academic record was found for you. Please contact the alumni office.';
        }
        if ($errors) {
            return $errors;
        }

        db_save($this->db, 'alumni_academic', [
            'id'            => $id,
            'degree'        => $d['degree'],
            'major'         => $d['specialization'] ?: null,
            'honors_awards' => $d['honors_awards'] ?: null,
            'academic_year' => $d['academic_year'] ?: null,
        ]);
        return [];
    }

    private function saveEmploymentState($survey, \ArrayAccess $d): array
    {
        $sid = (int) $survey->id;
        $new = $d['employment_state'];
        $L   = new Lookups();

        if (!in_array($new, ['employed', 'not_employed', 'never_employed'], true)) {
            return ['employment_state' => 'Please choose your employment status.'];
        }

        $ids = [];
        if ($new !== 'employed') {
            $ids = $this->idList($d['unemployment_reason_ids']);
            if (!$ids || array_diff($ids, $L->validIds('unemployment_reasons'))) {
                return ['unemployment_reason_ids' => 'Please select at least one reason.'];
            }
            if ($err = $this->otherRequired('unemployment_reasons', $ids, $d['unemployment_reason_other'], 'unemployment_reason_other')) {
                return $err;
            }
        }

        $this->replaceLinks('survey_unemployment_reasons', 'survey_id', $sid, 'unemployment_reason_id',
            'unemployment_reasons', $ids, $d['unemployment_reason_other']);

        if ($new !== 'employed') {
            db_run($this->db, 'DELETE FROM employment_records WHERE survey_id = ?', [$sid]);
            db_run($this->db, 'DELETE FROM survey_competencies WHERE survey_id = ?', [$sid]);
            db_run($this->db, 'UPDATE tracer_surveys SET current_is_first_job = NULL, curriculum_relevant = NULL WHERE id = ?', [$sid]);
        }

        db_run($this->db, 'UPDATE tracer_surveys SET employment_state = ?, modified = ? WHERE id = ?', [$new, date('Y-m-d H:i:s'), $sid]);
        return [];
    }

    private function saveCurrentJob($survey, \ArrayAccess $d): array
    {
        $sid = (int) $survey->id;
        $L   = new Lookups();
        $e   = [];

        if (!in_array((int) $d['employment_type_id'], $L->validIds('employment_types'), true)) {
            $e['employment_type_id'] = 'Please choose your employment status.';
        }
        if ($d['job_position'] === '') {
            $e['job_position'] = 'Current occupation is required.';
        }
        if (!in_array((int) $d['industry_id'], $L->validIds('industries'), true)) {
            $e['industry_id'] = 'Please choose a line of business.';
        }
        if (!in_array($d['place_of_work'], ['Local', 'Abroad'], true)) {
            $e['place_of_work'] = 'Please choose Local or Abroad.';
        }
        if (!in_array($d['related_to_degree'], ['0', '1'], true)) {
            $e['related_to_degree'] = 'Please tell us if the job is related to your degree.';
        }
        if (!in_array($d['current_is_first_job'], ['0', '1'], true)) {
            $e['current_is_first_job'] = 'Please tell us if this is your first job.';
        }
        foreach (['job_position' => 150, 'employer' => 150, 'employment_location' => 150] as $f => $max) {
            if (strlen($d[$f]) > $max) {
                $e[$f] = 'Too long (maximum ' . $max . ' characters).';
            }
        }
        if ($d['date_hired'] !== '') {
            $dt = \DateTime::createFromFormat('Y-m-d', $d['date_hired']);
            if (!$dt || $dt->format('Y-m-d') !== $d['date_hired'] || $d['date_hired'] > date('Y-m-d')) {
                $e['date_hired'] = 'Date hired is not a valid past date.';
            }
        }
        if ($e) {
            return $e;
        }

        $tenureName = $this->names('employment_types')[(int) $d['employment_type_id']] ?? '';
        $isFirst    = $d['current_is_first_job'] === '1' ? 1 : 0;
        $industry   = $this->names('industries')[(int) $d['industry_id']] ?? null;

        $current = $this->findRecord($sid, 'current');
        $row = [
            'id'                   => $current['id'] ?? null,
            'alumni_id'            => (int) $survey->alumni_id,
            'survey_id'            => $sid,
            'is_current'           => 1,
            'is_first_job'         => $isFirst,
            'employment_status_id' => $this->statusId($tenureName, (int) $d['related_to_degree']),
            'employment_type_id'   => (int) $d['employment_type_id'],
            'employment_type'      => $this->legacyType($tenureName),
            'job_position'         => $d['job_position'],
            'employer'             => $d['employer'] ?: null,
            'industry_id'          => (int) $d['industry_id'],
            'industry'             => $industry,
            'place_of_work'        => $d['place_of_work'],
            'employment_location'  => $d['employment_location'] ?: null,
            'related_to_degree'    => (int) $d['related_to_degree'],
            'date_hired'           => $d['date_hired'] ?: null,
            'date_ended'           => null,
        ];

        $wasFirst = $current && (int) $current['is_first_job'] === 1;
        if ($wasFirst && !$isFirst) {
            $row['search_method_id'] = null;
            $row['time_to_job_id']   = null;
            $row['duration_id']      = null;
            db_run($this->db, 
                "DELETE l FROM employment_record_reasons l JOIN employment_reasons r ON r.id = l.employment_reason_id
                 WHERE l.employment_record_id = ? AND r.reason_type = 'accept'",
                [$current['id']]
            );
        }

        $recordId = $this->saveRecord($row);

        if ($isFirst) {
            db_run($this->db, 'DELETE FROM employment_records WHERE survey_id = ? AND id <> ? AND is_first_job = 1', [$sid, $recordId]);
        }

        db_run($this->db, 'UPDATE tracer_surveys SET current_is_first_job = ?, modified = ? WHERE id = ?', [$isFirst, date('Y-m-d H:i:s'), $sid]);
        return [];
    }

    private function saveFirstJob($survey, \ArrayAccess $d): array
    {
        $sid    = (int) $survey->id;
        $L      = new Lookups();
        $merged = $survey->employment_state === 'employed' && (string) $survey->current_is_first_job === '1';
        $e      = [];

        if (!in_array((int) $d['duration_id'], $L->validIds('duration_ranges'), true)) {
            $e['duration_id'] = 'Please choose how long you stayed in your first job.';
        }
        $ids = $this->idList($d['accept_reason_ids']);
        if (!$ids || array_diff($ids, $L->validIds('employment_reasons', 'accept'))) {
            $e['accept_reason_ids'] = 'Please select at least one reason for accepting the job.';
        } elseif ($err = $this->otherRequired('employment_reasons', $ids, $d['accept_reason_other'], 'accept_reason_other')) {
            $e += $err;
        }

        if (!$merged) {
            if ($d['first_job_position'] === '') {
                $e['first_job_position'] = 'First job position is required.';
            }
            if (!in_array((int) $d['first_industry_id'], $L->validIds('industries'), true)) {
                $e['first_industry_id'] = 'Please choose the industry of your first job.';
            }
            if (!in_array($d['first_related_to_degree'], ['0', '1'], true)) {
                $e['first_related_to_degree'] = 'Please tell us if your first job was related to your degree.';
            }
            foreach (['first_job_position' => 150, 'first_employer' => 150, 'first_job_location' => 150] as $f => $max) {
                if (strlen($d[$f]) > $max) {
                    $e[$f] = 'Too long (maximum ' . $max . ' characters).';
                }
            }
        }
        if ($e) {
            return $e;
        }

        $first = $this->findRecord($sid, 'first');

        if ($merged) {
            if (!$first) {
                return ['_' => 'Please complete Current Employment first.'];
            }
            $this->saveRecord(['id' => $first['id'], 'duration_id' => (int) $d['duration_id']]);
            $recordId = (int) $first['id'];
        } else {
            $related  = (int) $d['first_related_to_degree'];
            $industry = $this->names('industries')[(int) $d['first_industry_id']] ?? null;
            $recordId = $this->saveRecord([
                'id'                   => $first['id'] ?? null,
                'alumni_id'            => (int) $survey->alumni_id,
                'survey_id'            => $sid,
                'is_current'           => 0,
                'is_first_job'         => 1,
                'employment_status_id' => $this->statusId('', $related),
                'job_position'         => $d['first_job_position'],
                'employer'             => $d['first_employer'] ?: null,
                'industry_id'          => (int) $d['first_industry_id'],
                'industry'             => $industry,
                'employment_location'  => $d['first_job_location'] ?: null,
                'related_to_degree'    => $related,
                'duration_id'          => (int) $d['duration_id'],
            ]);
        }

        $this->replaceRecordReasons($recordId, 'accept', $ids, $d['accept_reason_other']);
        return [];
    }

    private function saveJobSearch($survey, \ArrayAccess $d): array
    {
        $sid        = (int) $survey->id;
        $L          = new Lookups();
        $first      = $this->findRecord($sid, 'first');
        $merged     = $survey->employment_state === 'employed' && (string) $survey->current_is_first_job === '1';
        $needChange = $survey->employment_state === 'employed' && !$merged;
        $e          = [];

        if (!$first) {
            return ['_' => 'Please complete the First Job section first.'];
        }
        if (!in_array((int) $d['search_method_id'], $L->validIds('job_search_methods'), true)) {
            $e['search_method_id'] = 'Please choose how you found your first job.';
        }
        if (!in_array((int) $d['time_to_job_id'], $L->validIds('duration_ranges'), true)) {
            $e['time_to_job_id'] = 'Please choose how long it took to land your first job.';
        }
        $ids = [];
        if ($needChange) {
            $ids = $this->idList($d['change_reason_ids']);
            if (!$ids || array_diff($ids, $L->validIds('employment_reasons', 'change'))) {
                $e['change_reason_ids'] = 'Please select at least one reason for changing jobs.';
            } elseif ($err = $this->otherRequired('employment_reasons', $ids, $d['change_reason_other'], 'change_reason_other')) {
                $e += $err;
            }
        }
        if ($e) {
            return $e;
        }

        $this->saveRecord([
            'id'               => $first['id'],
            'search_method_id' => (int) $d['search_method_id'],
            'time_to_job_id'   => (int) $d['time_to_job_id'],
        ]);

        $current = $this->findRecord($sid, 'current');
        if ($needChange && $current) {
            $this->replaceRecordReasons((int) $current['id'], 'change', $ids, $d['change_reason_other']);
        }
        return [];
    }

    private function saveLevelAndEarnings($survey, \ArrayAccess $d): array
    {
        $sid         = (int) $survey->id;
        $L           = new Lookups();
        $first       = $this->findRecord($sid, 'first');
        $current     = $this->findRecord($sid, 'current');
        $merged      = $survey->employment_state === 'employed' && (string) $survey->current_is_first_job === '1';
        $needCurrent = $survey->employment_state === 'employed' && !$merged;
        $e           = [];

        if (!$first) {
            return ['_' => 'Please complete the First Job section first.'];
        }
        if (!in_array((int) $d['first_job_level_id'], $L->validIds('job_levels'), true)) {
            $e['first_job_level_id'] = 'Please choose the job level of your first job.';
        }
        foreach (['first_salary_range_id', 'current_salary_range_id'] as $f) {
            if ($d[$f] !== '' && !in_array((int) $d[$f], $L->validIds('salary_ranges'), true)) {
                $e[$f] = 'Invalid earnings bracket.';
            }
        }
        if ($needCurrent && !in_array((int) $d['current_job_level_id'], $L->validIds('job_levels'), true)) {
            $e['current_job_level_id'] = 'Please choose your present job level.';
        }
        if ($e) {
            return $e;
        }

        $this->saveRecord([
            'id'              => $first['id'],
            'job_level_id'    => (int) $d['first_job_level_id'],
            'salary_range_id' => $d['first_salary_range_id'] !== '' ? (int) $d['first_salary_range_id'] : null,
        ]);

        if ($needCurrent && $current) {
            $this->saveRecord([
                'id'              => $current['id'],
                'job_level_id'    => (int) $d['current_job_level_id'],
                'salary_range_id' => $d['current_salary_range_id'] !== '' ? (int) $d['current_salary_range_id'] : null,
            ]);
        }
        return [];
    }

    private function links(string $table, string $fk, int $id, string $col, string $refTable): array
    {
        $rows = db_run($this->db, 
            "SELECT l.`$col` AS ref_id, l.other_text FROM `$table` l JOIN `$refTable` r ON r.id = l.`$col`
             WHERE l.`$fk` = ? ORDER BY r.sort_order",
            [$id]
        )->fetchAll();

        $other = '';
        foreach ($rows as $r) {
            if ($r->other_text) {
                $other = $r->other_text;
            }
        }
        return ['ids' => array_map(fn($r) => (int) $r->ref_id, $rows), 'other' => $other];
    }

    private function recordReasons(int $recordId, string $type): array
    {
        $rows = db_run($this->db, 
            'SELECT l.employment_reason_id AS ref_id, l.other_text
             FROM employment_record_reasons l JOIN employment_reasons r ON r.id = l.employment_reason_id
             WHERE l.employment_record_id = ? AND r.reason_type = ? ORDER BY r.sort_order',
            [$recordId, $type]
        )->fetchAll();

        $other = '';
        foreach ($rows as $r) {
            if ($r->other_text) {
                $other = $r->other_text;
            }
        }
        return ['ids' => array_map(fn($r) => (int) $r->ref_id, $rows), 'other' => $other];
    }

    private function replaceLinks(string $table, string $fk, int $id, string $col, string $refTable, array $ids, string $otherText): void
    {
        db_run($this->db, "DELETE FROM `$table` WHERE `$fk` = ?", [$id]);
        $otherIds = array_map(fn($r) => (int) $r->id, db_run($this->db, "SELECT id FROM `$refTable` WHERE is_other = 1")->fetchAll());

        foreach ($ids as $refId) {
            db_run($this->db, 
                "INSERT INTO `$table` (`$fk`, `$col`, other_text) VALUES (?, ?, ?)",
                [$id, $refId, in_array($refId, $otherIds, true) && $otherText !== '' ? $otherText : null]
            );
        }
    }

    private function replaceRecordReasons(int $recordId, string $type, array $ids, string $otherText): void
    {
        db_run($this->db, 
            'DELETE l FROM employment_record_reasons l JOIN employment_reasons r ON r.id = l.employment_reason_id
             WHERE l.employment_record_id = ? AND r.reason_type = ?',
            [$recordId, $type]
        );
        $otherIds = array_map(fn($r) => (int) $r->id,
            db_run($this->db, 'SELECT id FROM employment_reasons WHERE is_other = 1 AND reason_type = ?', [$type])->fetchAll());

        foreach ($ids as $refId) {
            db_run($this->db, 
                'INSERT INTO employment_record_reasons (employment_record_id, employment_reason_id, other_text) VALUES (?, ?, ?)',
                [$recordId, $refId, in_array($refId, $otherIds, true) && $otherText !== '' ? $otherText : null]
            );
        }
    }

    private function saveRecord(array $row): int
    {
        db_save($this->db, 'employment_records', $row);
        return !empty($row['id']) ? (int) $row['id'] : (int) $this->db->lastInsertId();
    }

    private function idList($value): array
    {
        if (!is_array($value)) {
            return [];
        }
        return array_values(array_unique(array_map('intval', array_filter($value, 'is_scalar'))));
    }

    private function otherRequired(string $table, array $ids, string $text, string $field): array
    {
        $other = db_run($this->db, "SELECT id FROM `$table` WHERE is_other = 1")->fetchAll();
        foreach ($other as $o) {
            if (in_array((int) $o->id, $ids, true)) {
                if ($text === '') {
                    return [$field => 'Please specify "Other".'];
                }
                if (strlen($text) > 150) {
                    return [$field => 'Too long (maximum 150 characters).'];
                }
            }
        }
        return [];
    }

    private function aid($surveyId): int
    {
        return (int) db_run($this->db, 'SELECT alumni_id FROM tracer_surveys WHERE id = ?', [$surveyId])->fetchColumn();
    }

    private function statusId(string $tenureName, int $related): int
    {
        $name = $tenureName === 'Self-employed' ? 'Self-Employed'
              : ($related === 1 ? 'Employed - Related to Course' : 'Employed - Not Related to Course');

        return (int) db_run($this->db, 'SELECT id FROM employment_statuses WHERE status_name = ?', [$name])->fetchColumn();
    }

    private function legacyType(string $tenureName): string
    {
        return $tenureName === 'Self-employed' ? 'Self-employed'
             : ($tenureName === 'Contractual' ? 'Contractual' : ($tenureName !== '' ? 'Full-time' : 'N/A'));
    }

    private function names(string $table): array
    {
        if (!isset($this->nameCache[$table])) {
            $map = [];
            foreach (db_run($this->db, "SELECT id, name FROM `$table`")->fetchAll() as $r) {
                $map[(int) $r->id] = $r->name;
            }
            $this->nameCache[$table] = $map;
        }
        return $this->nameCache[$table];
    }

    public function begin(): void
    {
        if (!$this->db->inTransaction()) {
            $this->db->beginTransaction();
        }
    }

    public function commit(): void
    {
        if ($this->db->inTransaction()) {
            $this->db->commit();
        }
    }

    public function rollBack(): void
    {
        if ($this->db->inTransaction()) {
            $this->db->rollBack();
        }
    }
}
