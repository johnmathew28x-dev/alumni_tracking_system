<?php

namespace Models;

use Core\Model;

class Reference extends Model
{
    public const TABLES = [
        'programs'             => 'Programs',
        'departments'          => 'Departments',
        'industries'           => 'Industries (major line of business)',
        'employment_types'     => 'Employment Types',
        'job_levels'           => 'Job Levels',
        'salary_ranges'        => 'Salary Ranges',
        'job_search_methods'   => 'Job Search Methods',
        'duration_ranges'      => 'Duration Ranges',
        'course_reasons'       => 'Reasons for Taking the Course',
        'employment_reasons'   => 'Reasons for Accepting / Changing a Job',
        'unemployment_reasons' => 'Reasons for Not Being Employed',
        'competencies'         => 'Competencies',
        'civil_statuses'       => 'Civil Statuses',
        'residence_types'      => 'Residence Types',
        'regions'              => 'Regions',
    ];

    public function valid(string $table): bool
    {
        return isset(self::TABLES[$table]);
    }

    public function all(string $table): array
    {
        if ($table === 'programs') {
            return db_run($this->db, 
                'SELECT p.id, 
                        p.program_code, 
                        p.program_name, 
                        p.department_id, 
                        d.department_name,
                        (SELECT COUNT(*) FROM alumni_academic aa WHERE aa.program_id = p.id) AS in_use
                 FROM programs p 
                 JOIN departments d ON d.id = p.department_id 
                 ORDER BY p.program_name'
            )->fetchAll();
        }

        if ($table === 'departments') {
            return db_run($this->db, 
                'SELECT d.id, 
                        d.department_name,
                        (SELECT COUNT(*) FROM programs p WHERE p.department_id = d.id) AS in_use
                 FROM departments d 
                 ORDER BY d.department_name'
            )->fetchAll();
        }

        $orderBy = ($table === 'employment_reasons' ? 'reason_type, ' : '') . 'sort_order, name';

        return db_run($this->db, "SELECT * FROM `$table` ORDER BY $orderBy")->fetchAll();
    }

    public function find(string $table, int$id): ?object
    {
        return db_run($this->db, "SELECT * FROM `$table` WHERE id = ?", [$id])->fetch() ?: null;
    }

    public function duplicate(string $table, array$data, int $ignoreId = 0): bool
    {
        if ($table === 'programs') {$sql = 'SELECT COUNT(*) FROM programs WHERE program_code = ? AND id <> ?';
            $params = [$data['program_code'], $ignoreId];
        } elseif ($table === 'departments') {$sql = 'SELECT COUNT(*) FROM departments WHERE department_name = ? AND id <> ?';
            $params = [$data['department_name'], $ignoreId];
        } elseif ($table === 'employment_reasons') {$sql = 'SELECT COUNT(*) FROM employment_reasons WHERE name = ? AND reason_type = ? AND id <> ?';
            $params = [$data['name'],$data['reason_type'], $ignoreId];
        } else {
            $sql = "SELECT COUNT(*) FROM `$table` WHERE name = ? AND id <> ?";
            $params = [$data['name'], $ignoreId];
        }

        return (int) db_run($this->db, $sql,$params)->fetchColumn() > 0;
    }

    public function save(string $table, array$data): bool
    {
        $allowed = match ($table) {
            'programs'           => ['id', 'program_code', 'program_name', 'department_id'],
            'departments'        => ['id', 'department_name'],
            'employment_reasons' => ['id', 'reason_type', 'name', 'sort_order', 'is_other', 'is_active'],
            default              => ['id', 'name', 'sort_order', 'is_other', 'is_active'],
        };

        $data = array_intersect_key($data, array_flip($allowed));

        if (in_array($table, ['programs', 'departments'], true)) {
            return (bool) db_save($this->db, $table,$data);
        }

        $id =$data['id'] ?? null;
        unset($data['id']);

        if ($id) {
            $set = implode(', ', array_map(fn($c) => "`$c` = ?", array_keys($data)));
            return db_run($this->db, "UPDATE `$table` SET $set WHERE id = ?", [...array_values($data),$id])->rowCount() >= 0;
        }

        $cols  = implode(', ', array_map(fn($c) => "`$c`", array_keys($data)));
        $marks = implode(', ', array_fill(0, count($data), '?'));

        db_run($this->db, "INSERT INTO `$table` ($cols) VALUES ($marks)", array_values($data));

        return true;
    }

    public function setActive(string $table, int $id, int$active): void
    {
        db_run($this->db, "UPDATE `$table` SET is_active = ? WHERE id = ?", [$active,$id]);
    }

    public function delete(string $table, int$id): ?string
    {
        $row =$this->find($table,$id);

        if (!$row) {
            return 'Record not found.';
        }

        if ($table === 'programs' && (int) db_run($this->db, 'SELECT COUNT(*) FROM alumni_academic WHERE program_id = ?', [$id])->fetchColumn() > 0) {
            return 'This program is used by alumni records. Reassign those alumni first.';
        }

        if ($table === 'departments' && (int) db_run($this->db, 'SELECT COUNT(*) FROM programs WHERE department_id = ?', [$id])->fetchColumn() > 0) {
            return 'This department still has programs. Move or delete them first.';
        }

        db_run($this->db, "DELETE FROM `$table` WHERE id = ?", [$id]);

        return null;
    }
}