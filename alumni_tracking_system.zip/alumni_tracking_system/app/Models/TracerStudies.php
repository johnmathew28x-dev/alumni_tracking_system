<?php

namespace Models;

use Core\Model;

class TracerStudies extends Model
{
    public function find(): array
    {
        return db_run($this->db, 
            'SELECT ts.id, ts.title, ts.description, ts.start_date, ts.end_date, ts.status, ts.survey_year, ts.survey_type,
                    u.username AS created_by_name,
                    CASE WHEN ts.survey_type = \'gts\'
                         THEN (SELECT COUNT(*) FROM tracer_surveys sv WHERE sv.tracer_study_id = ts.id AND sv.status = \'submitted\')
                         ELSE (SELECT COUNT(DISTINCT r.alumni_id) FROM tracer_responses r WHERE r.tracer_study_id = ts.id)
                    END AS respondents,
                    (SELECT COUNT(*) FROM tracer_surveys sv WHERE sv.tracer_study_id = ts.id AND sv.status = \'draft\') AS drafts,
                    (SELECT COUNT(*) FROM tracer_questions q WHERE q.tracer_study_id = ts.id) AS question_count
             FROM tracer_studies ts
             JOIN users u ON u.id = ts.created_by
             ORDER BY ts.created DESC'
        )->fetchAll();
    }

    public function active(?int $alumniId = null): array
    {
        return db_run($this->db, 
            "SELECT ts.id, ts.title, ts.description, ts.start_date, ts.end_date, ts.survey_type, ts.survey_year,
                    ((SELECT COUNT(*) FROM tracer_responses r
                       WHERE r.tracer_study_id = ts.id AND r.alumni_id = ?) > 0
                     OR (SELECT COUNT(*) FROM tracer_surveys sv
                          WHERE sv.tracer_study_id = ts.id AND sv.alumni_id = ? AND sv.status = 'submitted') > 0) AS answered,
                    (SELECT COUNT(*) FROM tracer_surveys sv
                      WHERE sv.tracer_study_id = ts.id AND sv.alumni_id = ? AND sv.status = 'draft') > 0 AS in_progress
             FROM tracer_studies ts
             WHERE ts.status = 'active'
             ORDER BY ts.start_date DESC",
            [(int) $alumniId, (int) $alumniId, (int) $alumniId]
        )->fetchAll();
    }

    public function findByID(int $id): ?object
    {
        return db_run($this->db, 
            'SELECT id, title, description, start_date, end_date, status, survey_year, survey_type 
             FROM tracer_studies 
             WHERE id = ?',
            [$id]
        )->fetch() ?: null;
    }

    public function save(array $data)
    {
        $allowed = ['id', 'title', 'description', 'start_date', 'end_date', 'status', 'created_by', 'survey_year', 'survey_type'];

        return db_save($this->db, 'tracer_studies', array_intersect_key($data, array_flip($allowed)));
    }

    public function setStatus(int $id, string $status): bool
    {
        return db_run($this->db, 
            'UPDATE tracer_studies SET status = ?, modified = ? WHERE id = ?',
            [$status, date('Y-m-d H:i:s'), $id]
        )->rowCount() > 0;
    }

    public function delete(int $id): bool
    {
        return db_run($this->db, 'DELETE FROM tracer_studies WHERE id = ?', [$id])->rowCount() > 0;
    }
}