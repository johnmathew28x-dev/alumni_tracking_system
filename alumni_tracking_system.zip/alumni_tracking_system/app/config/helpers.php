<?php

function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function str_limit($text, int $max, string $suffix = '…'): string
{
    $text = (string) $text;

    if (function_exists('mb_strlen')) {
        return mb_strlen($text) > $max ? mb_substr($text, 0, $max) . $suffix : $text;
    }

    return strlen($text) > $max ? substr($text, 0, $max) . $suffix : $text;
}

function avatar_url($file): string
{
    $file = (string) $file;

    if ($file !== '' && preg_match('/^[A-Za-z0-9_.-]+$/', $file) && is_file(PROFILE_UPLOAD_DIR . '/' . $file)) {
        return BASE_URL . '/uploads/profile/' . rawurlencode($file) . '?v=' . filemtime(PROFILE_UPLOAD_DIR . '/' . $file);
    }

    return BASE_URL . '/img/default-avatar.svg';
}

function db_run(PDO $db, string $sql, array $params = []): PDOStatement
{
    $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    $stmt = $db->prepare($sql);
    $stmt->execute($params);

    return $stmt;
}

function db_save(PDO $db, string $table, array $data): bool
{
    $now = date('Y-m-d H:i:s');
    $id  = $data['id'] ?? null;
    unset($data['id']);

    if (!empty($id)) {
        $data['modified'] = $now;
        $set = implode(', ', array_map(fn($c) => "`$c` = ?", array_keys($data)));

        return db_run($db, "UPDATE `$table` SET $set WHERE id = ?", [...array_values($data), $id])->rowCount() >= 0;
    }

    $data['created']  = $now;
    $data['modified'] = $now;
    $cols  = implode(', ', array_map(fn($c) => "`$c`", array_keys($data)));
    $marks = implode(', ', array_fill(0, count($data), '?'));

    return db_run($db, "INSERT INTO `$table` ($cols) VALUES ($marks)", array_values($data))->rowCount() >= 0;
}

function auth_bearer_token(?string $header): ?string
{
    if (is_string($header) && preg_match('/^Bearer\s+([A-Za-z0-9]{32,128})$/i', trim($header), $m)) {
        return $m[1];
    }

    return null;
}

function auth_header(): string
{
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';

    return is_string($h) ? $h : '';
}

function auth_has_bearer(): bool
{
    return stripos(ltrim(auth_header()), 'Bearer ') === 0;
}

function auth_token_state(): array
{
    static $state = null;

    if ($state === null) {
        $state = ['user' => null, 'id' => null];
        $raw = auth_bearer_token(auth_header());

        if ($raw !== null) {
            try {
                $row = (new \Models\ApiTokens())->resolve($raw);
            } catch (\Throwable $e) {
                error_log('token resolve failed: ' . $e->getMessage());
                $row = null;
            }

            if ($row) {
                $state = [
                    'user' => [
                        'id'       => (int) $row['user_id'],
                        'username' => $row['username'],
                        'role'     => $row['role'],
                    ],
                    'id'   => (int) $row['token_id'],
                ];
            }
        }
    }

    return $state;
}

function auth_via_token(): bool
{
    return auth_has_bearer() && auth_token_state()['user'] !== null;
}

function auth_token_id(): ?int
{
    return auth_via_token() ? auth_token_state()['id'] : null;
}

function auth_user()
{
    if (auth_has_bearer()) {
        return auth_token_state()['user'];
    }

    return $_SESSION['user'] ?? null;
}

function auth_check(): bool
{
    return !empty(auth_user());
}

function auth_require_login(): void
{
    if (!auth_check()) {
        header('Location: ' . BASE_URL . '/Auth');
        exit;
    }
}

function user_id(): ?int
{
    return auth_user()['id'] ?? null;
}

function user_role(): ?string
{
    return auth_user()['role'] ?? null;
}

function has_role(string ...$roles): bool
{
    return auth_check() && in_array(user_role(), $roles, true);
}

function require_role(string ...$roles): void
{
    auth_require_login();

    if (!has_role(...$roles)) {
        http_response_code(403);
        exit('Forbidden');
    }
}

function login_user(array $user): void
{
    session_regenerate_id(true);

    $_SESSION['user'] = [
        'id'       => (int) $user['id'],
        'username' => $user['username'],
        'role'     => $user['role'],
    ];
}

function is_post(): bool
{
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function csrf_valid(?string $token): bool
{
    return $token && hash_equals(csrf_token(), $token);
}

function verify_csrf(): void
{
    $token = $_POST['_csrfToken'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');

    if (!csrf_valid($token)) {
        http_response_code(419);
        exit('Your session has expired or the request was invalid. Please go back and try again.');
    }
}

function audit(string $action, string $description = '', ?string $module = null, ?int $recordId = null): void
{
    try {
        (new Models\AuditLogs())->log(user_id(), $action, $description, $module, $recordId);
    } catch (Throwable $e) {
        error_log('audit failed: ' . $e->getMessage());
    }
}

function api_deny(int $code, string $message): void
{
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => $message]);
    exit;
}

function api_guard(array $roles = []): void
{
    if (!auth_check()) {
        api_deny(401, 'Your session has expired. Please log in again.');
    }

    if ($roles && !has_role(...$roles)) {
        api_deny(403, 'You are not authorized to perform this action.');
    }

    if (!auth_via_token() && !in_array($_SERVER['REQUEST_METHOD'], ['GET', 'HEAD', 'OPTIONS'], true)) {
        $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['_csrfToken'] ?? '');

        if (!csrf_valid($token)) {
            api_deny(419, 'Your session has expired. Please refresh the page and try again.');
        }
    }
}

function api_allow(string ...$roles): void
{
    if (!has_role(...$roles)) {
        api_deny(403, 'You are not authorized to perform this action.');
    }
}

function api_success(string $message, array $extra = []): array
{
    return array_merge(['status' => 'success', 'success' => true, 'message' => $message], $extra);
}

function api_error(string $message, array $errors = []): array
{
    return ['status' => 'error', 'success' => false, 'message' => $message, 'errors' => (object) $errors];
}

function input(): ArrayAccess
{
    return new class(array_map(fn($v) => is_string($v) ? trim($v) : $v, $_POST)) implements ArrayAccess {
        public function __construct(private array $data) {}

        public function offsetExists(mixed $key): bool
        {
            return isset($this->data[$key]);
        }

        public function offsetGet(mixed $key): mixed
        {
            return $this->data[$key] ?? '';
        }

        public function offsetSet(mixed $key, mixed $value): void
        {
            $this->data[$key] = $value;
        }

        public function offsetUnset(mixed $key): void
        {
            unset($this->data[$key]);
        }
    };
}

function current_alumni_id(): ?int
{
    $alumni = (new Models\Alumni())->findByUserID(user_id());

    return $alumni ? (int) $alumni->id : null;
}

function require_alumni_id(): int
{
    $id = current_alumni_id();

    if (!$id) {
        header('Content-Type: application/json');
        echo json_encode(api_error('Your alumni profile could not be found. Please contact the administrator.'));
        exit;
    }

    return $id;
}

function profile_image_store(?array $file, string $prefix): array
{
    $types = [
        'image/jpeg' => ['jpg',  ['jpg', 'jpeg']],
        'image/png'  => ['png',  ['png']],
        'image/webp' => ['webp', ['webp']],
    ];
    $fail = fn(string $m): array => ['file' => null, 'error' => $m];

    if (!is_array($file) || is_array($file['error'] ?? null)) {
        return $fail('Please choose an image to upload. (If you did, it may be larger than the server allows.)');
    }

    $upload = [
        UPLOAD_ERR_INI_SIZE   => 'The image is larger than the server allows (limit 2 MB).',
        UPLOAD_ERR_FORM_SIZE  => 'The image is larger than the allowed size (limit 2 MB).',
        UPLOAD_ERR_PARTIAL    => 'The upload was interrupted. Please try again.',
        UPLOAD_ERR_NO_FILE    => 'Please choose an image to upload.',
        UPLOAD_ERR_NO_TMP_DIR => 'The server has no temporary folder for uploads.',
        UPLOAD_ERR_CANT_WRITE => 'The server could not save the upload.',
        UPLOAD_ERR_EXTENSION  => 'The upload was blocked by a server extension.',
    ];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return $fail($upload[$file['error']] ?? 'The upload failed. Please try again.');
    }

    $tmp = $file['tmp_name'];

    if (!is_uploaded_file($tmp)) {
        return $fail('Invalid upload.');
    }

    if ($file['size'] <= 0 || $file['size'] > PROFILE_UPLOAD_MAX_BYTES || filesize($tmp) > PROFILE_UPLOAD_MAX_BYTES) {
        return $fail('The image must be 2 MB or smaller.');
    }

    $ext    = strtolower(pathinfo((string) $file['name'], PATHINFO_EXTENSION));
    $allExt = array_merge(...array_column($types, 1));

    if (!in_array($ext, $allExt, true)) {
        return $fail('Only JPG, JPEG, PNG or WEBP images are allowed.');
    }

    $mime = function_exists('finfo_open') ? (new finfo(FILEINFO_MIME_TYPE))->file($tmp) : null;
    $info = @getimagesize($tmp);

    if (!$info || empty($info['mime'])) {
        return $fail('The selected file is not a valid image.');
    }

    $mime = $mime ?: $info['mime'];

    if (!isset($types[$mime]) || $info['mime'] !== $mime) {
        return $fail('Only JPG, JPEG, PNG or WEBP images are allowed.');
    }

    if (!in_array($ext, $types[$mime][1], true)) {
        return $fail('The file extension does not match the image type.');
    }

    if ($info[0] < 1 || $info[1] < 1 || $info[0] > 12000 || $info[1] > 12000) {
        return $fail('The image dimensions are not supported.');
    }

    if (!is_dir(PROFILE_UPLOAD_DIR) && !@mkdir(PROFILE_UPLOAD_DIR, 0755, true)) {
        error_log('Profile upload folder cannot be created: ' . PROFILE_UPLOAD_DIR);
        return $fail('The upload folder is not available. Please contact the administrator.');
    }

    $name = preg_replace('/[^A-Za-z0-9_-]/', '', $prefix) . '_' . bin2hex(random_bytes(12)) . '.' . $types[$mime][0];
    $dest = PROFILE_UPLOAD_DIR . '/' . $name;

    $result = profile_image_reencode($tmp, $mime, $dest);

    if ($result === 'invalid') {
        return $fail('The selected file is not a valid image.');
    }

    if ($result === 'unsupported' && !move_uploaded_file($tmp, $dest)) {
        return $fail('Unable to save the image. Please try again.');
    }

    if (!is_file($dest)) {
        return $fail('Unable to save the image. Please try again.');
    }

    @chmod($dest, 0644);

    return ['file' => $name, 'error' => null];
}

function profile_image_reencode(string $src, string $mime, string $dest): string
{
    $maxSide = 1024;
    $create  = [
        'image/jpeg' => 'imagecreatefromjpeg',
        'image/png'  => 'imagecreatefrompng',
        'image/webp' => 'imagecreatefromwebp',
    ];

    if (!function_exists('imagecreatetruecolor') || !function_exists($create[$mime])) {
        return 'unsupported';
    }

    $img = @$create[$mime]($src);

    if (!$img) {
        return 'invalid';
    }

    if (function_exists('imagepalettetotruecolor')) {
        imagepalettetotruecolor($img);
    }

    if ($mime === 'image/jpeg' && function_exists('exif_read_data') && function_exists('imagerotate')) {
        $exif  = @exif_read_data($src);
        $angle = [3 => 180, 6 => -90, 8 => 90][$exif['Orientation'] ?? 1] ?? 0;

        if ($angle && ($rotated = imagerotate($img, $angle, 0))) {
            unset($img);
            $img = $rotated;
        }
    }

    $w = imagesx($img);
    $h = imagesy($img);

    if (max($w, $h) > $maxSide) {
        $scale = $maxSide / max($w, $h);
        $nw = max(1, (int) round($w * $scale));
        $nh = max(1, (int) round($h * $scale));

        $copy = imagecreatetruecolor($nw, $nh);
        imagealphablending($copy, false);
        imagesavealpha($copy, true);
        imagefill($copy, 0, 0, imagecolorallocatealpha($copy, 0, 0, 0, 127));
        imagecopyresampled($copy, $img, 0, 0, 0, 0, $nw, $nh, $w, $h);
        unset($img);
        $img = $copy;
    }

    imagesavealpha($img, true);

    switch ($mime) {
        case 'image/jpeg':
            $ok = imagejpeg($img, $dest, 88);
            break;
        case 'image/png':
            $ok = imagepng($img, $dest, 6);
            break;
        default:
            $ok = function_exists('imagewebp') ? imagewebp($img, $dest, 85) : false;
    }

    unset($img);

    if (!$ok) {
        @unlink($dest);
        return 'unsupported';
    }

    return 'ok';
}

function profile_image_delete(?string $file, ?string $keep = null): void
{
    if (!$file || $file === $keep || !preg_match('/^[A-Za-z0-9_.-]+$/', $file)) {
        return;
    }

    $path = PROFILE_UPLOAD_DIR . '/' . $file;

    if (is_file($path)) {
        @unlink($path);
    }
}

function attach_avatar(iterable $rows, string $field = 'profile_picture'): void
{
    foreach ($rows as $row) {
        $row->picture_url = avatar_url($row->$field ?? null);
        unset($row->$field);
    }
}
