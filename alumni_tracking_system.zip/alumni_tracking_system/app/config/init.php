<?php

ini_set('display_errors', '0');
ini_set('log_errors', '1');

date_default_timezone_set('Asia/Manila');

$https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';

session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'secure'   => $https,
    'httponly' => true,
    'samesite' => 'Lax',
]);
$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
if (is_string($authHeader) && stripos(ltrim($authHeader), 'Bearer ') === 0) {
    $_SESSION = [];
} else {
    session_start();
}
unset($authHeader);

define('BASE_PATH', dirname(__DIR__));
define('PUBLIC_PATH', dirname(BASE_PATH) . '/public');

$scheme   = $https ? 'https' : 'http';
$basePath = rtrim(str_replace('\\', '/', dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '/public/index.php'))), '/');
define('BASE_URL', $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $basePath);

define('APP_NAME', 'COE Alumni Portal');
define('APP_FULL_NAME', 'Northeastern College - Alumni Tracking System');

define('DB_HOST', 'localhost');
define('DB_NAME', 'alumni_tracking_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

define('PROFILE_UPLOAD_DIR', PUBLIC_PATH . '/uploads/profile');
define('PROFILE_UPLOAD_MAX_BYTES', 2 * 1024 * 1024);

$aiLocal = __DIR__ . '/ai.local.php';
if (is_file($aiLocal)) {
    require $aiLocal;
}

$aiEnv = function (string $key, string $default = ''): string {
    $value = getenv($key);

    if ($value === false || $value === '') {
        $value = $_SERVER[$key] ?? '';
    }

    return is_string($value) && $value !== '' ? $value : $default;
};

defined('AI_ENABLED')             || define('AI_ENABLED', filter_var($aiEnv('AI_ENABLED', '1'), FILTER_VALIDATE_BOOLEAN));
defined('AI_MAX_QUESTION_CHARS')  || define('AI_MAX_QUESTION_CHARS', (int) $aiEnv('AI_MAX_QUESTION_CHARS', '500'));
defined('AI_MIN_GROUP_SIZE')      || define('AI_MIN_GROUP_SIZE', (int) $aiEnv('AI_MIN_GROUP_SIZE', '5'));
defined('AI_RATE_LIMIT_PER_HOUR') || define('AI_RATE_LIMIT_PER_HOUR', (int) $aiEnv('AI_RATE_LIMIT_PER_HOUR', '10'));
defined('AI_COOLDOWN_SECONDS')    || define('AI_COOLDOWN_SECONDS', (int) $aiEnv('AI_COOLDOWN_SECONDS', '5'));

unset($aiLocal, $aiEnv);

require __DIR__ . '/helpers.php';
