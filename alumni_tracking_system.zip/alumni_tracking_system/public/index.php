<?php

require __DIR__ . '/../app/config/init.php';
require __DIR__ . '/../app/autoload.php';

use Core\Router;

$router = new Router();
$router->dispatch();
