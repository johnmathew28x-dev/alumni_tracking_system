$(function () {
    CrudModule({
        api: 'Announcements',
        noun: 'announcement',
        table: '#announcements-table',
        form: '#announcements-form',
        modal: '#announcements-modal',
        order: [[3, 'desc']],
        columns: [
            { 
                data: 'title', 
                title: 'Title' 
            },
            { 
                data: 'content', 
                title: 'Content', 
                render: function (data) { 
                    return Fmt.truncate(data, 80); 
                } 
            },
            { 
                data: 'status', 
                title: 'Status', 
                render: function (data) { 
                    return Fmt.badge(data, StatusColors); 
                } 
            },
            { 
                data: 'created', 
                title: 'Created', 
                render: function (data, type) { 
                    return type === 'display' ? Fmt.date(data) : data; 
                } 
            },
            { 
                data: 'created_by_name', 
                title: 'By' 
            }
        ],
        actions: [{
            key: 'toggle',
            color: 'success',
            icon: function (row) { 
                return row.status === 'published' ? 'fa-eye-slash' : 'fa-bullhorn'; 
            },
            title: function (row) { 
                return row.status === 'published' ? 'Unpublish' : 'Publish'; 
            },
            url: function (row) { 
                return 'Announcements/toggle/' + row.id; 
            }
        }]
    }).init();
});