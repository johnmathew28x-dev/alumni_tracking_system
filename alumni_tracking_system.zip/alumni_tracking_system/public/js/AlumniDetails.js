$(function () {
    $('.verify-btn').on('click', function () {
        const status = $(this).data('status');
        const id = window.PAGE.alumniId;
        const isVerified = status === 'verified';

        confirmAction(
            {
                title: (isVerified ? 'Verify' : 'Reject') + ' this alumni?',
                confirmText: isVerified ? 'Yes, verify' : 'Yes, reject',
                color: isVerified ? '#28a745' : '#d33'
            },
            'POST',
            'Alumni/verify/' + id,
            { status: status },
            function () {
                setTimeout(function () {
                    window.location.reload();
                }, 600);
            }
        );
    });
});