$(function () {
    const $table = $('#corrections-table');
    if (!$table.length) {
        return;
    }

    let current = null;

    const colors = { pending: 'warning', approved: 'success', rejected: 'danger' };

    function changesHtml(row) {
        let html = '<table class="table table-sm table-bordered mb-2"><thead><tr><th>Field</th><th>Current</th><th>Requested</th></tr></thead><tbody>';
        row.change_list.forEach(function (c) {
            html += '<tr' + (c.sensitive ? ' class="table-warning"' : '') + '>' +
                '<td>' + Fmt.esc(c.label) + (c.sensitive ? ' <i class="fas fa-exclamation-triangle text-warning" title="Identity-related field: review carefully"></i>' : '') + '</td>' +
                '<td>' + Fmt.dash(c.old) + '</td>' +
                '<td><strong>' + Fmt.dash(c.new) + '</strong></td></tr>';
        });
        return html + '</tbody></table>';
    }

    const dt = $table.DataTable({
        ajax: {
            url: BASE_URL + '/Api/Alumni/corrections',
            data: function (d) { d.status = $('#corr-status').val(); },
            dataSrc: 'data'
        },
        responsive: true,
        order: [],
        columns: [
            { data: 'created', title: 'Filed', render: function (d) { return Fmt.date ? Fmt.date(d) : Fmt.esc(d); } },
            {
                data: null, title: 'Alumnus',
                render: function (d, t, row) {
                    return Fmt.esc(row.last_name + ', ' + row.first_name) + '<div class="small text-muted">' + Fmt.esc(row.alumni_number) + '</div>';
                }
            },
            { data: null, title: 'Requested changes', orderable: false, render: function (d, t, row) { return changesHtml(row); } },
            { data: 'reason', title: 'Reason', render: function (d) { return Fmt.truncate(d, 80); } },
            { data: 'status', title: 'Status', render: function (d) { return Fmt.badge(d, colors); } },
            {
                data: null, title: 'Action', orderable: false,
                render: function (d, t, row) {
                    return row.status === 'pending'
                        ? '<button type="button" class="btn btn-sm btn-primary js-review" data-id="' + Number(row.id) + '"><i class="fas fa-search"></i> Review</button>'
                        : '<span class="small text-muted">' + Fmt.esc(row.reviewer || '') + '</span>';
                }
            }
        ]
    });

    $('#corr-status').on('change', function () { dt.ajax.reload(); });

    $table.on('click', '.js-review', function () {
        const id = Number($(this).data('id'));
        current = dt.rows().data().toArray().find(function (r) { return Number(r.id) === id; });
        if (!current) { return; }

        $('#corr-summary').text(current.last_name + ', ' + current.first_name + ' (' + current.alumni_number + ')');
        $('#corr-changes').html(changesHtml(current));
        $('#corr-reason').text(current.reason);
        $('#corr-note').val('');
        $('#correction-review-modal').modal('show');
    });

    function send(action, confirmText) {
        if (!current) { return; }

        const note = $.trim($('#corr-note').val() || '');
        if (action === 'rejectCorrection' && note.length < 3) {
            msgBox('error', 'Please enter the reason for rejecting this request.');
            $('#corr-note').trigger('focus');
            return;
        }

        Swal.fire({
            title: confirmText,
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#0b3d91'
        }).then(function (result) {
            if (!result.isConfirmed) { return; }

            apiRequest('POST', 'Alumni/' + action + '/' + Number(current.id), { review_note: note }, function () {
                $('#correction-review-modal').modal('hide');
                dt.ajax.reload();
            });
        });
    }

    $('#corr-approve').on('click', function () { send('approveCorrection', 'Approve and apply this correction?'); });
    $('#corr-reject').on('click', function () { send('rejectCorrection', 'Reject this correction request?'); });
});
