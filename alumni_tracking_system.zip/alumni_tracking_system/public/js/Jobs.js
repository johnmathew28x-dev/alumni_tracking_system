$(function () {
    CrudModule({
        api: 'Jobs',
        noun: 'job posting',
        table: '#jobs-table',
        form: '#jobs-form',
        modal: '#jobs-modal',
        order: [[0, 'asc']],
        columns: [
            {
                data: 'job_title',
                title: 'Job Title'
            },
            {
                data: 'company',
                title: 'Company'
            },
            {
                data: 'location',
                title: 'Location',
                render: function (d) {
                    return Fmt.dash(d);
                }
            },
            {
                data: 'deadline',
                title: 'Deadline',
                render: function (d, t) {
                    return t === 'display' ? Fmt.date(d) : d;
                }
            },
            {
                data: 'status',
                title: 'Status',
                render: function (d) {
                    return Fmt.badge(d, StatusColors);
                }
            }
        ],
        actions: [
            {
                key: 'toggle',
                color: 'secondary',
                icon: function (row) {
                    return row.status === 'open' ? 'fa-lock' : 'fa-lock-open';
                },
                title: function (row) {
                    return row.status === 'open' ? 'Close posting' : 'Re-open posting';
                },
                url: function (row) {
                    return 'Jobs/toggle/' + row.id;
                }
            }
        ]
    }).init();
});