$(function () {
    const states = { 
        employed: 'Employed', 
        not_employed: 'Not employed', 
        never_employed: 'Never employed' 
    };

    function params() { 
        return $('#resp-filter').serialize(); 
    }

    const dt = ListTable('#resp-table', 'Gts/responses', [
        { 
            data: 'alumni_no', 
            title: 'Alumni ID' 
        },
        { 
            data: 'name', 
            title: 'Name', 
            render: function (d, t, r) { 
                return t === 'display' ? Fmt.person(d, r.picture_url) : d; 
            } 
        },
        { 
            data: 'program_code', 
            title: 'Program', 
            render: function (d) { 
                return Fmt.dash(d); 
            } 
        },
        { 
            data: 'graduation_year', 
            title: 'Grad. Year', 
            render: function (d) { 
                return Fmt.dash(d); 
            } 
        },
        { 
            data: 'survey_year', 
            title: 'Survey', 
            render: function (d) { 
                return Fmt.dash(d); 
            } 
        },
        { 
            data: 'employment_state', 
            title: 'Employment', 
            render: function (d) { 
                return d ? Fmt.esc(states[d]) : Fmt.dash(null); 
            } 
        },
        { 
            data: 'status', 
            title: 'Status', 
            render: function (d, t, r) {
                const statusBadge = Fmt.badge(d === 'draft' ? 'in progress' : d, { 
                    'in progress': 'warning', 
                    submitted: 'success' 
                });
                const editBadge = Number(r.allow_resubmission) === 1 
                    ? ' <span class="badge badge-info">Edit allowed</span>' 
                    : '';

                return statusBadge + editBadge;
            } 
        },
        { 
            data: 'submitted_at', 
            title: 'Submitted', 
            render: function (d, t) { 
                return t === 'display' ? Fmt.datetime(d) : d; 
            } 
        },
        { 
            data: null, 
            title: 'Options', 
            orderable: false, 
            className: 'text-nowrap', 
            render: function (d, t, r) {
                const viewBtn = '<button class="btn btn-sm btn-outline-primary mr-1 resp-view" data-id="' + r.id + '" title="View"><i class="fas fa-eye"></i></button>';
                const reopenBtn = r.status === 'submitted' 
                    ? '<button class="btn btn-sm btn-outline-warning resp-reopen" data-id="' + r.id + '" title="Allow resubmission"><i class="fas fa-unlock"></i></button>' 
                    : '';

                return viewBtn + reopenBtn;
            } 
        }
    ], { 
        order: [[7, 'desc']] 
    });

    $('#resp-filter').on('submit', function (e) {
        e.preventDefault();
        dt.ajax.url(BASE_URL + '/Api/Gts/responses?' + params()).load();
    });

    if (PAGE.studyId) {
        $('#resp-filter [name="study_id"]').val(PAGE.studyId);
        dt.ajax.url(BASE_URL + '/Api/Gts/responses?' + params()).load();
    }

    $('#resp-table').on('click', '.resp-view', function () {
        const responseId = $(this).data('id');

        $.getJSON(BASE_URL + '/Api/Gts/detail/' + responseId)
            .done(function (res) {
                const row = dt.row($(this).closest('tr')).data() || {};
                let html = row.name ? '<div class="mb-3">' + Fmt.person(row.name, row.picture_url) + '</div>' : '';
                html += res.missing.length 
                    ? '<div class="alert alert-warning small"><strong>Incomplete:</strong> ' + res.missing.map(Fmt.esc).join(' ') + '</div>' 
                    : '';

                html += res.sections.map(function (sec) {
                    const rowsHtml = sec.rows.map(function (r) {
                        const valueHtml = r[1] === '' ? '&mdash;' : Fmt.esc(r[1]);
                        return '<tr><td class="text-muted" style="width:35%">' + Fmt.esc(r[0]) + '</td><td>' + valueHtml + '</td></tr>';
                    }).join('');

                    return '<h6 class="text-primary mt-3">' + Fmt.esc(sec.title) + '</h6>' +
                        '<table class="table table-sm table-borderless mb-0"><tbody>' + 
                        rowsHtml + 
                        '</tbody></table>';
                }).join('');

                $('#resp-body').html(html);
                $('#resp-modal').modal('show');
            })
            .fail(handleAjaxError);
    });

    $('#resp-table').on('click', '.resp-reopen', function () {
        const responseId = $(this).data('id');
        const confirmConfig = { 
            title: 'Allow this alumnus to edit and resubmit?', 
            text: 'The survey returns to "in progress" status.' 
        };

        confirmAction(
            confirmConfig, 
            'POST', 
            'Gts/allowResubmission/' + responseId, 
            {}, 
            function () { 
                dt.ajax.reload(null, false); 
            }
        );
    });
});