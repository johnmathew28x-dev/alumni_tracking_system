$(function () {
    CrudModule({
        api: 'Licensures',
        noun: 'licensure',
        table: '#licensures-table',
        form: '#licensures-form',
        modal: '#licensures-modal',
        addButton: '#add-licensure',
        order: [[2, 'desc']],
        columns: [
            {
                data: 'license_name',
                title: 'License'
            },
            {
                data: 'status_name',
                title: 'Status',
                render: function (d) {
                    return Fmt.badge(d, {
                        Passed: 'success',
                        Failed: 'danger',
                        'For Retake': 'warning',
                        'Not Taken': 'secondary'
                    });
                }
            },
            {
                data: 'examination_year',
                title: 'Exam Year',
                render: function (d) {
                    return Fmt.dash(d);
                }
            }
        ]
    }).init();
});
