$(function () {
    const studyId = PAGE.studyId;
    const sections = PAGE.sections;
    const editable = !!PAGE.editable;
    let data = PAGE.data;
    let current = 1;
    const dirty = {};

    const $form = function (n) { 
        return $('.gts-form[data-section="' + n + '"]'); 
    };
    const state = function () { 
        return data.survey.employment_state; 
    };
    const merged = function () { 
        return state() === 'employed' && String(data.survey.current_is_first_job) === '1'; 
    };

    function visible(n) {
        const s = state();

        if (n <= 6 || n === 13 || n === 14) { 
            return true; 
        }
        if (!s) { 
            return false; 
        }
        if (n === 7) { 
            return s === 'employed'; 
        }
        if (n <= 11) { 
            return s === 'employed'; 
        }
        if (n === 12) { 
            return s === 'employed' && String(data.survey.curriculum_relevant) === '1'; 
        }

        return true;
    }

    function nextVisible(n) { 
        for (let i = n + 1; i <= 14; i++) { 
            if (visible(i)) { 
                return i; 
            } 
        } 
        return null; 
    }

    function prevVisible(n) { 
        for (let i = n - 1; i >= 1; i--) { 
            if (visible(i)) { 
                return i; 
            } 
        } 
        return null; 
    }

    function renderSteps() {
        let html = '';

        $.each(sections, function (n, title) {
            n = parseInt(n, 10);
            if (!visible(n)) { 
                return; 
            }

            const done = data.survey.last_section > n;
            const isActive = n === current;
            let iconClass = done ? 'fa-check-circle text-success' : 'fa-circle text-muted';
            if (dirty[n]) {
                iconClass = 'fa-pencil-alt text-warning';
            }

            html += '<li class="nav-item" role="presentation">' +
                '<a href="#" class="nav-link gts-step' + (isActive ? ' active' : '') + '" role="tab" ' +
                'aria-selected="' + isActive + '" tabindex="' + (isActive ? '0' : '-1') + '" data-section="' + n + '">' +
                '<i class="fas ' + iconClass + ' mr-1"></i> ' + n + '. ' + Fmt.esc(title) +
                '</a></li>';
        });

        $('#gts-steps').html(html);
        $('#gts-steps .nav-link.active').each(function () {
            if (this.scrollIntoView) {
                const bar = $('#gts-steps')[0];
                bar.scrollLeft = Math.max(0, this.offsetLeft - bar.clientWidth / 2 + this.offsetWidth / 2);
            }
        });
    }

    function updateActions() {
        const isReview = current === 14;

        $('#gts-save')
            .attr('form', 'gts-form-' + current)
            .toggle(editable && !isReview);
        $('#gts-submit').toggle(editable && isReview);
        $('#gts-dirty').toggle(editable && !!dirty[current]);
        $('.gts-prev').prop('disabled', !prevVisible(current));
        $('.gts-next').toggle(!editable && !!nextVisible(current));
    }

    function go(n) {
        if (!visible(n)) { 
            n = prevVisible(n) || 1; 
        }

        current = n;
        $('.gts-panel').hide();
        $('.gts-panel[data-section="' + n + '"]').show();

        applyConditionals();
        renderSteps();
        updateActions();

        if (n === 14) { 
            loadReview(); 
        }

        $('html, body').animate({ scrollTop: 0 }, 150);
    }

    function applyConditionals() {
        $('.gts-check[data-other="1"]').each(function () {
            $('[name="' + $(this).data('other-target') + '"]').toggle($(this).is(':checked'));
        });

        const picked = $form(6).find('[name="employment_state"]:checked').val();
        $('#unemployment-wrap').toggle(!!picked && picked !== 'employed');

        const tenure = $form(7).find('[name="employment_type_id"] option:selected').data('name');
        $('#employer-label').text(tenure === 'Self-employed' ? 'Business / Enterprise Name' : 'Employer / Company');

        const isMerged = merged();
        const isEmployed = state() === 'employed';

        $('#first-separate').toggle(!isMerged);
        $('#first-merged-note').toggle(isMerged);
        $('#change-wrap').toggle(isEmployed && !isMerged);
        $('#level-current-wrap').toggle(isEmployed && !isMerged);
        $('#level-first-title').text(isMerged ? 'Your first (and present) job' : 'First job');

        $('#training-purpose-other').toggle($('#training-add [name="purpose"]').val() === 'Other');
    }

    $(document).on('change', '.gts-check, [name="employment_state"], [name="employment_type_id"], #training-add [name="purpose"]', applyConditionals);

    function setField($f, name, value) {
        const $el = $f.find('[name="' + name + '"]');
        if (!$el.length || value === null || value === undefined) { 
            return; 
        }

        if ($el.is(':radio')) { 
            $el.filter('[value="' + value + '"]').prop('checked', true); 
        } else { 
            $el.val(value); 
        }
    }

    function setChecks($f, name, ids) {
        $f.find('[name="' + name + '[]"]').each(function () {
            $(this).prop('checked', ids.indexOf(parseInt(this.value, 10)) !== -1);
        });
    }

    function fillAll() {
        const g = data.general;
        const ed = data.education;
        const s = data.survey;
        const cur = data.current || {};
        const first = data.first || {};

        $.each(g, function (k, v) { 
            setField($form(1), k, v); 
        });
        $('#gts-email').val(g.email || '');

        $('#edu-program').text(ed.program_name || '—');
        $('#edu-year').text(ed.graduation_year || '—');
        ['degree', 'specialization', 'academic_year', 'honors_awards'].forEach(function (k) { 
            setField($form(2), k, ed[k]); 
        });

        setChecks($form(4), 'course_reason_ids', data.course.ids);
        setField($form(4), 'course_reason_other', data.course.other);

        setField($form(6), 'employment_state', s.employment_state);
        setChecks($form(6), 'unemployment_reason_ids', data.unemployment.ids);
        setField($form(6), 'unemployment_reason_other', data.unemployment.other);

        [
            'employment_type_id', 'job_position', 'employer', 'industry_id', 
            'place_of_work', 'employment_location', 'related_to_degree', 'date_hired'
        ].forEach(function (k) { 
            setField($form(7), k, cur[k]); 
        });
        setField($form(7), 'current_is_first_job', s.current_is_first_job);

        const separate = !merged();
        if (separate) {
            setField($form(8), 'first_job_position', first.job_position);
            setField($form(8), 'first_employer', first.employer);
            setField($form(8), 'first_job_location', first.employment_location);
            setField($form(8), 'first_industry_id', first.industry_id);
            setField($form(8), 'first_related_to_degree', first.related_to_degree);
        }
        setField($form(8), 'duration_id', first.duration_id);
        setChecks($form(8), 'accept_reason_ids', data.accept.ids);
        setField($form(8), 'accept_reason_other', data.accept.other);

        setField($form(9), 'search_method_id', first.search_method_id);
        setField($form(9), 'time_to_job_id', first.time_to_job_id);
        setChecks($form(9), 'change_reason_ids', data.change.ids);
        setField($form(9), 'change_reason_other', data.change.other);

        setField($form(10), 'first_job_level_id', first.job_level_id);
        setField($form(10), 'first_salary_range_id', first.salary_range_id);
        if (separate) {
            setField($form(10), 'current_job_level_id', cur.job_level_id);
            setField($form(10), 'current_salary_range_id', cur.salary_range_id);
        }

        setField($form(11), 'curriculum_relevant', s.curriculum_relevant);
        setChecks($form(12), 'competency_ids', data.competencies.ids);
        setField($form(12), 'competency_other', data.competencies.other);
        setField($form(13), 'curriculum_feedback', data.feedback);
    }

    function clearErrors($f) {
        $f.find('.is-invalid').removeClass('is-invalid');
        $f.find('.gts-err').remove();
    }

    function showErrors($f, errors, message) {
        const seen = {};
        let html = '';

        $.each(errors || {}, function (field, msg) {
            $f.find('[name="' + field + '"], [name="' + field + '[]"]').first().addClass('is-invalid');
            if (!seen[msg]) { 
                seen[msg] = true; 
                html += '<li>' + Fmt.esc(msg) + '</li>'; 
            }
        });

        if (!html) { 
            html = '<li>' + Fmt.esc(message) + '</li>'; 
        }

        $f.find('.card-body').first().prepend(
            '<div class="alert alert-danger gts-err mb-3"><ul class="mb-0 pl-3">' + html + '</ul></div>'
        );
    }

    $('.gts-form').on('submit', function (e) {
        e.preventDefault();
        if (!editable) { 
            return; 
        }

        const $f = $(this);
        const n = $f.data('section');
        const $btn = $('#gts-save').prop('disabled', true);

        clearErrors($f);

        $.ajax({
            url: BASE_URL + '/Api/Gts/saveSection/' + studyId,
            method: 'POST',
            data: $f.serialize() + '&section=' + n,
            dataType: 'json'
        }).done(function (res) {
            if (res.status !== 'success') {
                showErrors($f, res.errors, res.message);
                msgBox('error', res.message);
                return;
            }

            data.survey = res.data.survey;
            delete dirty[n];
            msgBox('success', res.message);
            go(nextVisible(n) || 14);
        }).fail(handleAjaxError).always(function () { 
            $btn.prop('disabled', false); 
        });
    });

    $('.gts-form').on('input change', ':input', function () {
        if (!editable || $(this).closest('#exam-add, #training-add').length) {
            return;
        }

        const n = parseInt($(this).closest('.gts-form').data('section'), 10);
        if (!dirty[n]) {
            dirty[n] = true;
            renderSteps();
            updateActions();
        }
    });

    $(window).on('beforeunload', function () {
        if (editable && Object.keys(dirty).length) {
            return 'You have unsaved changes.';
        }
    });

    $('#gts-steps').on('keydown', '.gts-step', function (e) {
        const keys = { ArrowRight: 1, ArrowLeft: -1 };
        let $target = null;

        if (keys[e.key]) {
            const $all = $('#gts-steps .gts-step');
            $target = $all.eq((($all.index(this) + keys[e.key]) + $all.length) % $all.length);
        } else if (e.key === 'Home') {
            $target = $('#gts-steps .gts-step').first();
        } else if (e.key === 'End') {
            $target = $('#gts-steps .gts-step').last();
        }

        if ($target) {
            e.preventDefault();
            go(parseInt($target.data('section'), 10));
            $('#gts-steps .gts-step.active').trigger('focus');
        }
    });

    $(document).on('click', '.gts-step', function (e) {
        e.preventDefault();
        go(parseInt($(this).data('section'), 10));
    });

    $(document).on('click', '.gts-step-link', function (e) {
        e.preventDefault();
        go(parseInt($(this).data('section'), 10));
    });

    $(document).on('click', '.gts-prev', function () { 
        go(prevVisible(current) || 1); 
    });

    $(document).on('click', '.gts-next', function () { 
        go(nextVisible(current) || 14); 
    });

    function loadExams() {
        $.getJSON(BASE_URL + '/Api/Exams/all').done(function (res) {
            const rows = res.data || [];

            if (!rows.length) {
                $('#exam-rows').html('<tr><td colspan="5" class="text-center text-muted">None recorded.</td></tr>');
                return;
            }

            const html = rows.map(function (r) {
                const deleteBtn = editable 
                    ? '<button type="button" class="btn btn-xs btn-outline-danger exam-del" data-id="' + r.id + '"><i class="fas fa-trash"></i></button>' 
                    : '';

                return '<tr>' +
                    '<td>' + Fmt.esc(r.exam_name) + '</td>' +
                    '<td>' + Fmt.date(r.date_taken) + '</td>' +
                    '<td>' + Fmt.dash(r.rating) + '</td>' +
                    '<td>' + Fmt.esc(r.result) + '</td>' +
                    '<td class="text-right">' + deleteBtn + '</td>' +
                    '</tr>';
            }).join('');

            $('#exam-rows').html(html);
        }).fail(handleAjaxError);
    }

    $('#exam-add-btn').on('click', function () {
        const $box = $('#exam-add');

        apiRequest('POST', 'Exams/add', $box.find(':input').serialize(), function () {
            $box.find('input').val('');
            loadExams();
        });
    });

    $(document).on('click', '.exam-del', function () {
        const confirmConfig = { 
            title: 'Delete this examination?', 
            confirmText: 'Yes, delete it', 
            color: '#d33' 
        };

        confirmAction(confirmConfig, 'DELETE', 'Exams/delete/' + $(this).data('id'), {}, loadExams);
    });

    function loadTrainings() {
        $.getJSON(BASE_URL + '/Api/Trainings/all').done(function (res) {
            const rows = res.data || [];

            if (!rows.length) {
                $('#training-rows').html('<tr><td colspan="7" class="text-center text-muted">None recorded.</td></tr>');
                return;
            }

            const html = rows.map(function (r) {
                const durationCredits = [r.duration, r.credits_earned].filter(Boolean).join(' / ');
                const purpose = r.purpose === 'Other' ? r.purpose_other : r.purpose;
                const deleteBtn = editable 
                    ? '<button type="button" class="btn btn-xs btn-outline-danger training-del" data-id="' + r.id + '"><i class="fas fa-trash"></i></button>' 
                    : '';

                return '<tr>' +
                    '<td>' + Fmt.esc(r.training_title) + '</td>' +
                    '<td>' + Fmt.esc(r.training_type) + '</td>' +
                    '<td>' + Fmt.dash(r.organizer) + '</td>' +
                    '<td>' + Fmt.dash(durationCredits) + '</td>' +
                    '<td>' + Fmt.dash(r.training_year) + '</td>' +
                    '<td>' + Fmt.dash(purpose) + '</td>' +
                    '<td class="text-right">' + deleteBtn + '</td>' +
                    '</tr>';
            }).join('');

            $('#training-rows').html(html);
        }).fail(handleAjaxError);
    }

    $('#training-add-btn').on('click', function () {
        const $box = $('#training-add');

        apiRequest('POST', 'Trainings/add', $box.find(':input').serialize(), function () {
            $box.find('input').val('');
            $box.find('[name="purpose"]').val('');
            applyConditionals();
            loadTrainings();
        });
    });

    $(document).on('click', '.training-del', function () {
        const confirmConfig = { 
            title: 'Delete this record?', 
            confirmText: 'Yes, delete it', 
            color: '#d33' 
        };

        confirmAction(confirmConfig, 'DELETE', 'Trainings/delete/' + $(this).data('id'), {}, loadTrainings);
    });

    function loadReview() {
        $('#review-body').html('<p class="text-muted">Loading&hellip;</p>');

        $.getJSON(BASE_URL + '/Api/Gts/review/' + studyId).done(function (res) {
            const html = res.sections.map(function (sec) {
                const rowsHtml = sec.rows.map(function (r) {
                    const isEmpty = r[1] === '' || r[1] === null || r[1] === undefined;
                    const value = isEmpty ? '<span class="text-muted">&mdash;</span>' : Fmt.esc(r[1]);

                    return '<tr>' +
                        '<td class="text-muted" style="width:35%">' + Fmt.esc(r[0]) + '</td>' +
                        '<td>' + value + '</td>' +
                        '</tr>';
                }).join('');

                return '<h6 class="text-primary mt-3">' + Fmt.esc(sec.title) + '</h6>' +
                    '<table class="table table-sm table-borderless mb-0"><tbody>' + 
                    rowsHtml + 
                    '</tbody></table>';
            }).join('');

            $('#review-body').html(html);

            if (res.missing.length) {
                const missingList = res.missing.map(function (m) { 
                    const target = parseInt(m, 10);
                    return target >= 1 && target <= 13
                        ? '<li><a href="#" class="gts-step-link" data-section="' + target + '">' + Fmt.esc(m) + '</a></li>'
                        : '<li>' + Fmt.esc(m) + '</li>';
                }).join('');

                $('#review-missing')
                    .html('<strong>Please complete:</strong><ul class="mb-0 pl-3">' + missingList + '</ul>')
                    .show();
            } else {
                $('#review-missing').hide();
            }

            $('#gts-submit').prop('disabled', res.missing.length > 0);
        }).fail(handleAjaxError);
    }

    $('#gts-submit').on('click', function () {
        const confirmConfig = {
            title: 'Submit your survey?',
            text: 'You will not be able to change your answers afterwards unless the alumni office allows it.',
            confirmText: 'Yes, submit'
        };

        confirmAction(confirmConfig, 'POST', 'Gts/submit/' + studyId, {}, function () {
            Object.keys(dirty).forEach(function (k) { delete dirty[k]; });
            window.location.href = BASE_URL + '/Tracer';
        });
    });

    fillAll();
    loadExams();
    loadTrainings();

    if (!editable) {
        const submitted = data.survey.status === 'submitted';
        const lockMessage = submitted
            ? '<i class="fas fa-lock mr-1"></i> You submitted this survey' +
              (data.survey.submitted_at ? ' on ' + Fmt.datetime(data.survey.submitted_at) : '') +
              '. Your answers are locked; contact the alumni office if something must be corrected.'
            : '<i class="fas fa-lock mr-1"></i> This survey period is closed, so your answers can no longer be changed.';

        $('#gts-lock').html(lockMessage).show();
        $('.gts-form :input').not('.gts-prev, .gts-next').prop('disabled', true);
        $('.gts-edit-only').hide();
        updateActions();
    }

    const initialSection = !editable 
        ? 14 
        : Math.min(Math.max(data.survey.last_section || 1, 1), 14);

    go(initialSection);
});