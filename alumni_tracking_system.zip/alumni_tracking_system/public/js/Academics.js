$(function () {
    const academicsModule = CrudModule({
        api: 'Academics',
        noun: 'program record',
        table: '#academics-table',
        form: '#academics-form',
        modal: '#academics-modal',
        addButton: '#add-academic',
        order: [[2, 'desc']],
        columns: [
            { 
                data: 'program_name', 
                title: 'Program' 
            },
            { 
                data: 'major', 
                title: 'Major', 
                render: function (data) { 
                    return Fmt.dash(data); 
                } 
            },
            { 
                data: 'graduation_year', 
                title: 'Grad. Year' 
            },
            { 
                data: 'batch', 
                title: 'Batch', 
                render: function (data) { 
                    return Fmt.dash(data); 
                } 
            },
            { 
                data: 'student_id', 
                title: 'Student ID', 
                render: function (data) { 
                    return Fmt.dash(data); 
                } 
            }
        ]
    });

    const educationsModule = CrudModule({
        api: 'Educations',
        noun: 'education record',
        table: '#educations-table',
        form: '#educations-form',
        modal: '#educations-modal',
        addButton: '#add-education',
        order: [[0, 'asc']],
        columns: [
            { 
                data: 'level_name', 
                title: 'Level' 
            },
            { 
                data: 'institution', 
                title: 'Institution' 
            },
            { 
                data: 'degree', 
                title: 'Degree', 
                render: function (data) { 
                    return Fmt.dash(data); 
                } 
            },
            { 
                data: 'field_of_study', 
                title: 'Field', 
                render: function (data) { 
                    return Fmt.dash(data); 
                } 
            },
            { 
                data: null, 
                title: 'Years', 
                render: function (data, type, row) { 
                    const start = row.start_year || '';
                    const end = row.end_year || 'present';
                    return Fmt.esc(start + ' – ' + end); 
                } 
            },
            { 
                data: 'status', 
                title: 'Status', 
                render: function (data) { 
                    const statusColors = {
                        Completed: 'success',
                        Ongoing: 'primary',
                        Discontinued: 'secondary'
                    };
                    return Fmt.badge(data, statusColors); 
                } 
            }
        ]
    });

    academicsModule.init();
    educationsModule.init();
});