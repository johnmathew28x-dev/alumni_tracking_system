$(function () {
    const roleBadge = {
        'Administrator': 'danger',
        'Alumni': 'primary',
        'Faculty': 'info',
        'Quality Assurance': 'warning'
    };

    function toggleAlumniFields() {
        const isAdd = !$('#users-form').data('editing');
        const isAlumni = $('#user-role').val() === 'Alumni';
        $('.alumni-only').toggleClass('d-none', !(isAdd && isAlumni));
    }

    const users = CrudModule({
        api: 'Users',
        noun: 'user',
        table: '#users-table',
        form: '#users-form',
        modal: '#users-modal',
        columns: [
            { 
                data: 'username', 
                title: 'Username', 
                render: function (d, t, r) { 
                    return t === 'display' ? Fmt.person(d, r.picture_url) : d; 
                } 
            },
            { 
                data: 'email', 
                title: 'Email' 
            },
            { 
                data: 'role', 
                title: 'Role', 
                render: function (d) { 
                    return Fmt.badge(d, roleBadge); 
                } 
            },
            { 
                data: 'status', 
                title: 'Status', 
                render: function (d) { 
                    return Fmt.badge(d, StatusColors); 
                } 
            },
            { 
                data: 'created', 
                title: 'Created', 
                render: function (d) { 
                    return Fmt.date(d); 
                } 
            }
        ],
        actions: [
            {
                key: 'toggle',
                color: 'warning',
                icon: function (row) {
                    return row.status === 'active' ? 'fa-user-slash' : 'fa-user-check';
                },
                title: function (row) {
                    return row.status === 'active' ? 'Deactivate' : 'Activate';
                },
                url: function (row) {
                    return 'Users/toggle/' + row.id;
                },
                confirm: function (row) {
                    const action = row.status === 'active' ? 'Deactivate ' : 'Activate ';
                    return action + row.username + '?';
                }
            }
        ],
        onAdd: function ($form) {
            $form.data('editing', false);
            $form.find('[name=username]').prop('readonly', false);
            $form.find('[name=password]').prop('required', true);
            $('.edit-only').addClass('d-none');
            toggleAlumniFields();
        },
        onEdit: function (res, $form) {
            $form.data('editing', true);
            $form.find('[name=username]').prop('readonly', true);
            $form.find('[name=password]').prop('required', false).val('');
            $('.edit-only').removeClass('d-none');
            toggleAlumniFields();
        }
    });

    users.init();

    $('#user-role').on('change', toggleAlumniFields);
});