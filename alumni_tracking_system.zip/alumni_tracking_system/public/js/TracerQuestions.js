$(function () {
    const typeLabels = {
        text: 'Text',
        yes_no: 'Yes / No',
        multiple_choice: 'Multiple Choice',
        select: 'Select'
    };

    function toggleOptions() {
        const type = $('#q_type').val();
        const needsOptions = type === 'multiple_choice' || type === 'select';
        $('#q_options_wrap').toggleClass('d-none', !needsOptions);
    }

    CrudModule({
        api: 'TracerQuestions',
        listUrl: 'TracerQuestions/all/' + window.PAGE.studyId,
        noun: 'question',
        table: '#questions-table',
        form: '#questions-form',
        modal: '#questions-modal',
        order: [[0, 'asc']],
        columns: [
            { 
                data: 'sort_order', 
                title: '#', 
                width: '50px' 
            },
            { 
                data: 'question', 
                title: 'Question' 
            },
            { 
                data: 'question_type', 
                title: 'Type', 
                render: function (d) { 
                    return typeLabels[d] || d; 
                } 
            },
            { 
                data: 'is_required', 
                title: 'Required', 
                render: function (d) { 
                    return Fmt.yesNo(d); 
                } 
            }
        ],
        onReset: function ($form) {
            $('#q_required').prop('checked', true);
            toggleOptions();
        },
        onEdit: toggleOptions
    }).init();

    $('#q_type').on('change', toggleOptions);
});