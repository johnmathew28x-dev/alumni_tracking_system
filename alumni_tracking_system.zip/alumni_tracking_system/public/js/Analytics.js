$(function () {
    const palette = ['#0b3d91', '#d4a017', '#1f9d55', '#c0392b', '#6c757d', '#17a2b8', '#6f42c1', '#fd7e14', '#20c997', '#e83e8c'];
    const charts = {};

    function pct(v) {
        return v === null || v === undefined ? 'n/a' : v + '%';
    }

    function draw(id, type, labels, datasets, opts) {
        if (charts[id]) { 
            charts[id].destroy(); 
        }

        const $canvas = $('#' + id);
        $canvas.siblings('.no-data').remove();

        const hasData = datasets.some(function (d) { 
            return d.data.some(function (v) { return v !== null && v > 0; }); 
        });

        if (!hasData) {
            $canvas.hide().after('<p class="no-data text-muted text-center my-4">Not enough data to display.</p>');
            return;
        }

        $canvas.show();
        charts[id] = new Chart($canvas[0].getContext('2d'), {
            type: type,
            data: { labels: labels, datasets: datasets },
            options: $.extend(true, { 
                responsive: true, 
                legend: { 
                    display: datasets.length > 1 || type === 'pie' || type === 'doughnut', 
                    position: 'bottom' 
                } 
            }, opts || {})
        });
    }

    function simple(id, items, type, label) {
        const labels = items.map(function (i) { return i.label; });
        const data = items.map(function (i) { return i.total; });
        const isRound = type === 'doughnut' || type === 'pie';

        draw(id, type, labels, [{
            label: label || 'Respondents', 
            data: data,
            backgroundColor: isRound ? palette : '#0b3d91'
        }], isRound ? {} : { 
            scales: { 
                xAxes: [{ ticks: { autoSkip: false, maxRotation: 40 } }], 
                yAxes: [{ ticks: { beginAtZero: true, precision: 0 } }] 
            } 
        });
    }

    function kpi(label, value, icon, bg) {
        return '<div class="col-lg-3 col-6">' +
            '<div class="small-box ' + bg + '">' +
                '<div class="inner">' +
                    '<h3>' + value + '</h3>' +
                    '<p>' + Fmt.esc(label) + '</p>' +
                '</div>' +
                '<div class="icon"><i class="fas ' + icon + '"></i></div>' +
            '</div>' +
        '</div>';
    }

    function dlist(items, empty) {
        if (!items.length) { 
            return '<p class="text-muted mb-2">' + (empty || 'No data.') + '</p>'; 
        }

        const max = Math.max.apply(null, items.map(function (i) { return i.total; }));

        return items.map(function (i) {
            return '<div class="mb-1">' +
                '<div class="d-flex justify-content-between small">' +
                    '<span>' + Fmt.esc(i.label) + '</span>' +
                    '<strong>' + i.total + '</strong>' +
                '</div>' +
                '<div class="progress" style="height:5px">' +
                    '<div class="progress-bar" style="width:' + Math.round(i.total * 100 / max) + '%"></div>' +
                '</div>' +
            '</div>';
        }).join('');
    }

    function renderKpis(k, participation) {
        $('#low-n').toggle(!k.reliable).html(
            k.respondents === 0
                ? 'No submitted surveys match these filters yet.'
                : '<i class="fas fa-exclamation-triangle"></i> Only ' + k.respondents + ' submitted survey(s) match these filters. Percentages from so few responses are not reliable.'
        );

        $('#kpis').html(
            kpi('Alumni on record', participation.total_alumni, 'fa-user-graduate', 'bg-info') +
            kpi('Surveys submitted', k.respondents, 'fa-clipboard-check', 'bg-primary') +
            kpi('Survey completion rate', pct(participation.rate), 'fa-percentage', 'bg-indigo') +
            kpi('Employment rate', pct(k.employment_rate), 'fa-briefcase', 'bg-success') +
            kpi('Employed', k.employed, 'fa-user-tie', 'bg-success') +
            kpi('Not currently employed', k.not_employed, 'fa-user-times', 'bg-danger') +
            kpi('Never employed', k.never_employed, 'fa-user-slash', 'bg-secondary') +
            kpi('Self-employed', k.self_employed, 'fa-store', 'bg-teal') +
            kpi('Local employment', k.local, 'fa-map-marker-alt', 'bg-info') +
            kpi('Overseas employment', k.abroad, 'fa-globe-asia', 'bg-info') +
            kpi('Degree-related (of employed)', k.related + ' (' + pct(k.related_rate) + ')', 'fa-link', 'bg-primary') +
            kpi('Not degree-related', k.not_related, 'fa-unlink', 'bg-warning')
        );
    }

    function renderCharts(d) {
        const y = d.employment_by_year;
        draw('c-state-year', 'bar', y.map(function (r) { return r.label; }), [
            { label: 'Employed', backgroundColor: '#1f9d55', data: y.map(function (r) { return r.employed; }) },
            { label: 'Not currently employed', backgroundColor: '#c0392b', data: y.map(function (r) { return r.not_employed; }) },
            { label: 'Never employed', backgroundColor: '#6c757d', data: y.map(function (r) { return r.never_employed; }) }
        ], { 
            scales: { 
                xAxes: [{ stacked: true }], 
                yAxes: [{ stacked: true, ticks: { beginAtZero: true, precision: 0 } }] 
            } 
        });

        const p = d.by_program;
        const rateOpts = { scales: { yAxes: [{ ticks: { beginAtZero: true, max: 100 } }] } };

        draw('c-rate-program', 'bar', p.map(function (r) { return r.code; }),
            [{ label: 'Employment rate %', backgroundColor: '#0b3d91', data: p.map(function (r) { return r.employment_rate; }) }], rateOpts);

        draw('c-related-program', 'bar', p.map(function (r) { return r.code; }),
            [{ label: 'Degree-related %', backgroundColor: '#d4a017', data: p.map(function (r) { return r.related_rate; }) }], rateOpts);

        simple('c-place', d.place_of_work, 'doughnut');
        simple('c-industry', d.industry, 'bar');
        simple('c-level', d.job_level, 'bar');
        simple('c-salary', d.salary, 'bar');
        simple('c-time', d.time_to_first_job, 'bar');
        simple('c-relevance', d.curriculum_relevance, 'doughnut');
        simple('c-comp', d.competencies, 'bar');
    }

    function renderTables(d) {
        const p = d.by_program;
        const programRows = p.length ? p.map(function (r) {
            return '<tr>' +
                '<td>' + Fmt.esc(r.code) + '</td>' +
                '<td>' + r.respondents + '</td>' +
                '<td>' + r.employed + '</td>' +
                '<td>' + pct(r.employment_rate) + '</td>' +
                '<td>' + r.related + ' (' + pct(r.related_rate) + ')</td>' +
                '<td>' + r.local + '</td>' +
                '<td>' + r.abroad + '</td>' +
            '</tr>';
        }).join('') : '<tr><td colspan="7" class="text-center text-muted">No data.</td></tr>';

        $('#t-programs').html(
            '<thead><tr><th>Program</th><th>Resp.</th><th>Employed</th><th>Rate</th><th>Related</th><th>Local</th><th>Abroad</th></tr></thead>' +
            '<tbody>' + programRows + '</tbody>'
        );

        const pt = d.participation.by_year;
        const participationRows = pt.length ? pt.map(function (r) {
            return '<tr>' +
                '<td>' + Fmt.esc(r.label) + '</td>' +
                '<td>' + r.alumni + '</td>' +
                '<td>' + r.responded + '</td>' +
                '<td>' + pct(r.rate) + '</td>' +
            '</tr>';
        }).join('') : '<tr><td colspan="4" class="text-center text-muted">No data.</td></tr>';

        $('#t-participation').html(
            '<thead><tr><th>Graduation Year</th><th>Alumni</th><th>Responded</th><th>Rate</th></tr></thead>' +
            '<tbody>' + participationRows + '</tbody>'
        );
    }

    function renderDetails(d) {
        const dv = d.development;
        const examItems = dv.exams.map(function (x) { 
            return { label: x.label + ' (passed ' + x.passed + ')', total: x.total }; 
        });

        $('#dev-body').html(
            '<p class="mb-1">With a professional examination: <strong>' + dv.with_exam + '</strong> (' + pct(dv.exam_rate) + ') &middot; passed: <strong>' + dv.exam_passers + '</strong></p>' +
            '<p class="mb-1">With trainings: <strong>' + dv.with_training + '</strong> (' + pct(dv.training_rate) + ')</p>' +
            '<p class="mb-2">With advanced studies: <strong>' + dv.with_advanced_study + '</strong> (' + pct(dv.advanced_rate) + ')</p>' +
            '<h6>Most common examinations</h6>' + dlist(examItems)
        );

        $('#reasons-body').html(
            '<h6>How the first job was found</h6>' + dlist(d.search_method) +
            '<h6 class="mt-3">Reasons for taking the course</h6>' + dlist(d.course_reasons) +
            '<h6 class="mt-3">Reasons for accepting the first job</h6>' + dlist(d.accept_reasons) +
            '<h6 class="mt-3">Reasons for changing jobs</h6>' + dlist(d.change_reasons) +
            '<h6 class="mt-3">Reasons for not being employed</h6>' + dlist(d.unemployment_reasons) +
            '<h6 class="mt-3">Most common occupations</h6>' + dlist(d.occupation)
        );

        $('#demo-body').html(
            '<h6>Sex</h6>' + dlist(d.sex) +
            '<h6 class="mt-3">Civil status</h6>' + dlist(d.civil_status) +
            '<h6 class="mt-3">Region of origin</h6>' + dlist(d.region) +
            '<h6 class="mt-3">Residence</h6>' + dlist(d.residence) +
            '<h6 class="mt-3">Honors / awards</h6>' + dlist(d.honors) +
            '<h6 class="mt-3">Job level of first job</h6>' + dlist(d.first_job_level) +
            '<h6 class="mt-3">Initial salary bracket (first job)</h6>' + dlist(d.first_salary)
        );

        const feedbackHtml = d.feedback.length ? d.feedback.map(function (f) {
            return '<blockquote class="mb-2 pl-2 border-left small">' + 
                Fmt.esc(f.text) + '<br>' +
                '<span class="text-muted">' + Fmt.esc(f.program || '') + (f.year ? ' &middot; Class of ' + f.year : '') + '</span>' +
            '</blockquote>';
        }).join('') : '<p class="text-muted">No curriculum suggestions yet.</p>';

        $('#feedback-body').html(feedbackHtml);
    }

    function render(d) {
        renderKpis(d.kpis, d.participation);
        renderCharts(d);
        renderTables(d);
        renderDetails(d);
    }

    function load() {
        const qs = $('#filter-form').serialize();

        $.getJSON(BASE_URL + '/Api/Analytics/summary?' + qs)
            .done(function (res) {
                render(res.data);
            })
            .fail(handleAjaxError);

        $('.export-link').each(function () {
            $(this).attr('href', BASE_URL + '/Api/Analytics/export?dataset=' + $(this).data('dataset') + '&' + qs);
        });
    }

    if (PAGE.canExport) { 
        $('#export-btns').show(); 
    }

    $('#filter-form').on('submit', function (e) { 
        e.preventDefault(); 
        load(); 
    });

    $('#filter-reset').on('click', function () { 
        $('#filter-form')[0].reset(); 
        load(); 
    });

    load();
});