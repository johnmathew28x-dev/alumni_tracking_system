$(function () {
    const cfg = PAGE.ai || {};
    const $form = $('#ai-form');
    const $q = $('#ai-question');
    const $btn = $('#ai-analyze');
    let busy = false;

    $q.attr('maxlength', cfg.maxQuestion || 500);

    if (!cfg.enabled || !cfg.configured) {
        let note = 'The built-in statistics assistant is not available right now. Please contact the administrator.';

        if (!cfg.enabled) {
            note = 'AI Assist is currently turned off by the administrator.';
        } else if (cfg.isAdmin) {
            note = 'The built-in statistics assistant is not configured. Please contact the administrator.';
        }

        $('#ai-unavailable').text(note).show();
        $q.prop('disabled', true);
        $btn.prop('disabled', true);
        $('.ai-suggest').prop('disabled', true);
        return;
    }

    function showError(message) {
        $('#ai-error').text(message).show();
        $('#ai-result').hide();
    }

    function setBusy(state) {
        busy = state;
        $btn.prop('disabled', state);
        $q.prop('disabled', state);
        $('.ai-suggest').prop('disabled', state);
        $('#ai-loading').toggle(state);
    }

    function clearResult() {
        $('#ai-result, #ai-error, #ai-reset').hide();
    }

    $('#filter-form').on('submit', clearResult);
    $('#filter-reset').on('click', clearResult);

    $q.on('input', function () {
        $('#ai-count').text($q.val().length);
    }).on('keydown', function (e) {
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            e.preventDefault();
            $form.trigger('submit');
        }
    });

    $(document).on('click', '.ai-suggest', function () {
        $q.val($(this).text()).trigger('input').trigger('focus');
    });

    $('#ai-reset').on('click', function () {
        $('#ai-result, #ai-error').hide();
        $('#ai-reset').hide();
        $q.val('').trigger('input').trigger('focus');
    });

    $form.on('submit', function (e) {
        e.preventDefault();

        if (busy) {
            return;
        }

        const question = $.trim($q.val());
        $('#ai-error').hide();

        if (!question) {
            showError('Please type a question or choose a suggested one.');
            return;
        }

        setBusy(true);

        $.ajax({
            url: BASE_URL + '/Api/Analytics/ask?' + $('#filter-form').serialize(),
            method: 'POST',
            data: { question: question },
            dataType: 'json',
            timeout: 60000
        }).done(function (res) {
            if (res.status !== 'success') {
                showError(res.message || 'AI Assist could not answer this question.');
                return;
            }

            const d = res.data;
            const scope = Object.keys(d.scope || {}).map(function (k) {
                return k + ': ' + d.scope[k];
            }).join(' | ');

            $('#ai-scope').text('Scope: ' + scope);
            $('#ai-answer').text(d.answer);
            $('#ai-meta').text(
                (d.cached ? 'Cached local summary generated ' : 'Generated locally ') + d.generated_at +
                ' using ' + d.model + '. Only aggregate statistics were used.'
            );
            $('#ai-result').show();
            $('#ai-reset').show();
            $('#ai-answer').trigger('focus');
        }).fail(function (xhr, status) {
            if (xhr.status === 401) {
                handleAjaxError(xhr);
                return;
            }

            if (xhr.status === 429) {
                showError((xhr.responseJSON && xhr.responseJSON.message) || 'Too many requests. Please wait a moment and try again.');
                return;
            }

            if (status === 'timeout') {
                showError('The request took too long. Please try again.');
                return;
            }

            showError((xhr.responseJSON && xhr.responseJSON.message) || 'Something went wrong. Please try again.');
        }).always(function () {
            setBusy(false);
        });
    });
});
