$(function () {
    const handleResponse = function () {
        setTimeout(function () {
            window.location.reload();
        }, 700);
    };

    $('.register-btn').on('click', function () {
        const eventId = $(this).data('id');
        apiRequest('POST', 'Events/register/' + eventId, {}, handleResponse);
    });

    $('.cancel-btn').on('click', function () {
        const eventId = $(this).data('id');
        confirmAction(
            { 
                title: 'Cancel your registration for this event?', 
                confirmText: 'Yes, cancel it', 
                color: '#d33' 
            },
            'POST', 
            'Events/cancel/' + eventId, 
            {}, 
            handleResponse
        );
    });
});