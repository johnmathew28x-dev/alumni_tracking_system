$(function () {
    CrudModule({
        api: 'Exams',
        noun: 'examination',
        table: '#exams-table',
        form: '#exams-form',
        modal: '#exams-modal',
        addButton: '#add-examination',
        order: [[1, 'desc']],
        columns: [
            { 
                data: 'exam_name', 
                title: 'Examination' 
            },
            { 
                data: 'date_taken', 
                title: 'Date Taken', 
                render: (d, t) => (t === 'display' ? Fmt.date(d) : d)
            },
            { 
                data: 'rating', 
                title: 'Rating', 
                render: (d) => Fmt.dash(d) 
            },
            { 
                data: 'result', 
                title: 'Result', 
                render: (d) => Fmt.badge(d, {
                    Passed: 'success',
                    Failed: 'danger',
                    Pending: 'warning'
                }) 
            }
        ]
    }).init();
});
