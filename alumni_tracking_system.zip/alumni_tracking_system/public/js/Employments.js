$(function () {
    const syncEnded = bindToggle('#is_current', '#ended-wrap', true);

    CrudModule({
        api: 'Employments',
        noun: 'employment',
        table: '#employments-table',
        form: '#employments-form',
        modal: '#employments-modal',
        order: [[7, 'desc']],
        columns: [
            { 
                data: 'status_name', 
                title: 'Status' 
            },
            { 
                data: 'employer', 
                title: 'Employer', 
                render: function (data) { 
                    return Fmt.dash(data); 
                } 
            },
            { 
                data: 'job_position', 
                title: 'Position', 
                render: function (data) { 
                    return Fmt.dash(data); 
                } 
            },
            { 
                data: 'tenure_name', 
                title: 'Type', 
                render: function (data, type, row) { 
                    return Fmt.dash(data || row.employment_type); 
                } 
            },
            { 
                data: 'industry_name', 
                title: 'Industry', 
                render: function (data, type, row) { 
                    return Fmt.dash(data || row.industry); 
                } 
            },
            { 
                data: 'is_first_job', 
                title: 'First Job', 
                render: function (data) { 
                    return Fmt.yesNo(data); 
                } 
            },
            { 
                data: null, 
                title: 'Period', 
                render: function (data, type, row) {
                    const endDate = Number(row.is_current) === 1 ? 'Present' : Fmt.date(row.date_ended);
                    return Fmt.date(row.date_hired) + ' &ndash; ' + endDate;
                } 
            },
            { 
                data: 'is_current', 
                title: 'Current', 
                render: function (data) { 
                    return Fmt.yesNo(data); 
                } 
            }
        ],
        onReset: function () {
            $('#is_current').prop('checked', true);
            $('#is_first_job').prop('checked', false);
            syncEnded();
        },
        onEdit: syncEnded
    }).init();

    syncEnded();
});