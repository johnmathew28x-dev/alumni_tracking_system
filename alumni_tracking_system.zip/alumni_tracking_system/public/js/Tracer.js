$(function () {
    const colors = { 
        draft: 'secondary', 
        active: 'success', 
        closed: 'dark' 
    };

    CrudModule({
        api: 'Tracer',
        noun: 'tracer study',
        table: '#tracer-table',
        form: '#tracer-form',
        modal: '#tracer-modal',
        order: [[1, 'desc']],
        onReset: function () { 
            $('#survey-type-wrap').show(); 
        },
        onEdit: function () { 
            $('#survey-type-wrap').hide(); 
        },
        columns: [
            { 
                data: 'title', 
                title: 'Title' 
            },
            { 
                data: 'survey_year', 
                title: 'Year', 
                className: 'text-center', 
                render: function (d) { 
                    return Fmt.dash(d); 
                } 
            },
            { 
                data: 'survey_type', 
                title: 'Form', 
                render: function (d) { 
                    return d === 'gts' 
                        ? '<span class="badge badge-primary">CHED GTS-aligned</span>' 
                        : '<span class="badge badge-secondary">Custom</span>'; 
                } 
            },
            { 
                data: null, 
                title: 'Period', 
                render: function (d, t, r) { 
                    return Fmt.date(r.start_date) + ' &ndash; ' + Fmt.date(r.end_date); 
                } 
            },
            { 
                data: 'respondents', 
                title: 'Submitted', 
                className: 'text-center' 
            },
            { 
                data: 'drafts', 
                title: 'In progress', 
                className: 'text-center' 
            },
            { 
                data: 'status', 
                title: 'Status', 
                render: function (d) { 
                    return Fmt.badge(d, colors); 
                } 
            }
        ],
        actions: [
            {
                key: 'questions',
                color: 'secondary',
                icon: 'fa-tasks',
                title: 'Questions',
                show: function (row) { 
                    return row.survey_type !== 'gts'; 
                },
                onClick: function (row) { 
                    window.location.href = BASE_URL + '/Tracer/questions/' + row.id; 
                }
            },
            {
                key: 'stats',
                color: 'info',
                icon: 'fa-chart-bar',
                title: 'Statistics',
                onClick: function (row) {
                    window.location.href = row.survey_type === 'gts'
                        ? BASE_URL + '/Tracer/gtsResponses?study_id=' + row.id
                        : BASE_URL + '/Tracer/stats/' + row.id;
                }
            },
            {
                key: 'activate',
                color: 'success',
                icon: 'fa-play',
                title: 'Activate',
                show: function (row) { 
                    return row.status !== 'active'; 
                },
                url: function (row) { 
                    return 'Tracer/status/' + row.id; 
                },
                data: function () { 
                    return { status: 'active' }; 
                },
                confirm: function (row) { 
                    return 'Activate "' + row.title + '" for alumni to answer?'; 
                }
            },
            {
                key: 'close',
                color: 'dark',
                icon: 'fa-stop-circle',
                title: 'Close',
                show: function (row) { 
                    return row.status === 'active'; 
                },
                url: function (row) { 
                    return 'Tracer/status/' + row.id; 
                },
                data: function () { 
                    return { status: 'closed' }; 
                },
                confirm: function (row) { 
                    return 'Close "' + row.title + '"?'; 
                }
            }
        ]
    }).init();
});