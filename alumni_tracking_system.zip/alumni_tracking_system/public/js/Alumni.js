$(function () {
    const canEdit = !!(window.PAGE && window.PAGE.canEdit);
    let debounceTimer = null;

    const getFilterParams = function () {
        const params = {};
        $('#filter-form').serializeArray().forEach(function (field) {
            params[field.name] = field.value;
        });
        return params;
    };

    const columns = [
        { 
            data: 'alumni_id', 
            title: 'Alumni ID' 
        },
        { 
            data: null, 
            title: 'Name', 
            render: function (data, type, row) { 
                const name = row.last_name + ', ' + row.first_name;

                if (type !== 'display') {
                    return name;
                }

                return '<div class="alumni-name-cell">' +
                    '<img class="alumni-photo" loading="lazy" src="' + Fmt.esc(row.picture_url) + '" alt="Profile photo of ' + Fmt.esc(row.first_name + ' ' + row.last_name) + '">' +
                    '<span>' + Fmt.esc(name) + '</span></div>';
            } 
        },
        { 
            data: 'program_code', 
            title: 'Program', 
            defaultContent: '', 
            render: function (data) { 
                return Fmt.dash(data); 
            } 
        },
        { 
            data: 'graduation_year', 
            title: 'Grad. Year', 
            render: function (data) { 
                return Fmt.dash(data); 
            } 
        },
        { 
            data: 'email', 
            title: 'Email', 
            render: function (data) { 
                return Fmt.dash(data); 
            } 
        },
        { 
            data: 'submission_status', 
            title: 'Submission', 
            render: function (data) { 
                return Fmt.badge(data, { submitted: 'success', draft: 'secondary' }); 
            } 
        },
        { 
            data: 'verification_status', 
            title: 'Verification', 
            render: function (data) { 
                return Fmt.badge(data, StatusColors); 
            } 
        },
        { 
            data: 'profile_status', 
            title: 'Alumni Status', 
            render: function (data) { 
                return Fmt.badge(data, StatusColors); 
            } 
        }
    ];

    const actions = [
        {
            key: 'view',
            color: 'info',
            icon: 'fa-eye',
            title: 'View profile',
            onClick: function (row) {
                window.location.href = BASE_URL + '/Alumni/details/' + row.id;
            }
        }
    ];

    if (canEdit) {
        actions.push({
            key: 'verify',
            color: 'success',
            icon: 'fa-user-check',
            title: 'Verify',
            show: function (row) {
                return row.verification_status !== 'verified';
            },
            url: function (row) {
                return 'Alumni/verify/' + row.id;
            },
            data: function () {
                return { status: 'verified' };
            },
            confirm: function (row) {
                return 'Verify ' + row.first_name + ' ' + row.last_name + '?';
            }
        });
    }

    const alumniModule = CrudModule({
        api: 'Alumni',
        noun: 'alumni',
        table: '#alumni-table',
        form: '#alumni-form',
        modal: '#alumni-modal',
        columns: columns,
        actions: actions,
        canEdit: canEdit,
        canDelete: false,
        order: [[1, 'asc']],
        listParams: getFilterParams,
        onReset: function () {
            $('#alumni-photo-preview').attr('src', BASE_URL + '/img/default-avatar.svg');
        },
        onAdd: function () {
            $('.create-only').show().find(':input').prop('disabled', false);
        },
        onEdit: function (res) {
            $('.create-only').hide().find(':input').prop('disabled', true);
            if (res && res.picture_url) {
                $('#alumni-photo-preview').attr('src', res.picture_url);
            }
        }
    });

    $('#alumni-photo-input').on('change', function () {
        const file = this.files && this.files[0];

        if (!file) {
            return;
        }

        if (file.size > 2 * 1024 * 1024) {
            msgBox('error', 'The image must be 2 MB or smaller.');
            this.value = '';
            return;
        }

        $('#alumni-photo-preview').attr('src', URL.createObjectURL(file));
    });

    alumniModule.init();

    const reloadTable = function () {
        alumniModule.table().ajax.reload();
    };

    $('#filter-form')
        .on('change', 'select', reloadTable)
        .on('input', 'input[type="search"]', function () {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(reloadTable, 300);
        });

    $('#filter-reset').on('click', function () {
        setTimeout(reloadTable, 0);
    });
});