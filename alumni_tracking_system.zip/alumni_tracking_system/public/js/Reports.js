$(function () {
    const cfg = window.PAGE;
    const statusFields = ['verification_status', 'status', 'profile_status'];

    const columns = cfg.columns.map(function (c) {
        const col = Object.assign({ defaultContent: '' }, c);

        if (c.data === 'name') {
            col.render = function (d, t, row) {
                if (t !== 'display') {
                    return d === null ? '' : d;
                }
                return row.picture_url ? Fmt.person(d, row.picture_url) : Fmt.dash(d);
            };
        } else if (statusFields.indexOf(c.data) !== -1) {
            col.render = function (d, t) {
                return t === 'display' ? Fmt.badge(d, StatusColors) : (d === null ? '' : d);
            };
        } else {
            col.render = function (d, t) {
                if (t !== 'display') {
                    return d === null ? '' : d;
                }
                return Fmt.dash(d);
            };
        }
        return col;
    });

    const filters = function () {
        const p = {};
        $('#report-filter').serializeArray().forEach(function (f) {
            p[f.name] = f.value;
        });
        return p;
    };

    let lastRequest = null;
    const exportCols = { columns: ':visible' };
    const fileName = cfg.title.replace(/\s+/g, '_');

    const table = $('#report-table').DataTable({
        ajax: function (dtData, callback) {
            if (lastRequest && lastRequest.readyState !== 4) {
                lastRequest.abort();
            }

            lastRequest = $.ajax({
                url: BASE_URL + '/Api/Reports/data/' + cfg.type,
                data: filters(),
                dataType: 'json'
            })
            .done(function (res) {
                callback({ data: res.data });
            })
            .fail(function (xhr) {
                if (xhr.statusText === 'abort') {
                    return;
                }
                callback({ data: [] });
                handleAjaxError(xhr);
            });
        },
        columns: columns,
        responsive: true,
        autoWidth: false,
        pageLength: 25,
        dom: "<'row'<'col-md-8'B><'col-md-4'f>>rt<'row'<'col-md-5'i><'col-md-7'p>>",
        buttons: [
            {
                extend: 'excelHtml5',
                className: 'btn-sm btn-success',
                text: '<i class="fas fa-file-excel"></i> Excel',
                title: cfg.title,
                filename: fileName,
                exportOptions: exportCols
            },
            {
                extend: 'pdfHtml5',
                className: 'btn-sm btn-danger',
                text: '<i class="fas fa-file-pdf"></i> PDF',
                title: cfg.title,
                filename: fileName,
                orientation: 'landscape',
                exportOptions: exportCols
            },
            {
                extend: 'print',
                className: 'btn-sm btn-secondary',
                text: '<i class="fas fa-print"></i> Print',
                title: cfg.title,
                exportOptions: exportCols
            },
            {
                extend: 'colvis',
                className: 'btn-sm btn-info',
                text: '<i class="fas fa-columns"></i> Columns'
            }
        ],
        language: {
            emptyTable: 'No records match the selected filters.'
        }
    }).on('error.dt', function (e, settings, techNote, message) {
        console.error(message);
        msgBox('error', 'Unable to load the report. Please refresh the page.');
    });

    let pending = null;
    const reload = function () {
        table.ajax.reload();
    };

    $('#report-filter')
        .on('change', 'select', reload)
        .on('input', 'input[type="search"]', function () {
            clearTimeout(pending);
            pending = setTimeout(reload, 300);
        });

    $('#report-reset').on('click', function () {
        setTimeout(reload, 0);
    });
});