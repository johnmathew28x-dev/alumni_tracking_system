$(function () {
    $('#password-form').on('submit', function (e) {
        e.preventDefault();
        
        const $form = $(this);

        apiRequest('POST', 'Profile/password', $form.serialize(), function () {
            $form[0].reset();
        });
    });
});