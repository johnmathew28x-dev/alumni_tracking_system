$(function () {
    function actionBadge(action) {
        const actionUpper = String(action).toUpperCase();
        let badgeClass = 'secondary';

        if (/CREATE|ADD|LOGIN|REGISTER|SUBMIT|VERIFY/.test(actionUpper)) {
            badgeClass = 'success';
        } else if (/UPDATE|EDIT|SAVE|TOGGLE|CHANGE/.test(actionUpper)) {
            badgeClass = 'warning';
        } else if (/DELETE|LOGOUT|CANCEL/.test(actionUpper)) {
            badgeClass = 'danger';
        }

        return '<span class="badge badge-' + badgeClass + '">' + Fmt.esc(action) + '</span>';
    }

    ListTable(
        '#audit-table', 
        'Audit/all', 
        [
            { 
                data: 'created', 
                title: 'Date / Time', 
                render: function (data, type) { 
                    return type === 'display' ? Fmt.datetime(data) : data; 
                } 
            },
            { 
                data: 'username', 
                title: 'User', 
                render: function (data, type, row) { 
                    return type === 'display' ? Fmt.person(data, row.picture_url) : data; 
                } 
            },
            { 
                data: 'action', 
                title: 'Action', 
                render: function (data, type) { 
                    return type === 'display' ? actionBadge(data) : data; 
                } 
            },
            { 
                data: 'module', 
                title: 'Module', 
                render: function (data, type, row) { 
                    if (!data) return Fmt.dash(null);
                    return Fmt.esc(data) + (row.record_id ? ' #' + row.record_id : ''); 
                } 
            },
            { 
                data: 'description', 
                title: 'Description', 
                render: function (data) { 
                    return Fmt.dash(data); 
                } 
            },
            { 
                data: 'ip_address', 
                title: 'IP Address', 
                render: function (data) { 
                    return Fmt.dash(data); 
                } 
            }
        ], 
        { 
            order: [[0, 'desc']], 
            emptyText: 'No audit log entries yet.' 
        }
    );
});