$(function () {
    let participants = null;
    let participantsEventId = null;

    const events = CrudModule({
        api: 'Events',
        noun: 'event',
        table: '#events-table',
        form: '#events-form',
        modal: '#events-modal',
        order: [[1, 'desc']],
        columns: [
            { 
                data: 'title', 
                title: 'Event' 
            },
            { 
                data: 'event_date', 
                title: 'Date', 
                render: function (data, type, row) {
                    if (type !== 'display') return data;
                    return Fmt.date(data) + (row.event_time ? '<br><small class="text-muted">' + Fmt.time(row.event_time) + '</small>' : '');
                } 
            },
            { 
                data: 'location', 
                title: 'Location', 
                render: function (data) { 
                    return Fmt.dash(data); 
                } 
            },
            { 
                data: 'status', 
                title: 'Status', 
                render: function (data) { 
                    return Fmt.badge(data, StatusColors); 
                } 
            },
            { 
                data: 'registered_count', 
                title: 'Registered', 
                className: 'text-center' 
            },
            { 
                data: 'attended_count', 
                title: 'Attended', 
                className: 'text-center' 
            }
        ],
        actions: [{
            key: 'participants',
            color: 'info',
            icon: 'fa-users',
            title: 'Participants',
            onClick: function (row) {
                $('#participants-modal .modal-title').text('Participants: ' + row.title);

                if (participants) {
                    participants.destroy();
                    $('#participants-table').empty();
                }

                participantsEventId = row.id;
                participants = ListTable(
                    '#participants-table', 
                    'Events/participants/' + row.id, 
                    [
                        { 
                            data: 'alumni_number', 
                            title: 'Alumni ID' 
                        },
                        { 
                            data: null, 
                            title: 'Name', 
                            render: function (data, type, row) { 
                                return Fmt.esc(row.last_name + ', ' + row.first_name); 
                            } 
                        },
                        { 
                            data: 'registration_status', 
                            title: 'Status', 
                            render: function (data) { 
                                return Fmt.badge(data, StatusColors); 
                            } 
                        },
                        { 
                            data: 'created', 
                            title: 'Registered On', 
                            render: function (data) { 
                                return Fmt.datetime(data); 
                            } 
                        },
                        { 
                            data: null, 
                            title: 'Attendance', 
                            orderable: false, 
                            searchable: false, 
                            className: 'text-nowrap text-center', 
                            render: function (data, type, row) {
                                if (row.registration_status === 'cancelled') {
                                    return '<span class="text-muted">&mdash;</span>';
                                }

                                if (!['ongoing', 'completed'].includes(row.event_status)) {
                                    return '<span class="text-muted small">Not started</span>';
                                }

                                if (row.registration_status === 'attended') {
                                    return '<button type="button" class="btn btn-xs btn-outline-secondary attendance-btn" data-id="' + row.id + '" data-status="registered"><i class="fas fa-undo"></i> Undo</button>';
                                }

                                return '<button type="button" class="btn btn-xs btn-success attendance-btn" data-id="' + row.id + '" data-status="attended"><i class="fas fa-check"></i> Mark attended</button>';
                            } 
                        }
                    ], 
                    { 
                        order: [[3, 'desc']], 
                        emptyText: 'No registrations yet.' 
                    }
                );

                $('#participants-modal').modal('show');
            }
        }]
    });

    events.init();

    $('#participants-table').on('click', '.attendance-btn', function () {
        const $btn = $(this).prop('disabled', true);

        apiRequest(
            'POST', 
            'Events/attendance/' + $btn.data('id'), 
            { status: $btn.data('status') }, 
            function () {
                participants.ajax.reload(null, false);
                events.reload();
            }
        ).always(function () { 
            $btn.prop('disabled', false); 
        });
    });
});