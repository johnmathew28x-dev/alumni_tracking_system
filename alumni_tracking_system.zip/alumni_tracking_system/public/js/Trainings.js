$(function () {
    const syncPurpose = function () {
        const isOther = $('[name="purpose"]', '#trainings-form').val() === 'Other';
        $('#purpose-other-wrap').toggle(isOther);
    };

    $('#trainings-form').on('change', '[name="purpose"]', syncPurpose);

    CrudModule({
        api: 'Trainings',
        noun: 'training',
        table: '#trainings-table',
        form: '#trainings-form',
        modal: '#trainings-modal',
        order: [[4, 'desc']],
        onReset: syncPurpose,
        onEdit: syncPurpose,
        columns: [
            { 
                data: 'training_title', 
                title: 'Title' 
            },
            { 
                data: 'training_type', 
                title: 'Type', 
                render: function (d) { 
                    return Fmt.badge(d, { 
                        'Advanced Study': 'info', 
                        'Training': 'secondary' 
                    }); 
                } 
            },
            { 
                data: 'organizer', 
                title: 'Institution', 
                render: function (d) { 
                    return Fmt.dash(d); 
                } 
            },
            { 
                data: 'duration', 
                title: 'Duration / Credits', 
                render: function (d, t, r) {
                    return Fmt.dash([d, r.credits_earned].filter(Boolean).join(' / '));
                } 
            },
            { 
                data: 'training_year', 
                title: 'Year', 
                render: function (d) { 
                    return Fmt.dash(d); 
                } 
            },
            { 
                data: 'purpose', 
                title: 'Purpose', 
                render: function (d, t, r) { 
                    return Fmt.dash(d === 'Other' ? r.purpose_other : d); 
                } 
            }
        ]
    }).init();
});