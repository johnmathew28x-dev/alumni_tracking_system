$(function () {
    $('#tracer-answer-form').on('submit', function (e) {
        e.preventDefault();

        const $btn = $(this).find('button[type=submit]').prop('disabled', true);

        apiRequest('POST', 'Tracer/submit', $(this).serialize(), function () {
            setTimeout(function () {
                window.location.href = BASE_URL + '/Tracer';
            }, 900);
        }).always(function () {
            $btn.prop('disabled', false);
        });
    });
});