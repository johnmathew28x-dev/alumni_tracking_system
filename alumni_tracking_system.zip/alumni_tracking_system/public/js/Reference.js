$(function () {
    let table = PAGE.tables[PAGE.current] ? PAGE.current : 'programs';
    let dt = null;
    let editingId = null;
    const $modal = $('#ref-modal');
    const $form = $('#ref-form');

    $('#ref-table').val(table);

    function columns() {
        if (table === 'programs') {
            return [
                { data: 'program_code', title: 'Code' },
                { data: 'program_name', title: 'Program' },
                { data: 'department_name', title: 'Department' },
                { data: 'in_use', title: 'Alumni records', className: 'text-center' }
            ];
        }

        if (table === 'departments') {
            return [
                { data: 'department_name', title: 'Department' },
                { data: 'in_use', title: 'Programs', className: 'text-center' }
            ];
        }

        const cols = [
            { data: 'sort_order', title: 'Order', width: '60px' },
            { data: 'name', title: 'Choice' }
        ];

        if (table === 'employment_reasons') {
            cols.push({ data: 'reason_type', title: 'Type' });
        }

        cols.push({
            data: 'is_other',
            title: '"Other"',
            render: function (d) {
                return Fmt.yesNo(d);
            }
        });

        cols.push({
            data: 'is_active',
            title: 'Active',
            render: function (d) {
                return Fmt.yesNo(d);
            }
        });

        return cols;
    }

    function load() {
        if (dt) {
            dt.destroy();
            $('#ref-grid').empty();
        }

        const cols = columns();
        const gts = table !== 'programs' && table !== 'departments';

        cols.push({
            data: null,
            title: 'Options',
            orderable: false,
            className: 'text-nowrap text-center',
            render: function (d, t, r) {
                const editBtn = '<button class="btn btn-sm btn-outline-primary mr-1 ref-edit" data-id="' + r.id + '"><i class="fas fa-pen"></i></button>';
                const toggleBtn = '<button class="btn btn-sm btn-outline-' + (Number(r.is_active) ? 'warning' : 'success') + ' ref-toggle" data-id="' + r.id + '" title="' + (Number(r.is_active) ? 'Hide' : 'Show') + '"><i class="fas ' + (Number(r.is_active) ? 'fa-eye-slash' : 'fa-eye') + '"></i></button>';
                const delBtn = '<button class="btn btn-sm btn-outline-danger ref-del" data-id="' + r.id + '"><i class="fas fa-trash"></i></button>';

                return editBtn + (gts ? toggleBtn : delBtn);
            }
        });

        dt = $('#ref-grid').DataTable({
            ajax: {
                url: BASE_URL + '/Api/Reference/all/' + table,
                dataSrc: 'data'
            },
            columns: cols,
            responsive: true,
            autoWidth: false,
            pageLength: 25,
            order: [[0, 'asc']]
        }).on('error.dt', function () {
            msgBox('error', 'Unable to load the list.');
        });
    }

    function showFields() {
        $('.ref-field').hide();
        if (table === 'programs') {
            $('.f-program').show();
        } else if (table === 'departments') {
            $('.f-dept').show();
        } else {
            $('.f-name').show();
            if (table === 'employment_reasons') {
                $('.f-reason').show();
            }
        }
    }

    $('#ref-table').on('change', function () {
        table = this.value;
        load();
    });

    $('#ref-add').on('click', function () {
        editingId = null;
        $form[0].reset();
        showFields();
        $modal.find('.modal-title').text('Add');
        $modal.modal('show');
    });

    $('#ref-grid').on('click', '.ref-edit', function () {
        const id = $(this).data('id');
        $.getJSON(BASE_URL + '/Api/Reference/edit/' + table + '/' + id)
            .done(function (res) {
                editingId = id;
                $form[0].reset();
                showFields();
                $.each(res, function (k, v) {
                    const $f = $form.find('[name="' + k + '"]');
                    if ($f.is(':checkbox')) {
                        $f.prop('checked', Number(v) === 1);
                    } else {
                        $f.val(v);
                    }
                });
                $modal.find('.modal-title').text('Edit');
                $modal.modal('show');
            })
            .fail(handleAjaxError);
    });

    $('#ref-grid').on('click', '.ref-toggle', function () {
        const id = $(this).data('id');
        apiRequest('POST', 'Reference/toggle/' + table + '/' + id, {}, function () {
            dt.ajax.reload(null, false);
        });
    });

    $('#ref-grid').on('click', '.ref-del', function () {
        const id = $(this).data('id');
        confirmAction(
            {
                title: 'Delete this record?',
                confirmText: 'Yes, delete it',
                color: '#d33'
            },
            'DELETE',
            'Reference/delete/' + table + '/' + id,
            {},
            function () {
                dt.ajax.reload(null, false);
            }
        );
    });

    $form.on('submit', function (e) {
        e.preventDefault();
        const action = editingId ? 'edit/' + table + '/' + editingId : 'add/' + table;
        apiRequest('POST', 'Reference/' + action, $form.serialize(), function () {
            $modal.modal('hide');
            dt.ajax.reload(null, false);
        });
    });

    showFields();
    load();
});