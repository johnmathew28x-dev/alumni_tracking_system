const BASE_URL = (function () {
    const src = $('script[src$="/js/app.js"]').attr('src') || '';
    return src.replace(/\/js\/app\.js.*$/, '');
})();

const CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

$.ajaxSetup({
    headers: { 'X-CSRF-Token': CSRF_TOKEN }
});

$.fn.dataTable.ext.errMode = 'none';

const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true
});

function msgBox(type, message) {
    Toast.fire({ 
        icon: type, 
        title: message 
    });
}

function handleAjaxError(xhr) {
    if (xhr.status === 401) {
        Swal.fire({
            icon: 'warning',
            title: 'Session expired',
            text: 'Please log in again.'
        }).then(function () {
            window.location.href = BASE_URL + '/Auth';
        });
        return;
    }

    const message = (xhr.responseJSON && xhr.responseJSON.message) ||
        (xhr.status === 403 ? 'You are not authorized to do that.' : 'Something went wrong. Please try again.');

    msgBox('error', message);
}

function reportResult(res) {
    msgBox(res.status === 'success' ? 'success' : 'error', res.message || '');
    return res.status === 'success';
}

function apiRequest(method, url, data, onSuccess) {
    return $.ajax({
        url: BASE_URL + '/Api/' + url,
        method: method,
        data: data || {},
        dataType: 'json'
    }).done(function (res) {
        if (reportResult(res) && onSuccess) {
            onSuccess(res);
        }
    }).fail(handleAjaxError);
}

function confirmAction(opts, method, url, data, onSuccess) {
    Swal.fire({
        title: opts.title || 'Are you sure?',
        text: opts.text || '',
        icon: opts.icon || 'warning',
        showCancelButton: true,
        confirmButtonText: opts.confirmText || 'Yes, continue',
        confirmButtonColor: opts.color || '#0b3d91'
    }).then(function (result) {
        if (result.isConfirmed) {
            apiRequest(method, url, data, onSuccess);
        }
    });
}

const Fmt = {
    person: function (name, pictureUrl) {
        return '<div class="alumni-name-cell">' +
            '<img class="alumni-photo" loading="lazy" src="' + Fmt.esc(pictureUrl || BASE_URL + '/img/default-avatar.svg') + '" alt="Profile photo of ' + Fmt.esc(name) + '">' +
            '<span>' + Fmt.esc(name) + '</span></div>';
    },
    esc: function (v) {
        return $('<div>').text(v === null || v === undefined ? '' : v).html();
    },
    dash: function (v) {
        return (v === null || v === undefined || v === '') ? '<span class="text-muted">&mdash;</span>' : Fmt.esc(v);
    },
    date: function (v) {
        if (!v) return '<span class="text-muted">&mdash;</span>';
        const d = new Date(String(v).replace(' ', 'T'));
        return isNaN(d) ? Fmt.esc(v) : d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
    },
    datetime: function (v) {
        if (!v) return '<span class="text-muted">&mdash;</span>';
        const d = new Date(String(v).replace(' ', 'T'));
        return isNaN(d) ? Fmt.esc(v) : d.toLocaleString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
    },
    time: function (v) {
        if (!v) return '';
        const p = String(v).split(':');
        const h = parseInt(p[0], 10);
        return ((h % 12) || 12) + ':' + p[1] + ' ' + (h >= 12 ? 'PM' : 'AM');
    },
    badge: function (value, map, fallback) {
        const cls = (map && map[value]) || fallback || 'secondary';
        const label = String(value || '').replace(/_/g, ' ');
        return '<span class="badge badge-' + cls + '">' + Fmt.esc(label.charAt(0).toUpperCase() + label.slice(1)) + '</span>';
    },
    yesNo: function (v) {
        return Number(v) === 1 ? '<span class="badge badge-success">Yes</span>' : '<span class="badge badge-secondary">No</span>';
    },
    truncate: function (v, n) {
        v = v || '';
        return Fmt.esc(v.length > n ? v.substring(0, n) + '…' : v);
    }
};

const StatusColors = {
    verified: 'success', 
    pending: 'warning', 
    rejected: 'danger',
    active: 'success', 
    inactive: 'secondary',
    draft: 'secondary', 
    published: 'success', 
    closed: 'dark',
    open: 'success',
    upcoming: 'info', 
    ongoing: 'primary', 
    completed: 'secondary', 
    cancelled: 'danger',
    registered: 'success', 
    attended: 'primary', 
    absent: 'danger'
};

function CrudModule(cfg) {
    const apiBase = cfg.api;
    const $table = $(cfg.table);
    const $form = $(cfg.form);
    const $modal = $(cfg.modal);
    const noun = cfg.noun || 'record';
    const canEdit = cfg.canEdit !== false;
    const canDelete = cfg.canDelete !== false;
    const extra = cfg.actions || [];

    let editingId = null;
    let dt = null;

    function optionsHtml(row) {
        let html = '';

        extra.forEach(function (a) {
            if (a.show && !a.show(row)) return;
            const title = typeof a.title === 'function' ? a.title(row) : a.title;
            const icon = typeof a.icon === 'function' ? a.icon(row) : a.icon;
            html += '<button type="button" class="btn btn-sm btn-outline-' + (a.color || 'secondary') +
                ' mr-1 crud-action" data-key="' + a.key + '" data-id="' + row.id + '" title="' + Fmt.esc(title) + '">' +
                '<i class="fas ' + icon + '"></i></button>';
        });

        if (canEdit) {
            html += '<button type="button" class="btn btn-sm btn-outline-primary mr-1 crud-edit" data-id="' + row.id +
                '" title="Edit"><i class="fas fa-pen"></i></button>';
        }

        if (canDelete) {
            html += '<button type="button" class="btn btn-sm btn-outline-danger crud-delete" data-id="' + row.id +
                '" title="Delete"><i class="fas fa-trash"></i></button>';
        }

        return html;
    }

    function init() {
        const columns = cfg.columns.slice();

        if (canEdit || canDelete || extra.length) {
            columns.push({
                data: null, 
                title: 'Options', 
                orderable: false, 
                searchable: false,
                className: 'text-nowrap text-center',
                render: function (data, type, row) { 
                    return optionsHtml(row); 
                }
            });
        }

        dt = $table.DataTable({
            ajax: {
                url: BASE_URL + '/Api/' + (cfg.listUrl || apiBase + '/all'),
                data: cfg.listParams || {},
                dataSrc: 'data'
            },
            columns: columns,
            responsive: true,
            autoWidth: false,
            order: cfg.order || [[0, 'asc']],
            language: { emptyTable: cfg.emptyText || 'No records found.' }
        }).on('error.dt', function (e, settings, techNote, message) {
            console.error(message);
            msgBox('error', 'Unable to load the list. Please refresh the page.');
        });

        bind();
        return api;
    }

    function resetForm() {
        editingId = null;
        $form[0].reset();
        if (cfg.onReset) {
            cfg.onReset($form);
        }
    }

    function fill(res) {
        $.each(res, function (name, value) {
            const $f = $form.find('[name="' + name + '"]');
            if (!$f.length) return;

            if ($f.is(':checkbox')) {
                $f.prop('checked', Number(value) === 1);
            } else if ($f.is(':radio')) {
                $f.filter('[value="' + value + '"]').prop('checked', true);
            } else {
                $f.val(value === null ? '' : value);
            }
        });
    }

    function openAdd() {
        resetForm();
        $modal.find('.modal-title').text('Add ' + noun);
        if (cfg.onAdd) {
            cfg.onAdd($form);
        }
        $modal.modal('show');
    }

    function openEdit(id) {
        $.getJSON(BASE_URL + '/Api/' + apiBase + '/edit/' + id)
            .done(function (res) {
                resetForm();
                editingId = id;
                fill(res);
                $modal.find('.modal-title').text('Edit ' + noun);
                if (cfg.onEdit) {
                    cfg.onEdit(res, $form);
                }
                $modal.modal('show');
            })
            .fail(handleAjaxError);
    }

    function save(e) {
        e.preventDefault();

        const url = BASE_URL + '/Api/' + apiBase + (editingId ? '/edit/' + editingId : '/add');
        const $btn = $form.find('button[type=submit]').prop('disabled', true);

        const hasFile = $form.find('input[type="file"]').length > 0;
        const request = { 
            url: url, 
            method: 'POST', 
            data: hasFile ? new FormData($form[0]) : $form.serialize(), 
            dataType: 'json' 
        };

        if (hasFile) {
            request.processData = false;
            request.contentType = false;
        }

        $.ajax(request)
        .done(function (res) {
            if (reportResult(res)) {
                $modal.modal('hide');
                dt.ajax.reload(null, false);
                if (cfg.onSaved) {
                    cfg.onSaved(res);
                }
            }
        })
        .fail(handleAjaxError)
        .always(function () { 
            $btn.prop('disabled', false); 
        });
    }

    function bind() {
        $form.on('submit', save);

        $(cfg.addButton || '[data-crud-add]').on('click', openAdd);

        $table.on('click', '.crud-edit', function () {
            openEdit($(this).data('id'));
        });

        $table.on('click', '.crud-delete', function () {
            const id = $(this).data('id');
            confirmAction(
                {
                    title: 'Delete this ' + noun + '?',
                    text: 'This action cannot be undone.',
                    confirmText: 'Yes, delete it',
                    color: '#d33'
                }, 
                'DELETE', 
                apiBase + '/delete/' + id, 
                {}, 
                function () { 
                    dt.ajax.reload(null, false); 
                }
            );
        });

        $table.on('click', '.crud-action', function () {
            const key = $(this).data('key');
            const row = dt.row($(this).closest('tr')).data();
            const action = extra.find(function (a) { return a.key === key; });

            if (action.onClick) {
                action.onClick(row, api);
                return;
            }

            const run = function () {
                apiRequest('POST', action.url(row), action.data ? action.data(row) : {}, function () {
                    dt.ajax.reload(null, false);
                });
            };

            if (action.confirm) {
                confirmAction(
                    { title: typeof action.confirm === 'function' ? action.confirm(row) : action.confirm },
                    'POST', 
                    action.url(row), 
                    action.data ? action.data(row) : {}, 
                    function () { 
                        dt.ajax.reload(null, false); 
                    }
                );
            } else {
                run();
            }
        });
    }

    const api = {
        init: init,
        reload: function () { 
            dt.ajax.reload(null, false); 
        },
        table: function () { 
            return dt; 
        }
    };

    return api;
}

function ListTable(selector, url, columns, opts) {
    opts = opts || {};

    const config = {
        ajax: { 
            url: BASE_URL + '/Api/' + url, 
            data: opts.params, 
            dataSrc: 'data' 
        },
        columns: columns,
        responsive: true,
        autoWidth: false,
        order: opts.order || [[0, 'asc']],
        language: { emptyTable: opts.emptyText || 'No records found.' }
    };

    if (opts.dom) {
        config.dom = opts.dom;
    }
    if (opts.buttons) {
        config.buttons = opts.buttons;
    }

    return $(selector).DataTable(config).on('error.dt', function (e, settings, techNote, message) {
        console.error(message);
        msgBox('error', 'Unable to load the list. Please refresh the page.');
    });
}

function bindToggle(checkbox, target, hideWhenChecked) {
    const apply = function () {
        const checked = $(checkbox).is(':checked');
        $(target).toggle(hideWhenChecked ? !checked : checked);
    };
    $(document).on('change', checkbox, apply);
    return apply;
}