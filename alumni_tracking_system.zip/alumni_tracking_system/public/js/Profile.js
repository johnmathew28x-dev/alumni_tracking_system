$(function () {
    const cfg = window.PAGE || {};
    const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
    const ALLOWED_EXT = ['jpg', 'jpeg', 'png', 'webp'];
    const MAX_BYTES = cfg.maxBytes || 2 * 1024 * 1024;

    $('[data-toggle="tooltip"]').tooltip();

    function openAvatar() {
        $('#avatar-large').attr('src', $('#profile-avatar').attr('src'));
        $('#avatar-modal').modal('show');
    }

    $('#profile-avatar')
        .on('click', openAvatar)
        .on('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                openAvatar();
            }
        });

    function setAvatar(url) {
        $('.js-avatar, .js-avatar-nav').attr('src', url);
    }

    const $input = $('#picture-input');
    let previewUrl = null;

    function pictureError(msg) {
        $('#picture-error').text(msg || '').toggleClass('d-none', !msg);
    }

    function resetPicture() {
        if (previewUrl) {
            URL.revokeObjectURL(previewUrl);
            previewUrl = null;
        }
        $input.val('');
        $('#picture-preview-box').addClass('d-none');
        $('#picture-choose').removeClass('d-none');
        pictureError('');
    }

    $('#picture-pick').on('click', function () {
        $input.trigger('click');
    });

    $input.on('change', function () {
        const file = this.files && this.files[0];
        pictureError('');
        if (!file) {
            return;
        }

        const ext = (file.name.split('.').pop() || '').toLowerCase();

        if (ALLOWED_TYPES.indexOf(file.type) === -1 || ALLOWED_EXT.indexOf(ext) === -1) {
            resetPicture();
            pictureError('Only JPG, JPEG, PNG or WEBP images are allowed.');
            return;
        }

        if (file.size > MAX_BYTES) {
            resetPicture();
            pictureError('The image must be 2 MB or smaller.');
            return;
        }

        if (previewUrl) {
            URL.revokeObjectURL(previewUrl);
        }
        previewUrl = URL.createObjectURL(file);

        const probe = new Image();
        probe.onload = function () {
            $('#picture-preview').attr('src', previewUrl);
            $('#picture-name').text(file.name);
            $('#picture-choose').addClass('d-none');
            $('#picture-preview-box').removeClass('d-none');
        };
        probe.onerror = function () {
            resetPicture();
            pictureError('The selected file is not a valid image.');
        };
        probe.src = previewUrl;
    });

    $('#picture-cancel').on('click', resetPicture);

    $('#picture-form').on('submit', function (e) {
        e.preventDefault();
        if (!$input[0].files.length) {
            pictureError('Please choose an image first.');
            return;
        }

        const $btn = $('#picture-save').prop('disabled', true);
        const original = $btn.html();
        $btn.html('<i class="fas fa-spinner fa-spin"></i> Uploading...');

        $.ajax({
            url: BASE_URL + '/Api/Profile/picture',
            method: 'POST',
            data: new FormData(this),
            processData: false,
            contentType: false,
            dataType: 'json'
        })
        .done(function (res) {
            if (reportResult(res)) {
                setAvatar(res.picture_url);
                $('#picture-remove').removeClass('d-none');
                resetPicture();
            } else {
                pictureError(res.message);
            }
        })
        .fail(function (xhr) {
            pictureError((xhr.responseJSON && xhr.responseJSON.message) || 'The upload failed. Please try again.');
            handleAjaxError(xhr);
        })
        .always(function () {
            $btn.prop('disabled', false).html(original);
        });
    });

    $('#picture-remove').on('click', function () {
        confirmAction(
            { title: 'Remove your profile picture?', confirmText: 'Yes, remove it', color: '#d33' },
            'POST',
            'Profile/removePicture',
            {},
            function (res) {
                setAvatar(res.picture_url);
                $('#picture-remove').addClass('d-none');
            }
        );
    });

    const $form = $('#profile-form');

    $('#edit-profile-btn').on('click', function () {
        clearErrors();
        $('#edit-profile-modal').modal('show');
    });

    function clearErrors() {
        $form.find('.is-invalid').removeClass('is-invalid');
        $form.find('.invalid-feedback').remove();
    }

    function showError(name, message) {
        const $f = $form.find('[name="' + name + '"]');
        if (!$f.length) {
            return;
        }
        $f.addClass('is-invalid');
        $('<div class="invalid-feedback"></div>').text(message).insertAfter($f);
    }

    function validate() {
        const errors = {};
        const v = function (n) {
            return $.trim($form.find('[name="' + n + '"]').val() || '');
        };
        const phone = /^[0-9+\-\s()]{7,20}$/;

        if (cfg.isAlumni) {
            if (!v('first_name')) { errors.first_name = 'First name is required.'; }
            if (!v('last_name')) { errors.last_name = 'Last name is required.'; }
            if (!v('gender')) { errors.gender = 'Please choose your sex.'; }
            if (!v('civil_status_id')) { errors.civil_status_id = 'Please choose your civil status.'; }
            if (!v('region_id')) { errors.region_id = 'Please choose your region of origin.'; }
            if (!v('province')) { errors.province = 'Province is required.'; }

            const dob = v('date_of_birth');
            const limit = new Date();
            limit.setFullYear(limit.getFullYear() - 16);

            if (!dob) {
                errors.date_of_birth = 'Birthday is required.';
            } else if (isNaN(new Date(dob)) || new Date(dob) > limit) {
                errors.date_of_birth = 'Please enter a valid birthday.';
            }

            ['contact_number', 'telephone_number'].forEach(function (n) {
                if (v(n) && !phone.test(v(n))) {
                    errors[n] = 'Digits, spaces, + - ( ) only (7-20 characters).';
                }
            });
        } else {
            if (!/^[A-Za-z0-9_.\-]{3,55}$/.test(v('username'))) {
                errors.username = 'Username must be 3-55 characters: letters, numbers, dot, dash or underscore.';
            }
            if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v('email'))) {
                errors.email = 'Please enter a valid email address.';
            }
        }
        return errors;
    }

    function refreshProfile(profile) {
        $.each(profile.values, function (key, value) {
            $('[data-bind="' + key + '"]').text(value);
        });
        $('#avatar-modal .modal-title').text(profile.full_name);
        $('[data-bind="full_name"]').text(profile.full_name);
        if (profile.values.username) {
            $('.js-username').text(profile.values.username);
        }
    }

    $form.on('submit', function (e) {
        e.preventDefault();
        clearErrors();

        const errors = validate();
        if (!$.isEmptyObject(errors)) {
            $.each(errors, showError);
            msgBox('error', 'Please correct the highlighted fields.');
            $form.find('.is-invalid').first().trigger('focus');
            return;
        }

        const $btn = $form.find('button[type=submit]').prop('disabled', true);

        $.ajax({
            url: BASE_URL + '/Api/Profile/update',
            method: 'POST',
            data: $form.serialize(),
            dataType: 'json'
        })
        .done(function (res) {
            if (reportResult(res)) {
                refreshProfile(res.profile);
                $('#edit-profile-modal').modal('hide');
            } else if (res.errors) {
                $.each(res.errors, showError);
            }
        })
        .fail(function (xhr) {
            const errs = xhr.responseJSON && xhr.responseJSON.errors;
            if (errs) {
                $.each(errs, showError);
            }
            handleAjaxError(xhr);
        })
        .always(function () {
            $btn.prop('disabled', false);
        });
    });

    $('#submit-profile-btn').on('click', function () {
        clearErrors();

        const errors = validate();
        if (!$form.find('[name="privacy_ack"]').is(':checked')) {
            errors.privacy_ack = 'Please confirm before submitting.';
        }

        if (!$.isEmptyObject(errors)) {
            $.each(errors, showError);
            msgBox('error', 'Please correct the highlighted fields.');
            $form.find('.is-invalid').first().trigger('focus');
            return;
        }

        Swal.fire({
            title: 'Submit and lock your information?',
            text: 'After submitting, you can no longer edit this information directly. Changes will need an administrator-approved correction request.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, submit and lock',
            confirmButtonColor: '#0b3d91'
        }).then(function (result) {
            if (!result.isConfirmed) {
                return;
            }

            const $btn = $('#submit-profile-btn').prop('disabled', true);

            $.ajax({
                url: BASE_URL + '/Api/Profile/submit',
                method: 'POST',
                data: $form.serialize(),
                dataType: 'json'
            })
            .done(function (res) {
                if (res.status === 'success') {
                    Swal.fire({ icon: 'success', title: 'Submitted', text: res.message })
                        .then(function () { window.location.reload(); });
                } else {
                    msgBox('error', res.message || 'Unable to submit.');
                    if (res.errors) { $.each(res.errors, showError); }
                }
            })
            .fail(function (xhr) {
                handleAjaxError(xhr);
                if (xhr.status === 403) {
                    window.location.reload();
                }
            })
            .always(function () {
                $btn.prop('disabled', false);
            });
        });
    });

    const $corr = $('#correction-form');

    $('#request-correction-btn').on('click', function () {
        $corr.find('.is-invalid').removeClass('is-invalid');
        $corr.find('.invalid-feedback').remove();
        $('#correction-modal').modal('show');
    });

    function corrError(name, message) {
        const $f = $corr.find('[name="' + name + '"]');
        if ($f.length) {
            $f.addClass('is-invalid');
            $('<div class="invalid-feedback"></div>').text(message).insertAfter($f);
        }
    }

    $corr.on('submit', function (e) {
        e.preventDefault();
        $corr.find('.is-invalid').removeClass('is-invalid');
        $corr.find('.invalid-feedback').remove();

        const reason = $.trim($corr.find('[name="reason"]').val() || '');
        if (reason.length < 10) {
            corrError('reason', 'Please explain the reason (at least 10 characters).');
            return;
        }

        const $btn = $corr.find('button[type=submit]').prop('disabled', true);

        $.ajax({
            url: BASE_URL + '/Api/Profile/requestCorrection',
            method: 'POST',
            data: $corr.serialize(),
            dataType: 'json'
        })
        .done(function (res) {
            if (res.status === 'success') {
                Swal.fire({ icon: 'success', title: 'Request sent', text: res.message })
                    .then(function () { window.location.reload(); });
            } else {
                msgBox('error', res.message || 'Unable to send the request.');
                if (res.errors) { $.each(res.errors, corrError); }
            }
        })
        .fail(handleAjaxError)
        .always(function () {
            $btn.prop('disabled', false);
        });
    });
});
