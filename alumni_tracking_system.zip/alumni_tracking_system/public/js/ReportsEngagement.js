$(function () {
    const cfg = window.PAGE;
    const levelColors = { 
        highly: 'success', 
        moderate: 'info', 
        low: 'warning', 
        none: 'secondary' 
    };
    const attendanceColors = { 
        attended: 'primary', 
        absent: 'danger', 
        registered: 'info', 
        cancelled: 'secondary' 
    };
    const tables = {};

    const plain = function (d, t) { 
        return t === 'display' ? Fmt.dash(d) : (d === null ? '' : d); 
    };

    const pct = function (d, t) {
        if (t !== 'display') { 
            return d === null ? '' : d; 
        }
        return d === null ? '<span class="text-muted">n/a</span>' : Fmt.esc(d) + '%';
    };

    function build(key, selector, type, title, columns, order) {
        const $form = $('.eng-filter[data-table="' + key + '"]');
        let lastRequest = null;
        const exportCols = { columns: ':visible' };
        const fileName = title.replace(/\s+/g, '_');

        const dt = $(selector).DataTable({
            ajax: function (dtData, callback) {
                if (lastRequest && lastRequest.readyState !== 4) { 
                    lastRequest.abort(); 
                }

                const params = {};
                $form.serializeArray().forEach(function (f) { 
                    params[f.name] = f.value; 
                });

                lastRequest = $.ajax({ 
                    url: BASE_URL + '/Api/Reports/data/' + type, 
                    data: params, 
                    dataType: 'json' 
                })
                .done(function (res) { 
                    callback({ data: res.data }); 
                })
                .fail(function (xhr) {
                    if (xhr.statusText === 'abort') { 
                        return; 
                    }
                    callback({ data: [] });
                    handleAjaxError(xhr);
                });
            },
            columns: columns,
            responsive: true,
            autoWidth: false,
            pageLength: 25,
            order: order,
            dom: "<'row'<'col-md-8'B><'col-md-4'f>>rt<'row'<'col-md-5'i><'col-md-7'p>>",
            buttons: [
                { 
                    extend: 'excelHtml5', 
                    className: 'btn-sm btn-success', 
                    text: '<i class="fas fa-file-excel"></i> Excel', 
                    title: title, 
                    filename: fileName, 
                    exportOptions: exportCols 
                },
                { 
                    extend: 'pdfHtml5', 
                    className: 'btn-sm btn-danger', 
                    text: '<i class="fas fa-file-pdf"></i> PDF', 
                    title: title, 
                    filename: fileName, 
                    orientation: 'landscape', 
                    exportOptions: exportCols 
                },
                { 
                    extend: 'print', 
                    className: 'btn-sm btn-secondary', 
                    text: '<i class="fas fa-print"></i> Print', 
                    title: title, 
                    exportOptions: exportCols 
                }
            ],
            language: { 
                emptyTable: 'No records match the selected filters.' 
            }
        }).on('error.dt', function (e, settings, techNote, message) {
            console.error(message);
            msgBox('error', 'Unable to load the report. Please refresh the page.');
        });

        $form.on('change', 'select', function () { 
            dt.ajax.reload(); 
        });

        $form.on('reset', function () { 
            setTimeout(function () { 
                dt.ajax.reload(); 
            }, 0); 
        });

        tables[key] = dt;
        return dt;
    }

    build('alumni', '#eng-alumni-table', 'engagementAlumni', 'Active Alumni Attendance', [
        { 
            data: 'alumni_id', 
            title: 'Alumni ID' 
        },
        { 
            data: 'name', 
            title: 'Name', 
            render: function (d, t, r) { 
                return t === 'display' ? Fmt.person(d, r.picture_url) : Fmt.esc(d); 
            } 
        },
        { 
            data: 'program_code', 
            title: 'Program', 
            defaultContent: '', 
            render: plain 
        },
        { 
            data: 'graduation_year', 
            title: 'Grad. Year', 
            defaultContent: '', 
            render: plain 
        },
        { 
            data: 'events_registered', 
            title: 'Events Registered', 
            className: 'text-center' 
        },
        { 
            data: 'events_attended', 
            title: 'Events Attended', 
            className: 'text-center' 
        },
        { 
            data: 'total_events', 
            title: 'Total Events', 
            className: 'text-center' 
        },
        { 
            data: 'attendance_rate', 
            title: 'Attendance Rate', 
            className: 'text-center', 
            render: pct 
        },
        { 
            data: 'engagement_status', 
            title: 'Engagement Status', 
            render: function (d, t, r) {
                if (t !== 'display') { 
                    return d; 
                }
                const badgeColor = levelColors[r.engagement_key] || 'secondary';
                return '<span class="badge badge-' + badgeColor + '">' + Fmt.esc(d) + '</span>';
            } 
        }
    ], [[1, 'asc']]);

    build('events', '#eng-events-table', 'engagementEvents', 'Event Attendance', [
        { 
            data: 'title', 
            title: 'Event', 
            render: function (d) { 
                return Fmt.esc(d); 
            } 
        },
        { 
            data: 'event_date', 
            title: 'Event Date', 
            render: function (d, t) { 
                return t === 'display' ? Fmt.date(d) : d; 
            } 
        },
        { 
            data: 'status', 
            title: 'Status', 
            render: function (d, t) { 
                return t === 'display' ? Fmt.badge(d, StatusColors) : d; 
            } 
        },
        { 
            data: 'registered_count', 
            title: 'Registered', 
            className: 'text-center' 
        },
        { 
            data: 'attended_count', 
            title: 'Attended', 
            className: 'text-center' 
        },
        { 
            data: 'attendance_rate', 
            title: 'Attendance Rate', 
            className: 'text-center', 
            render: pct 
        },
        { 
            data: 'active_attended', 
            title: 'Active Alumni Attended', 
            className: 'text-center' 
        },
        { 
            data: 'active_rate', 
            title: 'Active Alumni Participation', 
            className: 'text-center', 
            render: pct 
        }
    ], [[1, 'desc']]);

    build('records', '#eng-records-table', 'engagementRecords', 'Attendance Records', [
        { 
            data: 'alumni_id', 
            title: 'Alumni ID' 
        },
        { 
            data: 'name', 
            title: 'Name', 
            render: function (d, t, r) { 
                return t === 'display' ? Fmt.person(d, r.picture_url) : Fmt.esc(d); 
            } 
        },
        { 
            data: 'program_code', 
            title: 'Program', 
            defaultContent: '', 
            render: plain 
        },
        { 
            data: 'event_title', 
            title: 'Event', 
            render: function (d) { 
                return Fmt.esc(d); 
            } 
        },
        { 
            data: 'event_date', 
            title: 'Event Date', 
            render: function (d, t) { 
                return t === 'display' ? Fmt.date(d) : d; 
            } 
        },
        { 
            data: 'attendance_status', 
            title: 'Attendance Status', 
            render: function (d, t) {
                return t === 'display' ? Fmt.badge(d, attendanceColors) : d;
            } 
        }
    ], [[4, 'desc']]);

    $('#eng-overview-table').DataTable({
        ajax: { 
            url: BASE_URL + '/Api/Reports/data/engagement', 
            dataSrc: 'data' 
        },
        columns: cfg.overviewColumns.map(function (c) { 
            return Object.assign({ defaultContent: '', render: plain }, c); 
        }),
        responsive: true,
        autoWidth: false,
        language: { 
            emptyTable: 'No engagement data yet.' 
        }
    }).on('error.dt', function () { 
        msgBox('error', 'Unable to load the report. Please refresh the page.'); 
    });

    $('#engagement-tabs a[data-toggle="pill"]').on('shown.bs.tab', function () {
        $.fn.dataTable.tables({ visible: true, api: true }).columns.adjust().responsive.recalc();
    });
});